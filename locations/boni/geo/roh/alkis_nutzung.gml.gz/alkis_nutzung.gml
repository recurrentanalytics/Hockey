<?xml version='1.0' encoding='utf-8'?><wfs:FeatureCollection xmlns="http://repository.gdi-de.org/schemas/adv/produkt/alkis-vereinfacht/2.0" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:wfs="http://www.opengis.net/wfs/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" timeStamp="2026-11-27T11:53:28.373+01:00" numberReturned="146" numberMatched="unknown" xsi:schemaLocation="http://repository.gdi-de.org/schemas/adv/produkt/alkis-vereinfacht/2.0 http://download.lgln.niedersachsen.de/aaa-suite/schema/AAA-vereinfacht/2.0/schema/ALKIS-vereinfacht.xsd http://www.opengis.net/wfs/2.0 http://download.lgln.niedersachsen.de/aaa-suite/schema/ogc/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://download.lgln.niedersachsen.de/aaa-suite/schema/ogc/gml/3.2.1/gml.xsd">
<wfs:boundedBy>
<gml:Envelope srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:lowerCorner>550340.17 5804167.492</gml:lowerCorner>
<gml:upperCorner>551002.224 5804910.478</gml:upperCorner>
</gml:Envelope>
</wfs:boundedBy>
<wfs:member>
<Nutzung gml:id="DENIAL430001yhbHTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001yhbHTN</gml:identifier>
<oid>DENIAL430001yhbHTN</oid>
<aktualit>2020-04-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41184580.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41184580.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550487.126 5804512.587 550487.148 5804512.507 550489.98 5804505.008 550492.121 5804499.338 550495.694 5804500.621 550509.578 5804505.605 550522.627 5804510.29 550530.197 5804513.008 550524.5 5804528.286 550518.872 5804526.251 550513.242 5804530.468 550510.521 5804537.985 550505.342 5804536.08 550506.521 5804532.843 550490.514 5804521.818 550488.622 5804520.514 550489.855 5804518.736 550491.883 5804515.813 550492.097 5804515.96 550492.168 5804515.738 550487.126 5804512.587</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jAGTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jAGTN</gml:identifier>
<oid>DENIAL4300005jAGTN</oid>
<aktualit>2011-09-15Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41187772.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41187772.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550561.141 5804766.416 550617.72 5804738.371 550619.62 5804742.812 550561.33 5804771.627 550561.141 5804766.416</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jBVTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jBVTN</gml:identifier>
<oid>DENIAL4300005jBVTN</oid>
<aktualit>2011-09-15Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41188227.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41188227.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550481.69 5804791.27 550540.927 5804761.739 550540.951 5804766.641 550486.002 5804794.213 550481.69 5804791.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jCkTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jCkTN</gml:identifier>
<oid>DENIAL4300005jCkTN</oid>
<aktualit>2011-09-15Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41188584.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41188584.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550553.502 5804755.47 550600.919 5804731.833 550606.343 5804733.828 550557.972 5804758.099 550553.502 5804755.47</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtERTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtERTN</gml:identifier>
<oid>DENIAL430001LtERTN</oid>
<aktualit>2022-05-13Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41219066.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41219066.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550601.004 5804647.193 550604.814 5804645.764 550628.468 5804707.518 550625.928 5804708.947 550601.004 5804647.193</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzCTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzCTN</gml:identifier>
<oid>DENIAL430001LtzCTN</oid>
<aktualit>2022-05-13Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41219078.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41219078.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550510.145 5804539.022 550510.521 5804537.985 550513.242 5804530.468 550518.872 5804526.251 550524.5 5804528.286 550543.543 5804535.17 550541.713 5804539.215 550521.208 5804532.6 550519.224 5804538.818 550540.258 5804545.433 550538.632 5804549.329 550527.357 5804545.249 550510.145 5804539.022</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzsTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzsTN</gml:identifier>
<oid>DENIAL430001LtzsTN</oid>
<aktualit>2022-05-13Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41219080.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41219080.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550554.479 5804468.505 550556.067 5804463.743 550558.713 5804460.568 550561.359 5804457.922 550564.004 5804456.863 550567.709 5804456.731 550571.81 5804457.789 550573.926 5804459.906 550575.514 5804462.552 550576.837 5804465.595 550577.101 5804468.24 550576.44 5804471.283 550575.249 5804474.723 550573.265 5804477.369 550570.751 5804478.824 550567.179 5804479.75 550562.814 5804479.221 550558.658 5804477.594 550555.405 5804474.723 550554.479 5804471.812 550554.479 5804468.505</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iidWTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iidWTN</gml:identifier>
<oid>DENIAL430001iidWTN</oid>
<aktualit>2017-03-06Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.41305866.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.41305866.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550479.117 5804507.582 550483.43 5804496.218 550492.121 5804499.338 550489.98 5804505.008 550487.148 5804512.507 550487.126 5804512.587 550479.117 5804507.582</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Industrie- und Gewerbefläche</nutzart>
<bez>Handel und Dienstleistung</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001jZRgTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZRgTN</gml:identifier>
<oid>DENIAL430001jZRgTN</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.153336840.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.153336840.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550826.28 5804336.952 550826.27104963 5804336.93333001 550826.14619703 5804336.62289781 550826.06415468 5804336.319876 550826.01918445 5804336.03008198 550826.0052814 5804335.75737538 550826.01665893 5804335.50396737 550826.04804679 5804335.2707792 550826.09483864 5804335.05778687 550826.15836025 5804334.84917188 550826.24520318 5804334.63049351 550826.3593952 5804334.40398689 550826.50508001 5804334.17303643 550826.68621971 5804333.94240401 550826.90615937 5804333.71839573 550827.16705261 5804333.50889385 550827.184 5804333.497 550837.006 5804327.628 550848.881 5804320.532 550850.45 5804323.176 550861.371 5804341.486 550864.691 5804347.052 550871.805 5804341.927 550879.605 5804354.408 550880.438 5804353.853 550910.278 5804333.98 550920.754 5804328.292 550927.841 5804341.316 550928.321 5804342.196 550925.386 5804344.014 550930.982 5804354.463 550936.786 5804365.298 550926.791 5804370.462 550916.876 5804375.585 550905.941 5804381.236 550884.15 5804392.496 550872.619 5804398.454 550865.243 5804402.265 550856.074 5804386.939 550848.919 5804374.981 550841.749 5804362.996 550833.046 5804348.343 550826.28 5804336.952</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009RFATN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009RFATN</gml:identifier>
<oid>DENIAL4300009RFATN</oid>
<aktualit>2026-04-08Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.153337973.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.153337973.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550872.392 5804414.263 550885.076 5804407.692 550899.723 5804400.104 550910.489 5804420.855 550903.327 5804424.174 550907.833 5804431.733 550915.003 5804443.76 550896.506 5804454.759 550889.342 5804442.756 550883.69 5804433.256 550872.392 5804414.263</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005byUTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005byUTN</gml:identifier>
<oid>DENIAL4300005byUTN</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.156848854.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.156848854.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550448.913 5804432.826 550457.946 5804416.643 550470.334 5804394.451 550487.806 5804363.164 550507.508 5804327.867 550534.148 5804342.841 550561.037 5804357.965 550578.805 5804326.579 550592.284 5804302.516 550624.721 5804320.659 550593.534 5804376.217 550573.763 5804411.423 550556.22 5804442.671 550540.427 5804470.83 550509.589 5804459.795 550475.362 5804447.55 550451.172 5804438.904 550448.913 5804432.826</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Industrie- und Gewerbefläche</nutzart>
<bez>Handel und Dienstleistung</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BjPTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BjPTN</gml:identifier>
<oid>DENIAL4300009BjPTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100352.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100352.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550635.708 5804337.496 550644.456 5804337.572 550648.482 5804339.805 550691.731 5804400.326 550690.018 5804404.262 550685.718 5804398.387 550679.65 5804390.248 550670.69 5804378.233 550659.344 5804363.016 550655.339 5804366.002 550649.206 5804357.777 550649.607 5804357.478 550642.99 5804348.654 550635.708 5804337.496</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMyTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMyTN</gml:identifier>
<oid>DENIAL430001iuMyTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100361.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100361.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550574.089 5804446.635 550578.553 5804438.595 550576.402 5804437.382 550580.479 5804430.118 550590.02 5804413.118 550597.24 5804400.254 550604.453 5804387.402 550611.629 5804374.617 550617.998 5804363.269 550618.10683719 5804363.04170477 550618.27755416 5804362.77722562 550618.46933791 5804362.55378632 550618.6724838 5804362.3703126 550618.87909472 5804362.22379509 550619.08318948 5804362.11014398 550619.28054793 5804362.02485753 550619.46842556 5804361.96348165 550619.66098255 5804361.91890805 550619.87401496 5804361.88990234 550620.10747567 5804361.88169605 550620.36007899 5804361.90032428 550620.62881881 5804361.95237977 550620.90849036 5804362.04452071 550621.19134132 5804362.18268306 550621.402 5804362.321 550622.936 5804363.611 550642.99 5804348.654 550649.607 5804357.478 550649.206 5804357.777 550655.339 5804366.002 550659.344 5804363.016 550670.69 5804378.233 550679.65 5804390.248 550685.718 5804398.387 550684.4 5804404.974 550668.942 5804414.221 550656.303 5804421.781 550643.664 5804429.341 550631.026 5804436.901 550614.317 5804446.896 550589.945 5804461.376 550589.562 5804461.704 550589.334 5804461.576 550583.688 5804455.984 550574.089 5804446.635</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzFTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzFTN</gml:identifier>
<oid>DENIAL430001LtzFTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100959.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100959.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550441.049 5804451.21 550442.273 5804448.348 550554.943 5804488.839 550558.491 5804493.241 550533.028 5804484.128 550519.166 5804479.167 550505.303 5804474.206 550491.43 5804469.241 550477.511 5804464.259 550463.632 5804459.292 550441.049 5804451.21</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzGTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzGTN</gml:identifier>
<oid>DENIAL430001LtzGTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100960.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100960.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550447.471 5804436.196 550448.913 5804432.826 550451.172 5804438.904 550475.362 5804447.55 550509.589 5804459.795 550540.427 5804470.83 550542.394 5804473.27 550539.993 5804473.678 550538.141 5804472.884 550448.58 5804441.002 550447.471 5804436.196</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzJTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzJTN</gml:identifier>
<oid>DENIAL430001LtzJTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100961.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100961.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550540.427 5804470.83 550556.22 5804442.671 550573.763 5804411.423 550593.534 5804376.217 550624.721 5804320.659 550626.516 5804323.409 550576.506 5804411.897 550542.394 5804473.27 550540.427 5804470.83</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtztTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtztTN</gml:identifier>
<oid>DENIAL430001LtztTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100962.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100962.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550442.273 5804448.348 550447.471 5804436.196 550448.58 5804441.002 550538.141 5804472.884 550539.993 5804473.678 550542.394 5804473.27 550554.943 5804488.839 550442.273 5804448.348</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzyTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzyTN</gml:identifier>
<oid>DENIAL430001LtzyTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100963.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100963.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550527.541 5804582.495 550533.084 5804565.919 550538.632 5804549.329 550540.258 5804545.433 550543.301 5804547.682 550529.698 5804586.073 550527.541 5804582.495</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMzTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMzTN</gml:identifier>
<oid>DENIAL430001iuMzTN</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157100983.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157100983.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550419.172 5804490.56 550427.198 5804475.863 550435.591 5804460.824 550441.049 5804451.21 550463.632 5804459.292 550477.511 5804464.259 550491.43 5804469.241 550505.303 5804474.206 550519.166 5804479.167 550533.028 5804484.128 550558.491 5804493.241 550554.035 5804505.686 550548.996 5804519.757 550543.543 5804535.17 550524.5 5804528.286 550530.197 5804513.008 550522.627 5804510.29 550509.578 5804505.605 550495.694 5804500.621 550492.121 5804499.338 550483.43 5804496.218 550479.117 5804507.582 550487.126 5804512.587 550492.168 5804515.738 550492.097 5804515.96 550491.883 5804515.813 550489.855 5804518.736 550488.622 5804520.514 550490.514 5804521.818 550506.521 5804532.843 550505.342 5804536.08 550510.521 5804537.985 550510.145 5804539.022 550527.357 5804545.249 550538.632 5804549.329 550533.084 5804565.919 550527.541 5804582.495 550519.808 5804579.892 550516.787 5804576.629 550501.998 5804560.656 550492.794 5804550.716 550484.755 5804542.074 550479.578 5804537.094 550477.506 5804535.114 550469.55 5804528.019 550468.55 5804527.129 550456.851 5804517.896 550443.923 5804508.579 550434.687 5804502.673 550430.71 5804500.37 550425.989 5804497.637 550420.328 5804494.594 550419.172 5804490.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001g4UwTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001g4UwTN</gml:identifier>
<oid>DENIAL430001g4UwTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157101976.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157101976.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550645.25 5804314.803 550710.182 5804200.1 550711.61 5804200.382 550711.862 5804200.984 550724.293 5804225.628 550728.055 5804233.419 550733.835 5804246.192 550742.942 5804266.523 550744.094 5804268.981 550757.073 5804284.114 550771.074 5804301.407 550765.98 5804304.434 550756.008 5804311.756 550755.324 5804312.556 550762.656 5804324.934 550754.618 5804329.776 550755.504 5804331.198 550687.702 5804371.848 550645.25 5804314.803</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Fläche besonderer funktionaler Prägung</nutzart>
<bez>Gesundheit, Kur</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001jZzdTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZzdTN</gml:identifier>
<oid>DENIAL430001jZzdTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157101978.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157101978.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550687.702 5804371.848 550755.504 5804331.198 550754.618 5804329.776 550762.656 5804324.934 550755.324 5804312.556 550756.008 5804311.756 550765.98 5804304.434 550771.074 5804301.407 550757.073 5804284.114 550744.094 5804268.981 550742.942 5804266.523 550733.835 5804246.192 550748.959 5804236.697 550760.401 5804255.856 550771.839 5804275.006 550783.277 5804294.156 550791.379 5804307.721 550799.85 5804321.903 550805.994 5804332.19 550783.856 5804345.448 550769.277 5804354.179 550703.754 5804393.419 550695.346 5804382.12 550687.702 5804371.848</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BqoTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BqoTN</gml:identifier>
<oid>DENIAL4300009BqoTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102055.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102055.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550708.903 5804406.967 550710.371 5804402.265 550712.794 5804405.504 550715.666 5804409.861 550751.253 5804463.854 550753.883 5804467.843 550755.849 5804471.02 550750.892 5804471.264 550708.903 5804406.967</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BtSTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BtSTN</gml:identifier>
<oid>DENIAL4300009BtSTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102056.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102056.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550640.263 5804317.479 550640.515 5804312.374 550645.25 5804314.803 550687.702 5804371.848 550695.346 5804382.12 550703.754 5804393.419 550706.093 5804396.546 550699.634 5804396.25 550640.263 5804317.479</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430000ae1MTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000ae1MTN</gml:identifier>
<oid>DENIAL430000ae1MTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102081.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102081.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550712.794 5804405.504 550717.27 5804402.823 550785.966 5804361.677 550809.248 5804347.732 550813.552 5804345.153 550816.126 5804349.459 550849.28 5804404.921 550851.838 5804409.2 550847.558 5804411.763 550824.285 5804425.696 550757.983 5804465.388 550753.883 5804467.843 550751.253 5804463.854 550715.666 5804409.861 550712.794 5804405.504</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Fläche besonderer funktionaler Prägung</nutzart>
<bez>Religiöse Einrichtung</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430000ae2NTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000ae2NTN</gml:identifier>
<oid>DENIAL430000ae2NTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102082.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102082.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550761.213 5804479.689 550859.937 5804420.618 550887.819 5804467.356 550790.862 5804527.034 550786.149 5804519.219 550782.261 5804512.867 550761.213 5804479.689</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Fläche besonderer funktionaler Prägung</nutzart>
<bez>Bildung und Wissenschaft</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZ9PTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZ9PTN</gml:identifier>
<oid>DENIALP10000cZ9PTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102113.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102113.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550706.093 5804396.546 550807.796 5804335.281 550812.02 5804342.525 550710.371 5804402.265 550706.093 5804396.546</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZ9QTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZ9QTN</gml:identifier>
<oid>DENIALP10000cZ9QTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102114.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102114.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550710.371 5804402.265 550812.02 5804342.525 550813.552 5804345.153 550809.248 5804347.732 550785.966 5804361.677 550717.27 5804402.823 550712.794 5804405.504 550710.371 5804402.265</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZ9RTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZ9RTN</gml:identifier>
<oid>DENIALP10000cZ9RTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102115.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102115.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550703.754 5804393.419 550769.277 5804354.179 550783.856 5804345.448 550805.994 5804332.19 550807.796 5804335.281 550706.093 5804396.546 550703.754 5804393.419</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZ9STN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZ9STN</gml:identifier>
<oid>DENIALP10000cZ9STN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102116.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102116.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550714.276 5804177.241 550714.861 5804176.62 550715.529 5804175.584 550715.967 5804174.431 550716.156 5804173.213 550716.088 5804171.981 550715.363 5804168.055 550723.637 5804167.492 550724.042 5804170.626 550724.228 5804177.086 550725.498 5804178.832 550727.615 5804180.208 550735.976 5804194.231 550737.299 5804193.49 550777.463 5804260.8 550779.632 5804262.017 550781.479 5804261.967 550786.8 5804270.88 550784.924 5804273.236 550785.453 5804275.3 550816.145 5804326.1 550817.997 5804326.84 550820.007 5804326.555 550823.699 5804332.648 550822.124 5804334.408 550822.495 5804336.895 550861.876 5804404.007 550854.142 5804408.008 550815.624 5804342.762 550813.52 5804342.008 550812.02 5804342.525 550807.796 5804335.281 550809.439 5804332.83 550808.381 5804331.11 550726.598 5804191.648 550723.264 5804187.044 550719.328 5804186.379 550714.276 5804177.241</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZa2TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZa2TN</gml:identifier>
<oid>DENIALP10000cZa2TN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102118.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102118.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550822.124 5804334.408 550823.699 5804332.648 550825.003 5804334.801 550826.28 5804336.952 550833.046 5804348.343 550841.749 5804362.996 550848.919 5804374.981 550856.074 5804386.939 550865.243 5804402.265 550861.876 5804404.007 550822.495 5804336.895 550822.124 5804334.408</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZa3TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZa3TN</gml:identifier>
<oid>DENIALP10000cZa3TN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102119.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102119.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550812.02 5804342.525 550813.52 5804342.008 550815.624 5804342.762 550854.142 5804408.008 550851.838 5804409.2 550849.28 5804404.921 550816.126 5804349.459 550813.552 5804345.153 550812.02 5804342.525</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZahTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZahTN</gml:identifier>
<oid>DENIALP10000cZahTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102123.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102123.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550755.849 5804471.02 550852.959 5804412.291 550853.991 5804410.703 550854.142 5804408.008 550861.876 5804404.007 550863.754 5804405.227 550866.215 5804404.671 550938.079 5804367.614 550942.178 5804374.958 550870.581 5804411.894 550868.517 5804413.72 550868.63 5804416.183 550862.799 5804419.158 550860.976 5804417.768 550857.563 5804418.641 550758.965 5804476.055 550755.849 5804471.02</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZajTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZajTN</gml:identifier>
<oid>DENIALP10000cZajTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102124.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102124.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550758.965 5804476.055 550857.563 5804418.641 550860.976 5804417.768 550862.799 5804419.158 550859.937 5804420.618 550761.213 5804479.689 550758.965 5804476.055</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZakTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZakTN</gml:identifier>
<oid>DENIALP10000cZakTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102125.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102125.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550753.883 5804467.843 550757.983 5804465.388 550824.285 5804425.696 550847.558 5804411.763 550851.838 5804409.2 550854.142 5804408.008 550853.991 5804410.703 550852.959 5804412.291 550755.849 5804471.02 550753.883 5804467.843</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZalTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZalTN</gml:identifier>
<oid>DENIALP10000cZalTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102126.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102126.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550861.876 5804404.007 550865.243 5804402.265 550872.619 5804398.454 550884.15 5804392.496 550905.941 5804381.236 550916.876 5804375.585 550926.791 5804370.462 550936.786 5804365.298 550938.079 5804367.614 550866.215 5804404.671 550863.754 5804405.227 550861.876 5804404.007</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZamTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZamTN</gml:identifier>
<oid>DENIALP10000cZamTN</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102127.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102127.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550868.517 5804413.72 550870.581 5804411.894 550942.178 5804374.958 550943.525 5804377.372 550942.636 5804377.832 550899.723 5804400.104 550885.076 5804407.692 550872.392 5804414.263 550868.63 5804416.183 550868.517 5804413.72</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzDTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzDTN</gml:identifier>
<oid>DENIAL430001LtzDTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102372.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102372.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550542.394 5804473.27 550576.506 5804411.897 550626.516 5804323.409 550635.708 5804337.496 550629.158 5804338.078 550627.571 5804339.798 550602.038 5804385.042 550569.891 5804442.854 550569.891 5804445.896 550571.743 5804448.542 550588.053 5804464.635 550579.469 5804481.315 550574.522 5804483.6 550572.493 5804488.333 550561.471 5804492.197 550559.705 5804490.611 550554.943 5804488.839 550542.394 5804473.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
<gml:interior>
<gml:LinearRing>
<gml:posList>550554.479 5804468.505 550554.479 5804471.812 550555.405 5804474.723 550558.658 5804477.594 550562.814 5804479.221 550567.179 5804479.75 550570.751 5804478.824 550573.265 5804477.369 550575.249 5804474.723 550576.44 5804471.283 550577.101 5804468.24 550576.837 5804465.595 550575.514 5804462.552 550573.926 5804459.906 550571.81 5804457.789 550567.709 5804456.731 550564.004 5804456.863 550561.359 5804457.922 550558.713 5804460.568 550556.067 5804463.743 550554.479 5804468.505</gml:posList>
</gml:LinearRing>
</gml:interior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzHTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzHTN</gml:identifier>
<oid>DENIAL430001LtzHTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102373.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102373.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550554.943 5804488.839 550559.705 5804490.611 550561.471 5804492.197 550558.491 5804493.241 550554.943 5804488.839</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzITN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzITN</gml:identifier>
<oid>DENIAL430001LtzITN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102374.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102374.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550572.493 5804488.333 550574.522 5804483.6 550579.469 5804481.315 550576.598 5804486.894 550572.493 5804488.333</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzKTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzKTN</gml:identifier>
<oid>DENIAL430001LtzKTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102375.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102375.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550569.891 5804442.854 550602.038 5804385.042 550627.571 5804339.798 550629.158 5804338.078 550635.708 5804337.496 550642.99 5804348.654 550622.936 5804363.611 550621.402 5804362.321 550621.19134132 5804362.18268306 550620.90849036 5804362.04452071 550620.62881881 5804361.95237977 550620.36007899 5804361.90032428 550620.10747567 5804361.88169605 550619.87401496 5804361.88990234 550619.66098255 5804361.91890805 550619.46842556 5804361.96348165 550619.28054793 5804362.02485753 550619.08318948 5804362.11014398 550618.87909472 5804362.22379509 550618.6724838 5804362.3703126 550618.46933791 5804362.55378632 550618.27755416 5804362.77722562 550618.10683719 5804363.04170477 550617.998 5804363.269 550611.629 5804374.617 550604.453 5804387.402 550597.24 5804400.254 550590.02 5804413.118 550580.479 5804430.118 550576.402 5804437.382 550578.553 5804438.595 550574.089 5804446.635 550583.688 5804455.984 550589.334 5804461.576 550589.562 5804461.704 550588.053 5804464.635 550571.743 5804448.542 550569.891 5804445.896 550569.891 5804442.854</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzLTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzLTN</gml:identifier>
<oid>DENIAL430001LtzLTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102376.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102376.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550588.053 5804464.635 550589.562 5804461.704 550589.945 5804461.376 550614.317 5804446.896 550631.026 5804436.901 550643.664 5804429.341 550656.303 5804421.781 550668.942 5804414.221 550684.4 5804404.974 550685.718 5804398.387 550690.018 5804404.262 550687.446 5804406.579 550591.243 5804464.999 550588.053 5804464.635</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzMTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzMTN</gml:identifier>
<oid>DENIAL430001LtzMTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102377.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102377.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550576.598 5804486.894 550579.469 5804481.315 550591.085 5804474.207 550695.541 5804411.808 550697.729 5804414.469 550680.927 5804424.515 550668.148 5804432.156 550652.701 5804441.392 550602.577 5804471.361 550583.348 5804482.858 550576.598 5804486.894</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzwTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzwTN</gml:identifier>
<oid>DENIAL430001LtzwTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102381.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102381.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550579.469 5804481.315 550588.053 5804464.635 550591.243 5804464.999 550687.446 5804406.579 550690.018 5804404.262 550695.541 5804411.808 550591.085 5804474.207 550579.469 5804481.315</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzxTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzxTN</gml:identifier>
<oid>DENIAL430001LtzxTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102382.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102382.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550541.713 5804539.215 550543.543 5804535.17 550548.996 5804519.757 550554.035 5804505.686 550558.491 5804493.241 550561.471 5804492.197 550561.24 5804495.162 550546.793 5804535.008 550546.211 5804537.231 550545.285 5804538.95 550543.301 5804539.744 550541.713 5804539.215</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001hQleTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001hQleTN</gml:identifier>
<oid>DENIAL430001hQleTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102384.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102384.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550573.216 5804548.824 550579.784 5804530.76 550598.832 5804537.358 550603.678 5804524.179 550606.971 5804521.941 550606.807 5804520.736 550606.01 5804520.451 550611.211 5804512.026 550619.208 5804499.075 550602.577 5804471.361 550652.701 5804441.392 550673.304 5804475.515 550673.925 5804476.543 550668.763 5804480.027 550651.697 5804491.544 550652.307 5804492.337 550676.51 5804523.75 550671.996 5804527.217 550656.157 5804539.695 550640.636 5804552.308 550625.653 5804564.835 550623.341 5804566.768 550573.216 5804548.824</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Fläche besonderer funktionaler Prägung</nutzart>
<bez>Bildung und Wissenschaft</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMwTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMwTN</gml:identifier>
<oid>DENIAL430001iuMwTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102385.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102385.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550556.676 5804542.962 550563.136 5804524.782 550569.331 5804507.346 550576.598 5804486.894 550583.348 5804482.858 550602.577 5804471.361 550619.208 5804499.075 550611.211 5804512.026 550606.01 5804520.451 550606.807 5804520.736 550606.971 5804521.941 550603.678 5804524.179 550598.832 5804537.358 550579.784 5804530.76 550573.216 5804548.824 550556.676 5804542.962</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMxTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMxTN</gml:identifier>
<oid>DENIAL430001iuMxTN</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157102386.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157102386.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550651.697 5804491.544 550668.763 5804480.027 550673.925 5804476.543 550673.304 5804475.515 550652.701 5804441.392 550668.148 5804432.156 550680.927 5804424.515 550697.729 5804414.469 550709.661 5804432.568 550716.821 5804443.43 550726.728 5804458.458 550739.386 5804477.659 550724.718 5804488.013 550720.065 5804491.298 550708.456 5804499.698 550703.862 5804503.022 550692.425 5804511.607 550687.872 5804515.025 550676.51 5804523.75 550652.307 5804492.337 550651.697 5804491.544</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004Y2OTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004Y2OTN</gml:identifier>
<oid>DENIAL4300004Y2OTN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329711.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329711.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550640.089 5804578.438 550640.341 5804576.451 550640.827 5804574.521 550641.588 5804572.681 550642.587 5804570.94 550643.845 5804569.376 550645.264 5804568.029 550649.867 5804564.147 550666.951 5804550.287 550679.654 5804540.311 550682.573 5804538.019 550692.857 5804530.099 550696.876 5804527.035 550712.679 5804515.186 550725.659 5804505.748 550728.83 5804503.443 550747.382 5804490.371 550767.483 5804522.12 550776.004 5804536.143 550766.232 5804541.389 550765.539 5804539.985 550760.484 5804530.076 550754.754 5804532.998 550759.809 5804542.908 550760.552 5804544.437 550759.284 5804545.118 550758.274 5804545.635 550741.63 5804554.156 550723.938 5804563.034 550714.893 5804567.389 550703.254 5804572.977 550691.937 5804578.478 550686.478 5804580.992 550682.832 5804582.638 550660.837 5804592.205 550658.981 5804592.938 550657.059 5804593.47 550655.081 5804593.681 550653.085 5804593.582 550651.105 5804593.199 550649.207 5804592.611 550647.395 5804591.756 550645.75 5804590.645 550644.254 5804589.324 550642.96 5804587.795 550641.875 5804586.106 550641.022 5804584.302 550640.417 5804582.402 550640.131 5804580.423 550640.089 5804578.438</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Sport-, Freizeit- und Erholungsfläche</nutzart>
<bez>Spielplatz, Bolzplatz</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005bAhTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005bAhTN</gml:identifier>
<oid>DENIAL4300005bAhTN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329712.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329712.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550754.754 5804532.998 550760.484 5804530.076 550765.539 5804539.985 550766.232 5804541.389 550760.552 5804544.437 550759.809 5804542.908 550754.754 5804532.998</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Industrie- und Gewerbefläche</nutzart>
<bez>Gebäude- und Freifläche Versorgungsanlage, Elektrizität</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009Bt1TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Bt1TN</gml:identifier>
<oid>DENIAL4300009Bt1TN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329714.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329714.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550695.541 5804411.808 550699.156 5804410.833 550699.694 5804411.594 550743.532 5804478.243 550741.93 5804481.704 550739.386 5804477.659 550726.728 5804458.458 550716.821 5804443.43 550709.661 5804432.568 550697.729 5804414.469 550695.541 5804411.808</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAgTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAgTN</gml:identifier>
<oid>DENIAL430001LtAgTN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329717.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329717.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550636.844 5804576.773 550637.638 5804572.275 550638.829 5804568.968 550643.988 5804565.131 550670.843 5804542.774 550671.373 5804540.392 550676.664 5804536.291 550679.654 5804540.311 550666.951 5804550.287 550649.867 5804564.147 550645.264 5804568.029 550643.845 5804569.376 550642.587 5804570.94 550641.588 5804572.681 550640.827 5804574.521 550640.341 5804576.451 550640.089 5804578.438 550640.131 5804580.423 550640.417 5804582.402 550641.022 5804584.302 550641.875 5804586.106 550642.96 5804587.795 550644.254 5804589.324 550645.75 5804590.645 550647.395 5804591.756 550649.207 5804592.611 550651.105 5804593.199 550653.085 5804593.582 550655.081 5804593.681 550657.059 5804593.47 550658.981 5804592.938 550660.837 5804592.205 550682.832 5804582.638 550686.478 5804580.992 550691.937 5804578.478 550703.254 5804572.977 550714.893 5804567.389 550716.22 5804570.687 550696.243 5804579.815 550664.626 5804593.838 550658.54 5804596.22 550654.307 5804597.278 550649.941 5804597.013 550646.766 5804595.69 550643.988 5804593.838 550641.871 5804591.589 550639.49 5804588.547 550637.903 5804584.975 550637.109 5804580.874 550636.844 5804576.773</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAiTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAiTN</gml:identifier>
<oid>DENIAL430001LtAiTN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329718.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329718.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550676.664 5804536.291 550720.056 5804503.88 550725.659 5804505.748 550712.679 5804515.186 550696.876 5804527.035 550692.857 5804530.099 550682.573 5804538.019 550679.654 5804540.311 550676.664 5804536.291</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAjTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAjTN</gml:identifier>
<oid>DENIAL430001LtAjTN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329719.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329719.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550714.893 5804567.389 550723.938 5804563.034 550741.63 5804554.156 550758.274 5804545.635 550758.818 5804551.108 550716.22 5804570.687 550714.893 5804567.389</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAlTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAlTN</gml:identifier>
<oid>DENIAL430001LtAlTN</oid>
<aktualit>2026-07-28Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157329720.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157329720.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550720.056 5804503.88 550725.745 5804499.382 550741.752 5804488.269 550745.098 5804486.741 550747.382 5804490.371 550728.83 5804503.443 550725.659 5804505.748 550720.056 5804503.88</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAfTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAfTN</gml:identifier>
<oid>DENIAL430001LtAfTN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330435.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330435.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550623.039 5804568.931 550623.341 5804566.768 550625.653 5804564.835 550640.636 5804552.308 550656.157 5804539.695 550671.996 5804527.217 550676.51 5804523.75 550687.872 5804515.025 550692.425 5804511.607 550703.862 5804503.022 550708.456 5804499.698 550720.065 5804491.298 550724.718 5804488.013 550739.386 5804477.659 550741.93 5804481.704 550739.371 5804482.978 550735.402 5804484.83 550732.624 5804485.491 550668.198 5804533.778 550631.685 5804563.147 550629.568 5804566.189 550626.658 5804568.835 550623.039 5804568.931</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzATN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzATN</gml:identifier>
<oid>DENIAL430001LtzATN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330436.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330436.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550552.626 5804554.278 550553.352 5804552.249 550622.067 5804575.91 550621.591 5804579.323 550611.611 5804575.731 550595.275 5804569.852 550594.719 5804569.652 550565.873 5804559.225 550563.051 5804558.171 550552.626 5804554.278</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzBTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzBTN</gml:identifier>
<oid>DENIAL430001LtzBTN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330437.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330437.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550555.827 5804545.334 550556.676 5804542.962 550573.216 5804548.824 550623.341 5804566.768 550623.039 5804568.931 550555.827 5804545.334</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzNTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzNTN</gml:identifier>
<oid>DENIAL430001LtzNTN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330438.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330438.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550554.016 5804540.803 550572.493 5804488.333 550576.598 5804486.894 550569.331 5804507.346 550563.136 5804524.782 550556.676 5804542.962 550555.827 5804545.334 550554.281 5804543.316 550554.016 5804540.803</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzuTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzuTN</gml:identifier>
<oid>DENIAL430001LtzuTN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330439.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330439.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550553.352 5804552.249 550555.827 5804545.334 550623.039 5804568.931 550622.067 5804575.91 550553.352 5804552.249</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzvTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzvTN</gml:identifier>
<oid>DENIAL430001LtzvTN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330440.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330440.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550519.224 5804538.818 550521.208 5804532.6 550541.713 5804539.215 550543.301 5804539.744 550545.285 5804538.95 550546.211 5804537.231 550546.793 5804535.008 550561.24 5804495.162 550561.471 5804492.197 550572.493 5804488.333 550554.016 5804540.803 550554.281 5804543.316 550555.827 5804545.334 550553.352 5804552.249 550551.238 5804551.386 550540.771 5804579.096 550535.085 5804595.008 550529.698 5804586.073 550543.301 5804547.682 550540.258 5804545.433 550519.224 5804538.818</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMvTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMvTN</gml:identifier>
<oid>DENIAL430001iuMvTN</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157330445.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157330445.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550539.134 5804596.942 550545.045 5804580.58 550543.521 5804579.991 550547.475 5804568.859 550552.626 5804554.278 550563.051 5804558.171 550565.873 5804559.225 550594.719 5804569.652 550595.275 5804569.852 550611.611 5804575.731 550621.591 5804579.323 550625.372 5804586.715 550634.71 5804604.971 550617.2 5804613.963 550615.396 5804614.89 550601.259 5804622.307 550589.513 5804628.471 550574.913 5804619.17 550562.273 5804611.128 550555.627 5804606.884 550553.083 5804605.259 550542.434 5804598.519 550539.134 5804596.942</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL43000058POTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000058POTN</gml:identifier>
<oid>DENIAL43000058POTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157331443.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157331443.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550619.766 5804629.521 550631.385 5804623.55 550640.13 5804619.071 550657.987 5804610.214 550665.827 5804606.426 550675.293 5804602.252 550675.41501117 5804602.25642289 550675.80075048 5804602.29286442 550676.16167822 5804602.35854067 550676.49659775 5804602.4480517 550676.8052343 5804602.55646364 550677.08801771 5804602.67939585 550677.34588766 5804602.81305052 550677.5801288 5804602.95420169 550677.80514171 5804603.1096422 550678.03304172 5804603.28970349 550678.26141689 5804603.49688352 550678.48719218 5804603.73360105 550678.70655156 5804604.00204988 550678.91488493 5804604.30400916 550679.10677814 5804604.64060953 550679.161 5804604.75 550686.392 5804601.666 550706.509 5804642.552 550686.82 5804652.337 550687.13 5804652.963 550670.923 5804660.839 550654.818 5804668.665 550649.598 5804671.202 550646.903 5804664.237 550640.41 5804647.456 550628.345 5804652.016 550619.766 5804629.521</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Fläche besonderer funktionaler Prägung</nutzart>
<bez>Bildung und Wissenschaft</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAcTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAcTN</gml:identifier>
<oid>DENIAL430001LtAcTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157331495.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157331495.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550589.513 5804628.471 550601.259 5804622.307 550615.396 5804614.89 550617.2 5804613.963 550634.71 5804604.971 550625.372 5804586.715 550621.591 5804579.323 550622.067 5804575.91 550636.844 5804602.702 550637.638 5804605.083 550636.58 5804606.935 550592.523 5804630.267 550589.513 5804628.471</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtzzTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtzzTN</gml:identifier>
<oid>DENIAL430001LtzzTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157331499.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157331499.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550535.085 5804595.008 550540.771 5804579.096 550551.238 5804551.386 550553.352 5804552.249 550552.626 5804554.278 550547.475 5804568.859 550543.521 5804579.991 550545.045 5804580.58 550539.134 5804596.942 550542.434 5804598.519 550553.083 5804605.259 550555.627 5804606.884 550562.273 5804611.128 550574.913 5804619.17 550589.513 5804628.471 550592.523 5804630.267 550588.965 5804631.741 550586.452 5804630.418 550537.768 5804599.991 550535.085 5804595.008</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMsTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMsTN</gml:identifier>
<oid>DENIAL430001iuMsTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157331500.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157331500.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550604.612 5804637.479 550619.766 5804629.521 550628.345 5804652.016 550640.41 5804647.456 550646.903 5804664.237 550649.598 5804671.202 550654.818 5804668.665 550670.923 5804660.839 550687.13 5804652.963 550686.82 5804652.337 550706.509 5804642.552 550712.442 5804654.552 550719.969 5804669.78 550700.244 5804679.525 550685.53 5804686.795 550667.947 5804695.482 550651.808 5804703.456 550633.383 5804712.559 550625.354 5804691.608 550618.917 5804674.809 550612.48 5804658.011 550604.612 5804637.479</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XVRTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XVRTN</gml:identifier>
<oid>DENIAL4300004XVRTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332403.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332403.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550692.973 5804594.319 550695.442 5804593.211 550700.989 5804604.413 550709.641 5804621.889 550717.411 5804637.581 550723.623 5804650.127 550730.723 5804664.466 550727.999 5804665.812 550692.973 5804594.319</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XVWTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XVWTN</gml:identifier>
<oid>DENIAL4300004XVWTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332404.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332404.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550675.293 5804602.252 550687.324 5804596.853 550722.477 5804668.541 550719.969 5804669.78 550712.442 5804654.552 550706.509 5804642.552 550686.392 5804601.666 550679.161 5804604.75 550679.10677814 5804604.64060953 550678.91488493 5804604.30400916 550678.70655156 5804604.00204988 550678.48719218 5804603.73360105 550678.26141689 5804603.49688352 550678.03304172 5804603.28970349 550677.80514171 5804603.1096422 550677.5801288 5804602.95420169 550677.34588766 5804602.81305052 550677.08801771 5804602.67939585 550676.8052343 5804602.55646364 550676.49659775 5804602.4480517 550676.16167822 5804602.35854067 550675.80075048 5804602.29286442 550675.41501117 5804602.25642289 550675.293 5804602.252</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jCoTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jCoTN</gml:identifier>
<oid>DENIAL4300005jCoTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332490.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332490.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550687.324 5804596.853 550692.973 5804594.319 550727.999 5804665.812 550722.477 5804668.541 550687.324 5804596.853</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BmqTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BmqTN</gml:identifier>
<oid>DENIAL4300009BmqTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332494.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332494.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550745.098 5804486.741 550751.301 5804487.62 550779.96 5804534.052 550778.295 5804539.912 550776.004 5804536.143 550767.483 5804522.12 550747.382 5804490.371 550745.098 5804486.741</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAdTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAdTN</gml:identifier>
<oid>DENIAL430001LtAdTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332512.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332512.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550599.868 5804634.649 550602.845 5804632.865 550604.565 5804633.526 550622.028 5804624.266 550685.263 5804595.426 550687.324 5804596.853 550675.293 5804602.252 550665.827 5804606.426 550657.987 5804610.214 550640.13 5804619.071 550631.385 5804623.55 550619.766 5804629.521 550604.612 5804637.479 550599.868 5804634.649</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAeTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAeTN</gml:identifier>
<oid>DENIAL430001LtAeTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332513.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332513.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550692.275 5804591.722 550692.672 5804590.002 550694.788 5804587.885 550697.566 5804586.43 550700.344 5804587.621 550720.85 5804577.566 550777.868 5804549.388 550777.074 5804547.139 550779.587 5804545.684 550781.659 5804545.446 550783.792 5804548.956 550766.167 5804558.411 550750.584 5804566.403 550748.386 5804567.53 550734.515 5804574.504 550730.496 5804576.525 550718.364 5804582.376 550712.486 5804585.21 550695.442 5804593.211 550692.973 5804594.319 550692.275 5804591.722</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAhTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAhTN</gml:identifier>
<oid>DENIAL430001LtAhTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332514.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332514.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550758.274 5804545.635 550759.284 5804545.118 550760.552 5804544.437 550766.232 5804541.389 550776.004 5804536.143 550778.295 5804539.912 550758.818 5804551.108 550758.274 5804545.635</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtAkTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtAkTN</gml:identifier>
<oid>DENIAL430001LtAkTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332515.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332515.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550592.523 5804630.267 550636.58 5804606.935 550637.638 5804605.083 550636.844 5804602.702 550622.067 5804575.91 550623.039 5804568.931 550626.658 5804568.835 550629.568 5804566.189 550631.685 5804563.147 550668.198 5804533.778 550732.624 5804485.491 550735.402 5804484.83 550739.371 5804482.978 550741.93 5804481.704 550745.098 5804486.741 550741.752 5804488.269 550725.745 5804499.382 550720.056 5804503.88 550676.664 5804536.291 550671.373 5804540.392 550670.843 5804542.774 550643.988 5804565.131 550638.829 5804568.968 550637.638 5804572.275 550636.844 5804576.773 550637.109 5804580.874 550637.903 5804584.975 550639.49 5804588.547 550641.871 5804591.589 550643.988 5804593.838 550646.766 5804595.69 550649.941 5804597.013 550654.307 5804597.278 550658.54 5804596.22 550664.626 5804593.838 550696.243 5804579.815 550716.22 5804570.687 550758.818 5804551.108 550778.295 5804539.912 550781.659 5804545.446 550779.587 5804545.684 550777.074 5804547.139 550777.868 5804549.388 550720.85 5804577.566 550700.344 5804587.621 550697.566 5804586.43 550694.788 5804587.885 550692.672 5804590.002 550692.275 5804591.722 550692.973 5804594.319 550687.324 5804596.853 550685.263 5804595.426 550622.028 5804624.266 550604.565 5804633.526 550602.845 5804632.865 550599.868 5804634.649 550592.523 5804630.267</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMrTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMrTN</gml:identifier>
<oid>DENIAL430001iuMrTN</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157332516.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157332516.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550695.442 5804593.211 550712.486 5804585.21 550718.364 5804582.376 550730.496 5804576.525 550734.515 5804574.504 550748.386 5804567.53 550750.584 5804566.403 550766.167 5804558.411 550783.792 5804548.956 550788.729 5804557.246 550792.662 5804564.015 550799.534 5804575.841 550803.452 5804582.584 550807.97 5804591.742 550813.404 5804602.756 550821.677 5804619.522 550801.97 5804629.26 550785.095 5804637.599 550768.219 5804645.937 550751.335 5804654.281 550730.723 5804664.466 550723.623 5804650.127 550717.411 5804637.581 550709.641 5804621.889 550700.989 5804604.413 550695.442 5804593.211</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BhHTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BhHTN</gml:identifier>
<oid>DENIAL4300009BhHTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333776.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333776.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550757.29 5804480.176 550758.965 5804476.055 550761.213 5804479.689 550782.261 5804512.867 550786.149 5804519.219 550790.862 5804527.034 550793.575 5804531.448 550789.355 5804531.215 550757.29 5804480.176</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001k0BNTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001k0BNTN</gml:identifier>
<oid>DENIAL430001k0BNTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333929.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333929.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550798.715 5804539.811 550820.025 5804526.686 550841.335 5804513.562 550851.364 5804529.894 550864.186 5804550.775 550865.568 5804553.024 550867.517 5804556.265 550869.42 5804559.545 550871.27 5804562.855 550873.063 5804566.185 550874.814 5804569.53 550876.214 5804572.313 550876.515 5804572.911 550884.604 5804590.451 550861.92 5804600.718 550839.237 5804610.986 550830.034 5804594.295 550822.385 5804580.421 550819.41 5804575.275 550808.409 5804556.244 550802.734 5804546.426 550798.715 5804539.811</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001k0BOTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001k0BOTN</gml:identifier>
<oid>DENIAL430001k0BOTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333930.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333930.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550852.409 5804506.742 550873.949 5804493.475 550895.482 5804480.214 550905.68 5804497.323 550912.79 5804509.251 550920.064 5804521.453 550927.338 5804533.655 550934.447 5804545.583 550944.646 5804562.692 550947.233 5804567.031 550925.187 5804577.018 550923.332 5804572.921 550911.649 5804578.209 550896.442 5804585.092 550889.344 5804569.575 550887.342 5804565.464 550887.023 5804564.807 550884.586 5804560.102 550882.07 5804555.471 550879.951 5804551.789 550879.427 5804550.879 550876.715 5804546.33 550871.879 5804538.453 550863.723 5804525.169 550858.557 5804516.756 550852.409 5804506.742</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZaBTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZaBTN</gml:identifier>
<oid>DENIALP10000cZaBTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333932.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333932.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550790.862 5804527.034 550887.819 5804467.356 550890.478 5804471.817 550793.575 5804531.448 550790.862 5804527.034</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZaCTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZaCTN</gml:identifier>
<oid>DENIALP10000cZaCTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333933.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333933.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550796.374 5804536.001 550799.407 5804535.362 550839.889 5804511.153 550842.005 5804510.624 550844.052 5804511.889 550841.335 5804513.562 550820.025 5804526.686 550798.715 5804539.811 550796.374 5804536.001</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZatTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZatTN</gml:identifier>
<oid>DENIALP10000cZatTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333934.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333934.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550793.575 5804531.448 550890.478 5804471.817 550893.795 5804477.383 550850.208 5804504.141 550849.149 5804506.258 550850.168 5804508.122 550877.989 5804552.692 550893.572 5804586.391 550888.009 5804588.909 550878.65 5804570.949 550866.479 5804548.856 550844.052 5804511.889 550842.005 5804510.624 550839.889 5804511.153 550799.407 5804535.362 550796.374 5804536.001 550793.575 5804531.448</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZauTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZauTN</gml:identifier>
<oid>DENIALP10000cZauTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333935.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333935.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550841.335 5804513.562 550844.052 5804511.889 550866.479 5804548.856 550878.65 5804570.949 550888.009 5804588.909 550884.604 5804590.451 550876.515 5804572.911 550876.214 5804572.313 550874.814 5804569.53 550873.063 5804566.185 550871.27 5804562.855 550869.42 5804559.545 550867.517 5804556.265 550865.568 5804553.024 550864.186 5804550.775 550851.364 5804529.894 550841.335 5804513.562</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZavTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZavTN</gml:identifier>
<oid>DENIALP10000cZavTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333936.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333936.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550850.168 5804508.122 550852.409 5804506.742 550858.557 5804516.756 550863.723 5804525.169 550871.879 5804538.453 550876.715 5804546.33 550879.427 5804550.879 550879.951 5804551.789 550882.07 5804555.471 550884.586 5804560.102 550887.023 5804564.807 550887.342 5804565.464 550889.344 5804569.575 550896.442 5804585.092 550893.572 5804586.391 550877.989 5804552.692 550850.168 5804508.122</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZawTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZawTN</gml:identifier>
<oid>DENIALP10000cZawTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333937.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333937.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550849.149 5804506.258 550850.208 5804504.141 550893.795 5804477.383 550895.482 5804480.214 550873.949 5804493.475 550852.409 5804506.742 550850.168 5804508.122 550849.149 5804506.258</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZaxTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZaxTN</gml:identifier>
<oid>DENIALP10000cZaxTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333938.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333938.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550862.799 5804419.158 550868.63 5804416.183 550873.873 5804425.12 550875.579 5804425.438 550956.264 5804560.375 550955.669 5804561.963 550957.475 5804565.131 550951.055 5804566.322 550897.918 5804479.124 550896.225 5804477.748 550893.795 5804477.383 550890.478 5804471.817 550890.933 5804468.858 550889.769 5804465.578 550862.799 5804419.158</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZayTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZayTN</gml:identifier>
<oid>DENIALP10000cZayTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333939.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333939.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550859.937 5804420.618 550862.799 5804419.158 550889.769 5804465.578 550890.933 5804468.858 550890.478 5804471.817 550887.819 5804467.356 550859.937 5804420.618</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000cZazTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000cZazTN</gml:identifier>
<oid>DENIALP10000cZazTN</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.157333940.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.157333940.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550868.63 5804416.183 550872.392 5804414.263 550883.69 5804433.256 550889.342 5804442.756 550896.506 5804454.759 550909.339 5804476.258 550916.942 5804488.971 550924.556 5804501.701 550932.955 5804515.804 550941.16 5804529.579 550949.914 5804544.145 550961.99 5804564.294 550957.475 5804565.131 550955.669 5804561.963 550956.264 5804560.375 550875.579 5804425.438 550873.873 5804425.12 550868.63 5804416.183</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtnrTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtnrTN</gml:identifier>
<oid>DENIAL430001LtnrTN</oid>
<aktualit>2026-08-26Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.158272565.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.158272565.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550408.99 5804483.556 550430.146 5804445.911 550431.099 5804443.53 550431.099 5804441.718 550429.885 5804440.407 550434.708 5804431.783 550436.02 5804432.047 550436.893 5804431.73 550437.687 5804430.46 550457.134 5804395.217 550476.978 5804359.419 550479.041 5804357.355 550494.043 5804331.003 550520.078 5804283.854 550529.423 5804267.32 550538.485 5804272.409 550507.508 5804327.867 550487.806 5804363.164 550470.334 5804394.451 550457.946 5804416.643 550454.184 5804418.964 550450.268 5804424.784 550446.67 5804431.769 550446.458 5804433.674 550447.471 5804436.196 550442.273 5804448.348 550440.822 5804448.398 550439.433 5804448.928 550437.515 5804451.11 550429.247 5804465.861 550417.297 5804489.27 550408.99 5804483.556</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL43000052m0TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052m0TN</gml:identifier>
<oid>DENIAL43000052m0TN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159277692.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159277692.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550365.658 5804576.601 550370.577 5804570.043 550372.364 5804567.539 550376.385 5804561.907 550381.459 5804554.487 550382.765 5804552.508 550387.515 5804545.312 550392.814 5804536.833 550393.734 5804535.299 550397.951 5804528.266 550400.832 5804523.235 550402.917 5804519.592 550409.014 5804508.345 550417.137 5804512.726 550425.778 5804517.719 550428.407 5804519.396 550434.212 5804523.099 550440.075 5804527.17 550454.557 5804538.236 550458.518 5804541.284 550468.799 5804550.948 550472.233 5804554.257 550479.458 5804562.064 550489.475 5804572.887 550499.492 5804583.709 550510.018 5804595.082 550518.846 5804604.621 550513.128 5804620.643 550507.081 5804637.587 550502.714 5804649.822 550497.233 5804665.181 550483.728 5804671.468 550479.796 5804673.263 550474.638 5804675.619 550465.514 5804679.697 550461.057 5804681.663 550456.37 5804683.729 550447.162 5804687.692 550434.511 5804693.125 550429.065 5804680.658 550426.973 5804675.693 550422.848 5804665.901 550418.536 5804656.807 550417.233 5804654.059 550412.63 5804645.133 550409.061 5804638.665 550403.003 5804628.12 550445.785 5804599.923 550453.02 5804584.333 550449.845 5804582.889 550435.28 5804576.262 550427.898 5804572.903 550422.509 5804583.838 550408.79 5804587.996 550417.247 5804600.161 550422.025 5804592.853 550424.464 5804594.413 550426.733 5804593.313 550432.771 5804596.122 550433.771 5804599.261 550433.091 5804602.33 550430.682 5804605.528 550427.973 5804607.997 550417.837 5804615.005 550405.852 5804623.292 550401.754 5804626.12 550397.465 5804619.183 550395.868 5804616.764 550391.969 5804610.858 550386.24 5804602.661 550384.576 5804600.412 550380.285 5804594.611 550374.105 5804586.709 550365.658 5804576.601</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtENTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtENTN</gml:identifier>
<oid>DENIAL430001LtENTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159277866.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159277866.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550416.071 5804495.989 550419.172 5804490.56 550420.328 5804494.594 550425.989 5804497.637 550430.71 5804500.37 550434.687 5804502.673 550443.923 5804508.579 550456.851 5804517.896 550468.55 5804527.129 550469.55 5804528.019 550477.506 5804535.114 550479.578 5804537.094 550484.755 5804542.074 550492.794 5804550.716 550501.998 5804560.656 550516.787 5804576.629 550519.808 5804579.892 550527.541 5804582.495 550529.698 5804586.073 550527.582 5804588.482 550525.862 5804589.408 550523.481 5804589.937 550521.761 5804589.54 550519.512 5804588.217 550515.808 5804584.248 550516.337 5804582.264 550487.498 5804549.323 550471.623 5804533.713 550454.557 5804519.293 550426.246 5804501.037 550422.41 5804499.714 550416.071 5804495.989</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMuTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMuTN</gml:identifier>
<oid>DENIAL430001iuMuTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159277990.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159277990.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550443.49 5804713.177 550448.037 5804711.029 550444.007 5804702.188 550448.114 5804700.333 550452.131 5804698.617 550459.068 5804695.623 550461.308 5804694.657 550470.451 5804690.625 550477.44 5804687.501 550479.575 5804686.547 550488.665 5804682.396 550492.624 5804680.564 550503.419 5804684.33 550510.9 5804699.468 550519.532 5804716.936 550530.377 5804738.882 550538.787 5804755.902 550515.28 5804767.518 550496.905 5804776.598 550484.091 5804782.929 550482.447 5804782.37 550480.81 5804779.031 550476.358 5804781.257 550468.475 5804765.295 550462.535 5804753.265 550459.421 5804746.914 550458.147 5804744.289 550453.805 5804735.292 550450.558 5804728.425 550449.534 5804726.259 550444.114 5804714.563 550443.49 5804713.177</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XUoTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XUoTN</gml:identifier>
<oid>DENIAL4300004XUoTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278589.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278589.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550547.288 5804751.713 550554.024 5804748.394 550564.687 5804743.125 550581.721 5804734.709 550595.582 5804727.86 550613.915 5804718.802 550617.934 5804717.513 550619.33 5804721.099 550619.644 5804724.698 550618.158 5804727.279 550614.09 5804729.94 550606.343 5804733.828 550600.919 5804731.833 550553.502 5804755.47 550547.288 5804751.713</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtELTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtELTN</gml:identifier>
<oid>DENIAL430001LtELTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278705.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278705.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550410.988 5804504.888 550416.071 5804495.989 550422.41 5804499.714 550426.246 5804501.037 550454.557 5804519.293 550471.623 5804533.713 550487.498 5804549.323 550516.337 5804582.264 550515.808 5804584.248 550519.512 5804588.217 550521.761 5804589.54 550523.481 5804589.937 550525.862 5804589.408 550527.582 5804588.482 550529.698 5804586.073 550535.085 5804595.008 550537.768 5804599.991 550586.452 5804630.418 550588.965 5804631.741 550592.523 5804630.267 550599.868 5804634.649 550598.623 5804636.874 550597.353 5804639.414 550597.194 5804642.113 550597.988 5804644.97 550601.004 5804647.193 550625.928 5804708.947 550628.164 5804714.233 550617.934 5804717.513 550589.256 5804650.05 550586.875 5804644.018 550584.494 5804641.954 550537.98 5804612.903 550534.805 5804611.474 550531.346 5804612.316 550522.701 5804606.994 550522.74 5804604.171 550520.041 5804600.679 550516.549 5804597.663 550497.658 5804577.978 550483.053 5804560.991 550470.035 5804547.339 550455.112 5804534.797 550440.666 5804523.367 550410.988 5804504.888</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtEMTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtEMTN</gml:identifier>
<oid>DENIAL430001LtEMTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278706.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278706.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550409.014 5804508.345 550410.988 5804504.888 550440.666 5804523.367 550455.112 5804534.797 550470.035 5804547.339 550483.053 5804560.991 550497.658 5804577.978 550516.549 5804597.663 550520.041 5804600.679 550522.74 5804604.171 550522.701 5804606.994 550518.846 5804604.621 550510.018 5804595.082 550499.492 5804583.709 550489.475 5804572.887 550479.458 5804562.064 550472.233 5804554.257 550468.799 5804550.948 550458.518 5804541.284 550454.557 5804538.236 550440.075 5804527.17 550434.212 5804523.099 550428.407 5804519.396 550425.778 5804517.719 550417.137 5804512.726 550409.014 5804508.345</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtEPTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtEPTN</gml:identifier>
<oid>DENIAL430001LtEPTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278707.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278707.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550531.346 5804612.316 550534.805 5804611.474 550537.98 5804612.903 550584.494 5804641.954 550586.875 5804644.018 550589.256 5804650.05 550617.934 5804717.513 550613.915 5804718.802 550605.001 5804697.662 550599.017 5804683.358 550593.017 5804669.093 550586.15 5804652.765 550582.849 5804645.004 550567.692 5804635.313 550552.535 5804625.621 550552.114 5804625.352 550541.596 5804618.627 550531.346 5804612.316</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtEQTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtEQTN</gml:identifier>
<oid>DENIAL430001LtEQTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278708.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278708.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550597.194 5804642.113 550597.353 5804639.414 550598.623 5804636.874 550599.868 5804634.649 550604.612 5804637.479 550612.48 5804658.011 550618.917 5804674.809 550625.354 5804691.608 550633.383 5804712.559 550628.164 5804714.233 550625.928 5804708.947 550628.468 5804707.518 550604.814 5804645.764 550601.004 5804647.193 550597.988 5804644.97 550597.194 5804642.113</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtJ5TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtJ5TN</gml:identifier>
<oid>DENIAL430001LtJ5TN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278709.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278709.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550495.597 5804679.165 550508.702 5804672.998 550547.288 5804751.713 550540.875 5804754.873 550505.253 5804682.599 550495.597 5804679.165</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtJ9TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtJ9TN</gml:identifier>
<oid>DENIAL430001LtJ9TN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278710.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278710.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550435.57 5804695.491 550492.712 5804670.322 550496.31 5804669.264 550498.427 5804667.782 550499.909 5804665.242 550509.01 5804640.265 550519.17 5804611.373 550521.075 5804610.738 550521.922 5804609.679 550522.701 5804606.994 550531.346 5804612.316 550528.166 5804612.643 550527.319 5804614.23 550528.06 5804615.288 550513.349 5804655.188 550508.481 5804670.428 550508.702 5804672.998 550495.597 5804679.165 550492.394 5804678.471 550438.355 5804701.71 550435.57 5804695.491</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtXWTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtXWTN</gml:identifier>
<oid>DENIAL430001LtXWTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278711.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278711.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550434.511 5804693.125 550447.162 5804687.692 550456.37 5804683.729 550461.057 5804681.663 550465.514 5804679.697 550474.638 5804675.619 550479.796 5804673.263 550483.728 5804671.468 550497.233 5804665.181 550502.714 5804649.822 550507.081 5804637.587 550513.128 5804620.643 550518.846 5804604.621 550522.701 5804606.994 550521.922 5804609.679 550521.075 5804610.738 550519.17 5804611.373 550509.01 5804640.265 550499.909 5804665.242 550498.427 5804667.782 550496.31 5804669.264 550492.712 5804670.322 550435.57 5804695.491 550434.511 5804693.125</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtXXTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtXXTN</gml:identifier>
<oid>DENIAL430001LtXXTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278712.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278712.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550508.481 5804670.428 550513.349 5804655.188 550528.06 5804615.288 550527.319 5804614.23 550528.166 5804612.643 550531.346 5804612.316 550541.596 5804618.627 550541.196 5804618.754 550539.4 5804618.037 550536.069 5804619.197 550535.46 5804617.631 550534.721 5804616.828 550534.013 5804616.426 550533.228 5804616.229 550530.256 5804617.225 550525.41 5804630.815 550522.222 5804639.755 550521.551 5804641.638 550516.517 5804655.755 550510.705 5804672.055 550508.702 5804672.998 550508.481 5804670.428</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtXYTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtXYTN</gml:identifier>
<oid>DENIAL430001LtXYTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278713.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278713.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550508.702 5804672.998 550510.705 5804672.055 550518.863 5804688.554 550527.941 5804706.916 550537.029 5804725.295 550547.321 5804746.111 550547.38785369 5804746.19473589 550547.70619697 5804746.55825102 550548.03540016 5804746.88305958 550548.37083891 5804747.17078973 550548.7085368 5804747.42350129 550549.0451521 5804747.64353547 550549.37794055 5804747.83338897 550549.70470283 5804747.99561283 550550.02372411 5804748.13273461 550550.333711 5804748.24720114 550550.64912229 5804748.34574133 550550.98551814 5804748.43185054 550551.34336752 5804748.50280114 550551.72285488 5804748.55554434 550552.12379524 5804748.58671702 550552.54553876 5804748.59266646 550552.98686748 5804748.56949847 550553.44588891 5804748.5131543 550553.91993387 5804748.41952166 550554.024 5804748.394 550547.288 5804751.713 550508.702 5804672.998</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtXZTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtXZTN</gml:identifier>
<oid>DENIAL430001LtXZTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278714.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278714.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550492.624 5804680.564 550495.597 5804679.165 550505.253 5804682.599 550540.875 5804754.873 550538.787 5804755.902 550530.377 5804738.882 550519.532 5804716.936 550510.9 5804699.468 550503.419 5804684.33 550492.624 5804680.564</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001LtY0TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001LtY0TN</gml:identifier>
<oid>DENIAL430001LtY0TN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278715.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278715.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550438.355 5804701.71 550492.394 5804678.471 550495.597 5804679.165 550492.624 5804680.564 550488.665 5804682.396 550479.575 5804686.547 550477.44 5804687.501 550470.451 5804690.625 550461.308 5804694.657 550459.068 5804695.623 550452.131 5804698.617 550448.114 5804700.333 550444.007 5804702.188 550448.037 5804711.029 550443.49 5804713.177 550438.355 5804701.71</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Rad- und Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMtTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMtTN</gml:identifier>
<oid>DENIAL430001iuMtTN</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159278716.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159278716.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550510.705 5804672.055 550516.517 5804655.755 550521.551 5804641.638 550522.222 5804639.755 550525.41 5804630.815 550530.256 5804617.225 550533.228 5804616.229 550534.013 5804616.426 550534.721 5804616.828 550535.46 5804617.631 550536.069 5804619.197 550539.4 5804618.037 550541.196 5804618.754 550541.596 5804618.627 550552.114 5804625.352 550552.535 5804625.621 550567.692 5804635.313 550582.849 5804645.004 550586.15 5804652.765 550593.017 5804669.093 550599.017 5804683.358 550605.001 5804697.662 550613.915 5804718.802 550595.582 5804727.86 550581.721 5804734.709 550564.687 5804743.125 550554.024 5804748.394 550553.91993387 5804748.41952166 550553.44588891 5804748.5131543 550552.98686748 5804748.56949847 550552.54553876 5804748.59266646 550552.12379524 5804748.58671702 550551.72285488 5804748.55554434 550551.34336752 5804748.50280114 550550.98551814 5804748.43185054 550550.64912229 5804748.34574133 550550.333711 5804748.24720114 550550.02372411 5804748.13273461 550549.70470283 5804747.99561283 550549.37794055 5804747.83338897 550549.0451521 5804747.64353547 550548.7085368 5804747.42350129 550548.37083891 5804747.17078973 550548.03540016 5804746.88305958 550547.70619697 5804746.55825102 550547.38785369 5804746.19473589 550547.321 5804746.111 550537.029 5804725.295 550527.941 5804706.916 550518.863 5804688.554 550510.705 5804672.055</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XUMTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XUMTN</gml:identifier>
<oid>DENIAL4300004XUMTN</oid>
<aktualit>2026-09-24Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.159283682.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.159283682.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550476.566 5804787.779 550484.091 5804782.929 550496.905 5804776.598 550515.28 5804767.518 550538.787 5804755.902 550540.875 5804754.873 550540.927 5804761.739 550481.69 5804791.27 550476.566 5804787.779</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001hQlcTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001hQlcTN</gml:identifier>
<oid>DENIAL430001hQlcTN</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160008164.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160008164.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550565.901 5804783.756 550565.89439008 5804783.74026102 550565.73096653 5804783.29449386 550565.61237372 5804782.85596412 550565.53445463 5804782.42948634 550565.49274585 5804782.0187576 550565.48271826 5804781.62644814 550565.49996067 5804781.25432673 550565.5403095 5804780.90340139 550565.59993145 5804780.57406079 550565.67536793 5804780.26620693 550565.76355048 5804779.97937321 550565.86775393 5804779.69796356 550565.99485146 5804779.40760021 550566.14756392 5804779.10977658 550566.32869806 5804778.80651589 550566.54106267 5804778.50045558 550566.78735263 5804778.19492567 550567.06999733 5804777.89401091 550567.39097224 5804777.60258376 550567.75157681 5804777.32629237 550568.15218826 5804777.07148641 550568.167 5804777.063 550594.154 5804764.223 550615.822 5804753.518 550627.472 5804747.762 550640.593 5804773.041 550650.031 5804791.225 550659.469 5804809.408 550624.084 5804827.812 550616.395 5804811.993 550615.051 5804809.332 550608.117 5804795.607 550609.161 5804795.07 550607.432 5804791.515 550607.029 5804790.688 550599.62 5804793.218 550594.704 5804783.474 550582.878 5804782.605 550568.78 5804789.58 550565.901 5804783.756</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XVATN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XVATN</gml:identifier>
<oid>DENIAL4300004XVATN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503224.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503224.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550673.777 5804793.56 550760.501 5804751.772 550761.634 5804754.063 550738.154 5804765.386 550725.468 5804771.504 550712.782 5804777.621 550694.776 5804786.304 550674.969 5804795.856 550673.777 5804793.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XViTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XViTN</gml:identifier>
<oid>DENIAL4300004XViTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503225.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503225.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550669.44 5804785.206 550678.624 5804780.773 550695.55 5804772.604 550714.907 5804763.261 550734.254 5804753.922 550756.303 5804743.28 550757.435 5804745.569 550670.742 5804787.714 550669.44 5804785.206</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XWMTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XWMTN</gml:identifier>
<oid>DENIAL4300004XWMTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503226.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503226.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550628.164 5804714.233 550633.383 5804712.559 550635.563 5804717.411 550637.096 5804720.822 550630.448 5804719.553 550628.164 5804714.233</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XWnTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XWnTN</gml:identifier>
<oid>DENIAL4300004XWnTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503227.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503227.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550633.383 5804712.559 550651.808 5804703.456 550667.947 5804695.482 550685.53 5804686.795 550700.244 5804679.525 550719.969 5804669.78 550722.477 5804668.541 550724.462 5804672.605 550635.563 5804717.411 550633.383 5804712.559</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XXyTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XXyTN</gml:identifier>
<oid>DENIAL4300004XXyTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503228.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503228.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550637.392 5804733.86 550640.221 5804727.778 550641.832 5804731.365 550644.027 5804736.25 550640.039 5804739.023 550637.392 5804733.86</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004Y00TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004Y00TN</gml:identifier>
<oid>DENIAL4300004Y00TN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503241.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503241.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550561.33 5804771.627 550619.62 5804742.812 550617.72 5804738.371 550626.237 5804739.541 550628.583 5804742.48 550630.645 5804745.556 550627.472 5804747.762 550615.822 5804753.518 550594.154 5804764.223 550568.167 5804777.063 550561.596 5804780.309 550561.33 5804771.627</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004Y0nTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004Y0nTN</gml:identifier>
<oid>DENIAL4300004Y0nTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503242.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503242.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550640.039 5804739.023 550644.027 5804736.25 550655.619 5804758.58 550669.44 5804785.206 550670.742 5804787.714 550665.433 5804787.43 550640.039 5804739.023</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jA4TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jA4TN</gml:identifier>
<oid>DENIAL4300005jA4TN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503348.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503348.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550670.742 5804787.714 550757.435 5804745.569 550760.501 5804751.772 550673.777 5804793.56 550670.742 5804787.714</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jBUTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jBUTN</gml:identifier>
<oid>DENIAL4300005jBUTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503349.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503349.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550635.563 5804717.411 550724.462 5804672.605 550723.835 5804677.342 550637.096 5804720.822 550635.563 5804717.411</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jCaTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jCaTN</gml:identifier>
<oid>DENIAL4300005jCaTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503350.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503350.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550340.17 5804867.387 550344.716 5804865.11 550397.115 5804838.816 550397.333 5804833.322 550397.505 5804829.033 550403.978 5804825.837 550407.539 5804828.234 550411.874 5804831.41 550467.575 5804803.46 550467.896 5804798.146 550468.238 5804793.146 550476.566 5804787.779 550481.69 5804791.27 550486.002 5804794.213 550540.951 5804766.641 550540.927 5804761.739 550540.875 5804754.873 550547.288 5804751.713 550553.502 5804755.47 550557.972 5804758.099 550606.343 5804733.828 550614.09 5804729.94 550618.158 5804727.279 550619.644 5804724.698 550619.33 5804721.099 550617.934 5804717.513 550628.164 5804714.233 550630.448 5804719.553 550637.096 5804720.822 550640.221 5804727.778 550637.392 5804733.86 550640.039 5804739.023 550630.645 5804745.556 550628.583 5804742.48 550626.237 5804739.541 550617.72 5804738.371 550561.141 5804766.416 550561.33 5804771.627 550561.596 5804780.309 550555.483 5804783.329 550550.39 5804777.035 550547.347 5804773.253 550488.614 5804802.366 550489.471 5804807.151 550490.846 5804814.841 550481.989 5804817.211 550477.45 5804813.094 550473.757 5804809.73 550413.633 5804839.532 550414.608 5804844.16 550415.631 5804849.066 550409.286 5804852.201 550405.201 5804848.81 550401.351 5804845.62 550355.62 5804868.286 550352.927 5804874.652 550344.751 5804878.693 550340.17 5804867.387</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jzMTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jzMTN</gml:identifier>
<oid>DENIAL4300005jzMTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503351.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503351.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550640.221 5804727.778 550727.274 5804684.057 550731.348 5804686.652 550641.832 5804731.365 550640.221 5804727.778</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMnTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMnTN</gml:identifier>
<oid>DENIAL430001iuMnTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503359.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503359.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550674.969 5804795.856 550694.776 5804786.304 550712.782 5804777.621 550725.468 5804771.504 550738.154 5804765.386 550761.634 5804754.063 550771.36 5804773.738 550765.94 5804789.849 550759.563 5804808.802 550755.182 5804821.824 550739.87 5804829.77 550722.128 5804838.978 550707.056 5804846.801 550702.612 5804849.107 550693.513 5804831.579 550684.068 5804813.385 550674.969 5804795.856</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMpTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMpTN</gml:identifier>
<oid>DENIAL430001iuMpTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160503360.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160503360.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550644.027 5804736.25 550653.002 5804731.817 550670.941 5804722.957 550687.079 5804714.986 550703.217 5804707.015 550731.476 5804693.058 550737.472 5804705.186 550743.01 5804716.39 550756.303 5804743.28 550734.254 5804753.922 550714.907 5804763.261 550695.55 5804772.604 550678.624 5804780.773 550669.44 5804785.206 550655.619 5804758.58 550644.027 5804736.25</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XULTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XULTN</gml:identifier>
<oid>DENIAL4300004XULTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160504586.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160504586.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550627.472 5804747.762 550630.645 5804745.556 550716.11 5804910.057 550711.641 5804909.922 550702.051 5804891.446 550690.776 5804869.724 550680.178 5804849.305 550668.907 5804827.591 550659.469 5804809.408 550650.031 5804791.225 550640.593 5804773.041 550627.472 5804747.762</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jCDTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jCDTN</gml:identifier>
<oid>DENIAL4300005jCDTN</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160504707.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160504707.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550630.645 5804745.556 550640.039 5804739.023 550665.433 5804787.43 550670.742 5804787.714 550673.777 5804793.56 550670.927 5804797.918 550698.653 5804850.858 550703.536 5804850.886 550707.078 5804857.71 550704.452 5804861.93 550730.06 5804910.478 550716.11 5804910.057 550630.645 5804745.556</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XV7TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XV7TN</gml:identifier>
<oid>DENIAL4300004XV7TN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505424.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505424.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550736.858 5804683.9 550830.328 5804637.22 550833.097 5804642.884 550821.924 5804648.384 550800.365 5804659.033 550789.169 5804664.563 550778.026 5804670.066 550759.317 5804679.307 550742.227 5804687.748 550739.422 5804689.133 550736.858 5804683.9</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XVrTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XVrTN</gml:identifier>
<oid>DENIAL4300004XVrTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505425.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505425.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550739.422 5804689.133 550742.227 5804687.748 550752.422 5804708.382 550753.972 5804711.519 550761.5 5804726.755 550770.578 5804745.128 550779.71 5804763.609 550786.659 5804765.954 550781.775 5804768.439 550776.809 5804765.452 550739.422 5804689.133</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XWOTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XWOTN</gml:identifier>
<oid>DENIAL4300004XWOTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505426.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505426.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550760.501 5804751.772 550763.825 5804752.9 550773.597 5804772.6 550771.36 5804773.738 550761.634 5804754.063 550760.501 5804751.772</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XXGTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XXGTN</gml:identifier>
<oid>DENIAL4300004XXGTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505427.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505427.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550772.229 5804810.8 550783.543 5804777.194 550875.411 5804736.781 550876.811 5804740.016 550863.98 5804745.558 550841.494 5804755.269 550820.266 5804764.438 550818.55 5804765.179 550798.396 5804773.884 550786.437 5804779.049 550780.489 5804796.735 550775.614 5804811.228 550774.307 5804814.441 550772.229 5804810.8</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XXeTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XXeTN</gml:identifier>
<oid>DENIAL4300004XXeTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505428.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505428.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550641.832 5804731.365 550731.348 5804686.652 550733.981 5804691.821 550731.476 5804693.058 550703.217 5804707.015 550687.079 5804714.986 550670.941 5804722.957 550653.002 5804731.817 550644.027 5804736.25 550641.832 5804731.365</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XXvTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XXvTN</gml:identifier>
<oid>DENIAL4300004XXvTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505429.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505429.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550727.999 5804665.812 550730.723 5804664.466 550751.335 5804654.281 550768.219 5804645.937 550785.095 5804637.599 550801.97 5804629.26 550821.677 5804619.522 550823.285 5804622.812 550729.967 5804669.832 550727.999 5804665.812</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XYUTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XYUTN</gml:identifier>
<oid>DENIAL4300004XYUTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505430.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505430.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550731.476 5804693.058 550733.981 5804691.821 550758.64 5804742.322 550757.435 5804745.569 550756.303 5804743.28 550743.01 5804716.39 550737.472 5804705.186 550731.476 5804693.058</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300004XZeTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300004XZeTN</gml:identifier>
<oid>DENIAL4300004XZeTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505434.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505434.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550781.775 5804768.439 550786.659 5804765.954 550825.137 5804749.305 550825.825 5804749.007 550837.523 5804743.946 550860.001 5804734.22 550872.048 5804729.008 550873.259 5804731.806 550787.491 5804768.699 550785.459 5804769.418 550781.775 5804768.439</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jADTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jADTN</gml:identifier>
<oid>DENIAL4300005jADTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505606.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505606.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550733.981 5804691.821 550739.422 5804689.133 550776.809 5804765.452 550781.775 5804768.439 550773.597 5804772.6 550763.825 5804752.9 550760.501 5804751.772 550757.435 5804745.569 550758.64 5804742.322 550733.981 5804691.821</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jALTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jALTN</gml:identifier>
<oid>DENIAL4300005jALTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505607.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505607.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550637.096 5804720.822 550723.835 5804677.342 550724.462 5804672.605 550722.477 5804668.541 550727.999 5804665.812 550729.967 5804669.832 550734.043 5804672.226 550825.127 5804626.581 550828.402 5804633.279 550736.878 5804679.234 550736.858 5804683.9 550739.422 5804689.133 550733.981 5804691.821 550731.348 5804686.652 550727.274 5804684.057 550640.221 5804727.778 550637.096 5804720.822</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jBbTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jBbTN</gml:identifier>
<oid>DENIAL4300005jBbTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505609.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505609.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550729.967 5804669.832 550823.285 5804622.812 550825.127 5804626.581 550734.043 5804672.226 550729.967 5804669.832</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jBuTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jBuTN</gml:identifier>
<oid>DENIAL4300005jBuTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505610.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505610.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550703.536 5804850.886 550757.298 5804823.465 550773.138 5804777.381 550773.597 5804772.6 550781.775 5804768.439 550785.459 5804769.418 550787.491 5804768.699 550873.259 5804731.806 550875.411 5804736.781 550783.543 5804777.194 550772.229 5804810.8 550774.307 5804814.441 550769.834 5804825.425 550767.031 5804824.749 550765.749 5804826.781 550707.078 5804857.71 550703.536 5804850.886</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300005jzBTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005jzBTN</gml:identifier>
<oid>DENIAL4300005jzBTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505611.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505611.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550736.858 5804683.9 550736.878 5804679.234 550828.402 5804633.279 550830.328 5804637.22 550736.858 5804683.9</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
<bez>Begleitfläche Straßenverkehr</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009Be1TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Be1TN</gml:identifier>
<oid>DENIAL4300009Be1TN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505629.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505629.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550844.674 5804632.199 550847.308 5804628.055 550848.609 5804630.806 550857.35 5804651.001 550866.58 5804672.324 550875.817 5804693.7 550884.128 5804712.935 550892.333 5804731.922 550900.827 5804751.58 550910.186 5804773.07 550908.836 5804775.852 550905.054 5804773.502 550844.674 5804632.199</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BecTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BecTN</gml:identifier>
<oid>DENIAL4300009BecTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505630.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505630.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550781.659 5804545.446 550786.274 5804545.035 550827.484 5804623.375 550825.127 5804626.581 550823.285 5804622.812 550821.677 5804619.522 550813.404 5804602.756 550807.97 5804591.742 550803.452 5804582.584 550799.534 5804575.841 550792.662 5804564.015 550788.729 5804557.246 550783.792 5804548.956 550781.659 5804545.446</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BfkTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BfkTN</gml:identifier>
<oid>DENIAL4300009BfkTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505631.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505631.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550839.237 5804610.986 550861.92 5804600.718 550884.604 5804590.451 550888.009 5804588.909 550888.964 5804591.701 550888.964 5804593.468 550888.525 5804595.382 550887.05 5804596.852 550884.399 5804598.034 550842.4 5804617.675 550839.237 5804610.986</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BkFTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BkFTN</gml:identifier>
<oid>DENIAL4300009BkFTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505632.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505632.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550847.308 5804628.055 550853.486 5804624.09 550949.895 5804580.572 550952.184 5804579.582 550954.522 5804578.523 550956.019 5804578.335 550957.138 5804578.585 550957.949 5804579.146 550958.573 5804580.018 550958.946 5804580.852 550954.434 5804582.932 550935.972 5804591.33 550915.489 5804600.647 550899.937 5804607.671 550884.394 5804614.69 550865.016 5804623.417 550848.609 5804630.806 550847.308 5804628.055</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009Bq5TN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Bq5TN</gml:identifier>
<oid>DENIAL4300009Bq5TN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505634.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505634.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550828.402 5804633.279 550833.043 5804636.123 550875.504 5804727.702 550873.259 5804731.806 550872.048 5804729.008 550859.718 5804700.511 550852.41 5804683.621 550849.508 5804676.913 550846.218 5804669.31 550845.829 5804668.411 550834.233 5804645.153 550833.097 5804642.884 550830.328 5804637.22 550828.402 5804633.279</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL4300009BujTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009BujTN</gml:identifier>
<oid>DENIAL4300009BujTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505635.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505635.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550795.017 5804539.348 550796.374 5804536.001 550798.715 5804539.811 550802.734 5804546.426 550808.409 5804556.244 550819.41 5804575.275 550822.385 5804580.421 550830.034 5804594.295 550839.237 5804610.986 550842.4 5804617.675 550838.201 5804617.871 550822.533 5804588.646 550795.017 5804539.348</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Weg</nutzart>
<bez>Fußweg</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001hQlbTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001hQlbTN</gml:identifier>
<oid>DENIAL430001hQlbTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505820.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505820.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550770.578 5804745.128 550795.669 5804732.896 550786.764 5804714.623 550779.229 5804699.162 550777.649 5804696.207 550786.468 5804691.748 550798.439 5804685.874 550800.913 5804691.564 550806.981 5804705.514 550812.245 5804717.697 550812.743 5804718.864 550811.957 5804719.121 550825.137 5804749.305 550786.659 5804765.954 550779.71 5804763.609 550770.578 5804745.128</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Industrie- und Gewerbefläche</nutzart>
<bez>Handel und Dienstleistung</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMoTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMoTN</gml:identifier>
<oid>DENIAL430001iuMoTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505821.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505821.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550775.614 5804811.228 550780.489 5804796.735 550786.437 5804779.049 550798.396 5804773.884 550818.55 5804765.179 550820.266 5804764.438 550841.494 5804755.269 550863.98 5804745.558 550876.811 5804740.016 550889.571 5804769.508 550900.101 5804793.847 550896.965 5804799.079 550887.647 5804814.625 550878.399 5804830.054 550865.812 5804851.054 550856.297 5804866.929 550831.963 5804852.347 550813.623 5804841.357 550810.622 5804839.559 550792.299 5804828.579 550781.153 5804821.899 550775.614 5804811.228</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001iuMqTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001iuMqTN</gml:identifier>
<oid>DENIAL430001iuMqTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505822.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505822.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550742.227 5804687.748 550759.317 5804679.307 550778.026 5804670.066 550789.169 5804664.563 550800.365 5804659.033 550821.924 5804648.384 550833.097 5804642.884 550834.233 5804645.153 550845.829 5804668.411 550846.218 5804669.31 550849.508 5804676.913 550852.41 5804683.621 550859.718 5804700.511 550872.048 5804729.008 550860.001 5804734.22 550837.523 5804743.946 550825.825 5804749.007 550825.137 5804749.305 550811.957 5804719.121 550812.743 5804718.864 550812.245 5804717.697 550806.981 5804705.514 550800.913 5804691.564 550798.439 5804685.874 550786.468 5804691.748 550777.649 5804696.207 550779.229 5804699.162 550786.764 5804714.623 550795.669 5804732.896 550770.578 5804745.128 550761.5 5804726.755 550753.972 5804711.519 550752.422 5804708.382 550742.227 5804687.748</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001jZLPTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLPTN</gml:identifier>
<oid>DENIAL430001jZLPTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505824.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505824.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550848.609 5804630.806 550865.016 5804623.417 550869.859 5804634.344 550871.801 5804633.678 550874.881 5804640.374 550879.033 5804638.683 550880.129 5804641.259 550857.35 5804651.001 550848.609 5804630.806</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Industrie- und Gewerbefläche</nutzart>
<bez>Handel und Dienstleistung</bez>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001jZLVTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLVTN</gml:identifier>
<oid>DENIAL430001jZLVTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505829.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505829.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550857.35 5804651.001 550880.129 5804641.259 550879.033 5804638.683 550874.881 5804640.374 550871.801 5804633.678 550869.859 5804634.344 550865.016 5804623.417 550884.394 5804614.69 550899.937 5804607.671 550915.489 5804600.647 550935.972 5804591.33 550942.997 5804607.638 550921.605 5804613.745 550927.188 5804626.366 550911.86 5804633.299 550896.067 5804640.572 550903.023 5804656.634 550912.909 5804677.647 550875.817 5804693.7 550866.58 5804672.324 550857.35 5804651.001</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Wohnbaufläche</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIALP10000in6gTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIALP10000in6gTN</gml:identifier>
<oid>DENIALP10000in6gTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160505896.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160505896.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550538.485 5804272.409 550544.527 5804262.09 550627.817 5804309.143 550631.416 5804311.09 550633.343 5804310.667 550634.867 5804309.476 550640.515 5804312.374 550640.263 5804317.479 550699.634 5804396.25 550706.093 5804396.546 550710.371 5804402.265 550708.903 5804406.967 550750.892 5804471.264 550755.849 5804471.02 550758.965 5804476.055 550757.29 5804480.176 550789.355 5804531.215 550793.575 5804531.448 550796.374 5804536.001 550795.017 5804539.348 550822.533 5804588.646 550838.201 5804617.871 550842.4 5804617.675 550847.308 5804628.055 550844.674 5804632.199 550905.054 5804773.502 550908.836 5804775.852 550903.823 5804786.179 550899.154 5804783.286 550879.421 5804737.298 550875.411 5804736.781 550873.259 5804731.806 550875.504 5804727.702 550833.043 5804636.123 550828.402 5804633.279 550825.127 5804626.581 550827.484 5804623.375 550786.274 5804545.035 550781.659 5804545.446 550778.295 5804539.912 550779.96 5804534.052 550751.301 5804487.62 550745.098 5804486.741 550741.93 5804481.704 550743.532 5804478.243 550699.694 5804411.594 550699.156 5804410.833 550695.541 5804411.808 550690.018 5804404.262 550691.731 5804400.326 550648.482 5804339.805 550644.456 5804337.572 550635.708 5804337.496 550626.516 5804323.409 550627.552 5804321.578 550627.552 5804319.885 550626.441 5804318.192 550542.462 5804271.466 550540.398 5804271.625 550538.485 5804272.409</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
<wfs:member>
<Nutzung gml:id="DENIAL430001jZLTTN">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLTTN</gml:identifier>
<oid>DENIAL430001jZLTTN</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="tn.id_tn.160506392.position.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="tn.id_tn.160506392.position.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550842.4 5804617.675 550884.399 5804598.034 550887.05 5804596.852 550888.525 5804595.382 550888.964 5804593.468 550888.964 5804591.701 550888.009 5804588.909 550893.572 5804586.391 550894.412 5804587.873 550895.589 5804589.051 550897.209 5804590.08 550900.154 5804590.378 550902.805 5804589.641 550950.215 5804569.138 550950.798 5804568.679 550951.283 5804567.708 550951.214 5804566.944 550951.055 5804566.322 550957.475 5804565.131 550958.294 5804566.249 550959.196 5804566.806 550960.237 5804567.151 550961.417 5804567.151 550963.34 5804566.716 550999.176 5804550.209 551002.224 5804557.242 550965.365 5804574.099 550964.119 5804574.722 550963.185 5804575.593 550962.811 5804576.093 550962.561 5804577.028 550962.623 5804577.526 550962.978 5804578.995 550958.946 5804580.852 550958.573 5804580.018 550957.949 5804579.146 550957.138 5804578.585 550956.019 5804578.335 550954.522 5804578.523 550952.184 5804579.582 550950.535 5804575.634 550948.236 5804576.613 550949.895 5804580.572 550853.486 5804624.09 550847.308 5804628.055 550842.4 5804617.675</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<nutzart>Straßenverkehr</nutzart>
</Nutzung>
</wfs:member>
</wfs:FeatureCollection>