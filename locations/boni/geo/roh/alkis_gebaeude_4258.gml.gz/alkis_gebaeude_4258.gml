<?xml version='1.0' encoding='utf-8'?><wfs:FeatureCollection xmlns="http://repository.gdi-de.org/schemas/adv/produkt/alkis-vereinfacht/2.0" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:wfs="http://www.opengis.net/wfs/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" timeStamp="2026-11-27T11:53:28.650+01:00" numberReturned="265" numberMatched="unknown" xsi:schemaLocation="http://repository.gdi-de.org/schemas/adv/produkt/alkis-vereinfacht/2.0 http://download.lgln.niedersachsen.de/aaa-suite/schema/AAA-vereinfacht/2.0/schema/ALKIS-vereinfacht.xsd http://www.opengis.net/wfs/2.0 http://download.lgln.niedersachsen.de/aaa-suite/schema/ogc/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://download.lgln.niedersachsen.de/aaa-suite/schema/ogc/gml/3.2.1/gml.xsd">
<wfs:boundedBy>
<gml:Envelope srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:lowerCorner>52.386976738469 9.74139211123921</gml:lowerCorner>
<gml:upperCorner>52.3909976219431 9.74798790879994</gml:upperCorner>
</gml:Envelope>
</wfs:boundedBy>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053jNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053jNBL</gml:identifier>
<oid>DENIAL43000053jNBL</oid>
<aktualit>2017-01-23Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41345557.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41345557.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886941409303 9.74580246017237 52.3886673421118 9.74588620764218 52.3887559513803 9.74596198180503 52.3887827592421 9.74587823436601 52.3886941409303 9.74580246017237</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude zur Versorgung</funktion>
<gfkzshh>31001_2500</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 19</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300012aFjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300012aFjBL</gml:identifier>
<oid>DENIAL4300012aFjBL</oid>
<aktualit>2012-07-05Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41722413.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41722413.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872503334363 9.74479224966102 52.3872236909833 9.7448684155625 52.3872414005191 9.74488583212525 52.3872685497727 9.74481484701302 52.3872503334363 9.74479224966102</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8MBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8MBL</gml:identifier>
<oid>DENIAL430001fU8MBL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767081.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767081.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886678375056 9.74159640964687 52.3885823640944 9.74169388524909 52.3886782783297 9.74187392750143 52.3887564023046 9.74175994450511 52.3887387939109 9.74172920241355 52.3886757460786 9.74161123662815 52.3886678375056 9.74159640964687</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 30</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8OBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8OBL</gml:identifier>
<oid>DENIAL430001fU8OBL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767082.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767082.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3887564023046 9.74175994450511 52.3886782783297 9.74187392750143 52.3887654378604 9.7420220836702 52.3888776400906 9.74195617942203 52.388800693218 9.74183676028346 52.3887564023046 9.74175994450511</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8SBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8SBL</gml:identifier>
<oid>DENIAL430001fU8SBL</oid>
<aktualit>2017-03-06Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767085.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767085.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886050358695 9.74189197863274 52.3885904234518 9.74190817668987 52.3885639598067 9.74193753324427 52.3885652615439 9.74194069967264 52.3886937323568 9.74225356780658 52.3887615582704 9.74221472187657 52.3887449108322 9.74213834002004 52.388741635797 9.74214016598391 52.3887395551228 9.7421307560214 52.3887176546004 9.74214356964605 52.3887196639102 9.74215289024087 52.3887157027127 9.74215517491695 52.3887139521792 9.74215618886338 52.3886050358695 9.74189197863274</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8TBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8TBL</gml:identifier>
<oid>DENIAL430001fU8TBL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767086.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767086.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.388697462935 9.74253279550037 52.3885588917943 9.74261146577416 52.3885941448536 9.74277728138134 52.3887332050839 9.74269948674662 52.388697462935 9.74253279550037</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8VBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8VBL</gml:identifier>
<oid>DENIAL430001fU8VBL</oid>
<aktualit>2017-03-06Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767087.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767087.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3884911434722 9.74174872390737 52.3883885878936 9.74181038152789 52.3884158340557 9.74193854690763 52.3884670025771 9.74190794419316 52.3885346768035 9.74186746430894 52.3884911434722 9.74174872390737</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Ulrichstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU90BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU90BL</gml:identifier>
<oid>DENIAL430001fU90BL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767090.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767090.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3888067740183 9.742188589387 52.388771081607 9.74220862176881 52.3887923206909 9.74230973805746 52.3888382083733 9.74228398428095 52.3888383568602 9.74228467741303 52.3888460077264 9.74228039740628 52.3888367542327 9.74223636442249 52.3888067740183 9.742188589387</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TDTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TDTBL</gml:identifier>
<oid>DENIAL4300009TDTBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336650.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336650.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871578196836 9.74705486702739 52.3871326230269 9.74712253334716 52.3871002610992 9.74719442800768 52.3870995772205 9.74719594462833 52.3871260580083 9.74722240000771 52.3871165471253 9.74724782153896 52.387104870163 9.74723616310206 52.3870966122148 9.74725822617402 52.3870793067276 9.7472409477849 52.3870270668746 9.74735688215575 52.387063806004 9.74739326759709 52.3870568638028 9.74741198793745 52.3870605270571 9.74741560573442 52.3870920215105 9.74744680387692 52.3870990185838 9.74742793751476 52.3871277970111 9.74745643021623 52.3871535081446 9.74738705359085 52.387141115837 9.74737478057454 52.387153024752 9.74734264034311 52.3871507478691 9.74729180494641 52.3871689945677 9.74728961510821 52.3871946415303 9.74731570384956 52.3872027439161 9.74732393704871 52.3872648942238 9.74716203043626 52.3872560316112 9.74715316727265 52.3871578196836 9.74705486702739</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TOIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TOIBL</gml:identifier>
<oid>DENIAL4300009TOIBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336652.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336652.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3873918045062 9.74742377243594 52.3873916120086 9.74742435694536 52.3873622368662 9.74751297995706 52.3873312557689 9.74760674800798 52.3874190740735 9.74768231892212 52.3874737055928 9.74751380493692 52.3873918045062 9.74742377243594</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bürgerstraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009Uz8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Uz8BL</gml:identifier>
<oid>DENIAL4300009Uz8BL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336668.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336668.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872648942238 9.74716203043626 52.3872027439161 9.74732393704871 52.3872129901504 9.74733436646807 52.3872401199941 9.74736196439619 52.3872411753829 9.74738131948252 52.3872106429453 9.74740272720354 52.3872010972075 9.7474322330755 52.3871860662359 9.74741923954463 52.3871631876209 9.74748995711462 52.3871901803544 9.74751790544576 52.3871835632688 9.74753497089573 52.3872151738803 9.74756769934515 52.3872183894151 9.74757103041937 52.3872257834443 9.74755195031934 52.3872516328345 9.74757871858938 52.3872634046148 9.74754836868094 52.3872964810382 9.74746304108484 52.387280983956 9.74744698329406 52.3872893923472 9.74742530475009 52.3872812820939 9.74741689505539 52.3872915551067 9.74739038428895 52.3873151715331 9.74741483722101 52.3873248047762 9.74738997605016 52.3873717273371 9.74726896988 52.3872744625564 9.74717161083006 52.3872648942238 9.74716203043626</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 20</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009Vg0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Vg0BL</gml:identifier>
<oid>DENIAL4300009Vg0BL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336679.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336679.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3873717273371 9.74726896988 52.3873248047762 9.74738997605016 52.3873685953178 9.74742875843768 52.3873749469022 9.74740960186678 52.3873916120086 9.74742435694536 52.3873918045062 9.74742377243594 52.3874737055928 9.74751380493692 52.3875009847005 9.74742964268144 52.3874933283758 9.74739067698402 52.3873717273371 9.74726896988</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 22</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HZMxBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HZMxBL</gml:identifier>
<oid>DENIAL430001HZMxBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336833.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336833.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872648942238 9.74716203043626 52.3872027439161 9.74732393704871 52.3872129901504 9.74733436646807 52.3872744625564 9.74717161083006 52.3872648942238 9.74716203043626</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HZMyBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HZMyBL</gml:identifier>
<oid>DENIAL430001HZMyBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336834.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336834.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872560316112 9.74715316727265 52.3871946415303 9.74731570384956 52.3872027439161 9.74732393704871 52.3872648942238 9.74716203043626 52.3872560316112 9.74715316727265</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TJDBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TJDBL</gml:identifier>
<oid>DENIAL4300009TJDBL</oid>
<aktualit>2026-04-08Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153337988.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153337988.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3876298280245 9.74752353945312 52.3876070471052 9.74753330824193 52.3876080863216 9.74753673482609 52.3875555939545 9.74769823228266 52.387555996256 9.74769859173788 52.387632058184 9.74776652934759 52.3876620844782 9.7476830158218 52.3876771599699 9.74769749444158 52.3876719252624 9.74771205602262 52.3876992613356 9.74773830609766 52.3876896593456 9.74776816393081 52.3877450925088 9.74782116197147 52.3877855328489 9.74768175136714 52.387629816573 9.74752677196112 52.3876298280245 9.74752353945312</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 24</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052AzBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052AzBL</gml:identifier>
<oid>DENIAL43000052AzBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848823.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848823.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3873062112249 9.74237091580612 52.3871339095542 9.7425251327901 52.3871379602897 9.74253722039315 52.3871299587077 9.74254437431818 52.3872238118661 9.74282472293199 52.3872311625199 9.74281814587454 52.3872350894943 9.74282989349266 52.3874077258337 9.74267541846837 52.3874038427768 9.74266383318933 52.3874112567182 9.74265719836479 52.387317391503 9.74237727484082 52.3873104296413 9.74238350585077 52.3873062112249 9.74237091580612</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1D</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052LwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052LwBL</gml:identifier>
<oid>DENIAL43000052LwBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848825.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848825.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3875281572125 9.74176144139262 52.3874872631098 9.74179806409713 52.3874938820422 9.74181782099215 52.3875347671614 9.74178119814985 52.3875281572125 9.74176144139262</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052UIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052UIBL</gml:identifier>
<oid>DENIAL43000052UIBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848827.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848827.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877129229269 9.74141164451207 52.3875394907798 9.74156712606346 52.3875436741528 9.74157958326367 52.38753616973 9.74158631963009 52.3875795573406 9.74171541417966 52.387586194358 9.74173515671263 52.3876302085406 9.74186609882154 52.3876377943466 9.74185929038217 52.3876421364585 9.7418722352044 52.3877232650438 9.74179952223666 52.3877344673431 9.7417894829108 52.3878147188147 9.74171756311847 52.3878105004203 9.74170495830003 52.387817471328 9.7416987125714 52.3877243273606 9.74142097533216 52.3877233477605 9.74141804948285 52.3877169916628 9.74142374716683 52.3877129229269 9.74141164451207</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1G; Spichernstraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052WiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052WiBL</gml:identifier>
<oid>DENIAL43000052WiBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848829.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848829.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3878647774755 9.74186954641371 52.3877852222627 9.74194081644879 52.3877740199509 9.74195085574759 52.3876935062565 9.74202299106707 52.3876978925605 9.7420360542158 52.3876895835175 9.74204349704727 52.3877836184683 9.74232371895057 52.3877907883793 9.74231728563732 52.3877949010473 9.74232953607581 52.3878756770085 9.74225718513598 52.3878867798145 9.74224724708193 52.3879677274502 9.74217475178094 52.387963685484 9.74216269351936 52.3879707919977 9.74215633256197 52.387876840329 9.7418756703987 52.3878691371041 9.74188256506812 52.3878647774755 9.74186954641371</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052meBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052meBL</gml:identifier>
<oid>DENIAL43000052meBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848830.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848830.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872462944994 9.7420163885335 52.3872078142862 9.74205086185099 52.3872139919977 9.74206928880413 52.3872524632266 9.74203481534722 52.3872462944994 9.7420163885335</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oQBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oQBL</gml:identifier>
<oid>DENIAL43000052oQBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848831.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848831.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3874333354699 9.74166231301808 52.3872601922272 9.7418175476634 52.3872642256092 9.74182954678106 52.3872561787527 9.74183675887085 52.3873002896853 9.7419680249915 52.3873064675939 9.74198642258697 52.3873503930822 9.74211712752569 52.3873581054951 9.74211020374302 52.387362253406 9.74212257218499 52.3875353606235 9.74196741124274 52.3875312215018 9.74195507230237 52.3875378397992 9.74194914400936 52.3874938820422 9.74181782099215 52.3874872631098 9.74179806409713 52.3874438965173 9.74166849987937 52.387437368683 9.74167434155382 52.3874333354699 9.74166231301808</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1E</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052saBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052saBL</gml:identifier>
<oid>DENIAL43000052saBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848832.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848832.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877388429403 9.74257748485171 52.3875658177793 9.74273233691992 52.3875698509753 9.74274435089571 52.3875626359085 9.74275081273836 52.3876568534382 9.74303175842625 52.3876641951135 9.74302518118872 52.3876684047468 9.74303772716863 52.3878414403994 9.74288269978308 52.3878373190763 9.74287040505207 52.3878443893923 9.74286408770087 52.3877505292085 9.74258344105723 52.3877430701388 9.74259010457535 52.3877388429403 9.74257748485171</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052uNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052uNBL</gml:identifier>
<oid>DENIAL43000052uNBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848834.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848834.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871523752495 9.74191388108071 52.3869803008431 9.74206779454972 52.3869843603387 9.74207992629702 52.386976738469 9.74208674868835 52.3869887231413 9.74212250885215 52.38707076251 9.74236725984978 52.3870785471314 9.74236029328347 52.3870826686013 9.74237257306361 52.3872552777524 9.74221803755337 52.387251165164 9.7422057725826 52.3872577563207 9.74219987329684 52.3872139919977 9.74206928880413 52.3872078142862 9.74205086185099 52.3871638999246 9.74191980493316 52.3871565583098 9.74192638228116 52.3871523752495 9.74191388108071</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1C</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005307BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005307BL</gml:identifier>
<oid>DENIAL4300005307BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848836.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848836.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3875394907798 9.74156712606346 52.3874333354699 9.74166231301808 52.387437368683 9.74167434155382 52.3874438965173 9.74166849987937 52.3874872631098 9.74179806409713 52.3875281572125 9.74176144139262 52.3875795573406 9.74171541417966 52.38753616973 9.74158631963009 52.3875436741528 9.74157958326367 52.3875394907798 9.74156712606346</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005354BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005354BL</gml:identifier>
<oid>DENIAL4300005354BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848837.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848837.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3878867798145 9.74224724708193 52.3878756770085 9.74225718513598 52.3879004496133 9.742331056884 52.3879115524254 9.74232111884305 52.3878867798145 9.74224724708193</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000535sBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000535sBL</gml:identifier>
<oid>DENIAL430000535sBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848838.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848838.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3879115524254 9.74232111884305 52.3879004496133 9.742331056884 52.3879266517275 9.7424092140137 52.387937763628 9.74239926144478 52.3879115524254 9.74232111884305</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005365BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005365BL</gml:identifier>
<oid>DENIAL4300005365BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848839.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848839.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3875795573406 9.74171541417966 52.3875281572125 9.74176144139262 52.3875347671614 9.74178119814985 52.387586194358 9.74173515671263 52.3875795573406 9.74171541417966</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000539yBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000539yBL</gml:identifier>
<oid>DENIAL430000539yBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848840.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848840.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877344673431 9.7417894829108 52.3877232650438 9.74179952223666 52.3877464051968 9.74186853173406 52.3877576164915 9.74185849257124 52.3877344673431 9.7417894829108</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053CVBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053CVBL</gml:identifier>
<oid>DENIAL43000053CVBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848841.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848841.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877576164915 9.74185849257124 52.3877464051968 9.74186853173406 52.3877740199509 9.74195085574759 52.3877852222627 9.74194081644879 52.3877576164915 9.74185849257124</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053J8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053J8BL</gml:identifier>
<oid>DENIAL43000053J8BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848842.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848842.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3873002896853 9.7419680249915 52.3872462944994 9.7420163885335 52.3872524632266 9.74203481534722 52.3873064675939 9.74198642258697 52.3873002896853 9.7419680249915</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053tjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053tjBL</gml:identifier>
<oid>DENIAL43000053tjBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848844.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848844.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3874586845367 9.7428270492105 52.3872862559637 9.74298133628704 52.3872907568107 9.74299475398957 52.3872831801141 9.74300153294691 52.3873772208679 9.74328190135675 52.3873851773611 9.74327477615596 52.3873894840986 9.7432876028977 52.3875618057442 9.74313322669594 52.3875576227203 9.74312073996034 52.3875645755383 9.7431145235739 52.387470715109 9.74283401041796 52.3874632469432 9.74284068839362 52.3874586845367 9.7428270492105</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053u1BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053u1BL</gml:identifier>
<oid>DENIAL43000053u1BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848845.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848845.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872601922272 9.7418175476634 52.3871523752495 9.74191388108071 52.3871565583098 9.74192638228116 52.3871638999246 9.74191980493316 52.3872078142862 9.74205086185099 52.3872462944994 9.7420163885335 52.3873002896853 9.7419680249915 52.3872561787527 9.74183675887085 52.3872642256092 9.74182954678106 52.3872601922272 9.7418175476634</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053wtBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053wtBL</gml:identifier>
<oid>DENIAL43000053wtBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848846.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848846.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3880180876585 9.74232729956369 52.387937763628 9.74239926144478 52.3879266517275 9.7424092140137 52.3878459660322 9.74248149280277 52.3878502021381 9.74249412739145 52.3878428966352 9.74250067596284 52.3879367624597 9.74278045615456 52.3879439955994 9.74277397987187 52.3879483376102 9.74278692487273 52.3881207763882 9.74263239982098 52.3881164961803 9.74261963215302 52.3881238468222 9.74261305493019 52.3880300694887 9.7423334370303 52.3880224385234 9.74234027407911 52.3880180876585 9.74232729956369</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053xFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053xFBL</gml:identifier>
<oid>DENIAL43000053xFBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848847.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848847.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871783918072 9.74307787185422 52.387006830435 9.74323145155367 52.3870113310692 9.74324489858102 52.3870032751376 9.74325211022083 52.3870972235618 9.74353276971474 52.3871042578624 9.7435264666624 52.3871085380663 9.74353921943169 52.3872804619114 9.74338524992548 52.38727620004 9.74337243865353 52.3872848519723 9.74336481087802 52.3871906353144 9.7430838521662 52.3871827602007 9.74309090526708 52.3871783918072 9.74307787185422</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052J8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052J8BL</gml:identifier>
<oid>DENIAL43000052J8BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100284.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100284.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3875497716456 9.74443992968008 52.3875120972676 9.74454047916048 52.3875320227867 9.74456292897251 52.3875182263013 9.74460082791916 52.3874622084119 9.74453195479676 52.3874391011323 9.74458215757191 52.3874527540039 9.74460131321307 52.3874178320621 9.74467736963595 52.3874904367681 9.74476775492481 52.3875125324118 9.74470974731346 52.3875497732991 9.74474938678825 52.3876343308823 9.74452366853457 52.3875497716456 9.74443992968008</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052JEBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052JEBL</gml:identifier>
<oid>DENIAL43000052JEBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100285.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100285.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3873730739921 9.74440808341761 52.3873709956789 9.74441260359904 52.3873106512174 9.74454390785185 52.3874178320621 9.74467736963595 52.3874527540039 9.74460131321307 52.3874391011323 9.74458215757191 52.3874622084119 9.74453195479676 52.3874664197251 9.74452279779385 52.3873730739921 9.74440808341761</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 68</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052JqBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052JqBL</gml:identifier>
<oid>DENIAL43000052JqBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100286.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100286.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3879344895616 9.74313493014566 52.3878618007704 9.74319930422465 52.3878565686827 9.74318350828526 52.3878231158253 9.74321337805998 52.3878283841446 9.743229130517 52.3877964502138 9.74325764450075 52.3878456468556 9.74340485409748 52.3878999160386 9.74335875910526 52.3879081387839 9.74332216176987 52.3879255058806 9.7433325924908 52.3879211957798 9.74335175478532 52.3879435974077 9.74339080622729 52.387951150218 9.74337925121993 52.3880176466658 9.74327737649383 52.3879344895616 9.74313493014566</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052R9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052R9BL</gml:identifier>
<oid>DENIAL43000052R9BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100287.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100287.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3876195238739 9.74425376813964 52.3875497716456 9.74443992968008 52.3876343308823 9.74452366853457 52.3877034617723 9.74433911267267 52.3876195238739 9.74425376813964</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052rzBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052rzBL</gml:identifier>
<oid>DENIAL43000052rzBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100288.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100288.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3880176466658 9.74327737649383 52.387951150218 9.74337925121993 52.3879640629555 9.74340175925093 52.3879500629442 9.74343919998624 52.3879423972661 9.74343153307615 52.3879208714567 9.74348909593706 52.3879389278155 9.74350714990138 52.3879036579598 9.74360146704059 52.3878886213402 9.74358644671341 52.3878627245705 9.74365567661882 52.3879331185727 9.74372602518667 52.388065540527 9.74337012280991 52.3880685245062 9.74336454504381 52.3880673949031 9.74336117578127 52.3880176466658 9.74327737649383</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 41</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ygBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ygBL</gml:identifier>
<oid>DENIAL43000052ygBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100289.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100289.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3876432451313 9.74339728072863 52.3875268208162 9.74350109273175 52.3875750189883 9.74364547835345 52.3876340354936 9.74382227027955 52.3876752505701 9.74380189170724 52.3876807337286 9.7437934906744 52.3876315923385 9.74364614987442 52.3876112444672 9.74364364789957 52.3876127234114 9.74361149269922 52.3876291813718 9.74361351785798 52.387695340798 9.74355525069213 52.3876432451313 9.74339728072863</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052zWBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052zWBL</gml:identifier>
<oid>DENIAL43000052zWBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100290.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100290.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877964502138 9.74325764450075 52.3877655922292 9.74328519200883 52.3877600417005 9.7432685678733 52.3877332704822 9.74329245168845 52.3877391652274 9.74331009549381 52.3877011828594 9.74334397397252 52.3876952881192 9.74332633017789 52.387669800805 9.74334905996238 52.3876761190045 9.74336798925091 52.3876432451313 9.74339728072863 52.387695340798 9.74355525069213 52.3876967081244 9.74355941740797 52.3877684860439 9.74349695378493 52.3877617402198 9.74347597476843 52.3878381093287 9.74341111943115 52.3878456468556 9.74340485409748 52.3877964502138 9.74325764450075</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005308BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005308BL</gml:identifier>
<oid>DENIAL4300005308BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100291.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100291.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871836223961 9.74384007588021 52.3870473103915 9.74413245610938 52.3871260226208 9.74423100941852 52.3871287476068 9.74422516298161 52.3872333579876 9.74400153159474 52.3872203939804 9.74398290210488 52.3872382268067 9.74394646700431 52.3871836223961 9.74384007588021</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000530BBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000530BBL</gml:identifier>
<oid>DENIAL430000530BBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100292.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100292.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387848920944 9.74364188192923 52.3877577003847 9.74388516798905 52.3878417225994 9.74397001390616 52.3879331185727 9.74372602518667 52.3878627245705 9.74365567661882 52.387848920944 9.74364188192923</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 39</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000534JBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000534JBL</gml:identifier>
<oid>DENIAL430000534JBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100293.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100293.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3874109839691 9.74360439977328 52.3872945952451 9.74370824068009 52.387343056548 9.74385220406592 52.3874591644075 9.7437487260549 52.3874109839691 9.74360439977328</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053DlBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053DlBL</gml:identifier>
<oid>DENIAL43000053DlBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100294.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100294.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871876737343 9.74422627153618 52.3871649297112 9.7442702059571 52.3872021197598 9.74431651494604 52.3871749062623 9.74437490646538 52.3873106512174 9.74454390785185 52.3873709956789 9.74441260359904 52.3872357799392 9.74424662354732 52.3872244129158 9.7442713680243 52.3871876737343 9.74422627153618</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 69</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053dWBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053dWBL</gml:identifier>
<oid>DENIAL43000053dWBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100295.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100295.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3872945952451 9.74370824068009 52.3871727635301 9.74381694141512 52.3871836223961 9.74384007588021 52.3872382268067 9.74394646700431 52.387343056548 9.74385220406592 52.3872945952451 9.74370824068009</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053g0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053g0BL</gml:identifier>
<oid>DENIAL43000053g0BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100296.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100296.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3876883334189 9.74407020571696 52.3876195238739 9.74425376813964 52.3877034617723 9.74433911267267 52.3877725923755 9.74415455623233 52.3876883334189 9.74407020571696</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 35</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053s7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053s7BL</gml:identifier>
<oid>DENIAL43000053s7BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100297.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100297.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877577003847 9.74388516798905 52.3876883334189 9.74407020571696 52.3877725923755 9.74415455623233 52.3878417225994 9.74397001390616 52.3877577003847 9.74388516798905</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 37</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053tfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053tfBL</gml:identifier>
<oid>DENIAL43000053tfBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100298.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100298.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3875268208162 9.74350109273175 52.3874109839691 9.74360439977328 52.3874591644075 9.7437487260549 52.3875750189883 9.74364547835345 52.3875268208162 9.74350109273175</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052BaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052BaBL</gml:identifier>
<oid>DENIAL43000052BaBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100862.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100862.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3883607636941 9.74248889625381 52.3882753281374 9.74253729111432 52.3883548997361 9.74291278817922 52.3884671868492 9.74284919522858 52.3884410750261 9.74272523606502 52.3884165609911 9.7427390340483 52.3884059885459 9.74268888110286 52.3884041253322 9.74269065723627 52.3883607636941 9.74248889625381</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052UNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052UNBL</gml:identifier>
<oid>DENIAL43000052UNBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100865.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100865.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877529814886 9.74139211123921 52.3877245372459 9.74141761389438 52.3877203097375 9.74140502367195 52.3877129229269 9.74141164451207 52.3877169916628 9.74142374716683 52.3877233477605 9.74141804948285 52.3877243273606 9.74142097533216 52.387817471328 9.7416987125714 52.3878105004203 9.74170495830003 52.3878147188147 9.74171756311847 52.3877344673431 9.7417894829108 52.3877576164915 9.74185849257124 52.3877852222627 9.74194081644879 52.3878647774755 9.74186954641371 52.3878691371041 9.74188256506812 52.387876840329 9.7418756703987 52.3879707919977 9.74215633256197 52.387963685484 9.74216269351936 52.3879677274502 9.74217475178094 52.3878867798145 9.74224724708193 52.3879115524254 9.74232111884305 52.387937763628 9.74239926144478 52.3880180876585 9.74232729956369 52.3880224385234 9.74234027407911 52.3880300694887 9.7423334370303 52.3881238468222 9.74261305493019 52.3881164961803 9.74261963215302 52.3881207763882 9.74263239982098 52.3881291396821 9.74262491385579 52.3881247798592 9.74261193913044 52.3881395719609 9.74259863925907 52.3881033142846 9.74249110073921 52.3881152407937 9.74248028016446 52.3878801026196 9.74177129358413 52.3877529814886 9.74139211123921</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052uqBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052uqBL</gml:identifier>
<oid>DENIAL43000052uqBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100868.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100868.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3889661478921 9.74209291199267 52.3888989177528 9.74220870875488 52.3889255846909 9.74225008029226 52.3889290243601 9.74224637619151 52.388949895556 9.7422800828727 52.3889555859252 9.74228161839199 52.3889635372096 9.74229249347959 52.3889668945807 9.74231191719977 52.3889620739504 9.74231934523861 52.3889586752194 9.74231223484593 52.3889507102955 9.7423106905548 52.3889438741997 9.74230691693787 52.3889346882589 9.74232514569223 52.3889278363062 9.74233105549985 52.388922285145 9.74232310080431 52.3888688060993 9.74235367928108 52.3888585258533 9.74230564682501 52.3888445582716 9.74231364143193 52.3888421824831 9.74230255131609 52.3888383568602 9.74228467741303 52.3888382083733 9.74228398428095 52.3887923206909 9.74230973805746 52.3888253053108 9.7424631875582 52.3889773129668 9.74238233187805 52.3891083745454 9.74231261543353 52.3889661478921 9.74209291199267</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 36</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000534fBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000534fBL</gml:identifier>
<oid>DENIAL430000534fBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100869.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100869.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882023288898 9.7416616387802 52.3881018346904 9.74171859921058 52.3881453375175 9.74192385784802 52.3882285687147 9.74187568948501 52.3882457129671 9.74186577907071 52.3882023288898 9.7416616387802</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000539FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000539FBL</gml:identifier>
<oid>DENIAL430000539FBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100872.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100872.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3885301704972 9.74247636844396 52.3884724067644 9.74250919628486 52.3884872523538 9.74257897918647 52.3884962751891 9.74257384062435 52.3885041171945 9.74261069348732 52.3885308717436 9.74263666664335 52.3885267820358 9.74266655987092 52.3885036769909 9.7426478481957 52.3884331394324 9.74268754408484 52.3884410750261 9.74272523606502 52.3884671868492 9.74284919522858 52.3885941448536 9.74277728138134 52.3885588917943 9.74261146577416 52.3885352092848 9.74250005218642 52.3885301704972 9.74247636844396</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000539mBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000539mBL</gml:identifier>
<oid>DENIAL430000539mBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100873.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100873.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882778130995 9.74207715116177 52.3881886914062 9.74212843845727 52.3881967598098 9.7421664850175 52.3882320099033 9.7423328719336 52.3883215458511 9.74228148908859 52.3882860583597 9.74211567097329 52.3882778130995 9.74207715116177</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053BTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053BTBL</gml:identifier>
<oid>DENIAL43000053BTBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100874.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100874.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882285687147 9.74187568948501 52.3881453375175 9.74192385784802 52.3881808064222 9.74209124725497 52.3881886914062 9.74212843845727 52.3882778130995 9.74207715116177 52.3882967707362 9.74206624262237 52.38828891791 9.74202965434627 52.3882717272421 9.74194956130442 52.3882859566059 9.74194139474193 52.3882729576954 9.74188100360794 52.3882345098542 9.74190316455854 52.3882285687147 9.74187568948501</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053EcBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053EcBL</gml:identifier>
<oid>DENIAL43000053EcBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100875.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100875.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3883215458511 9.74228148908859 52.3882320099033 9.7423328719336 52.3882753281374 9.74253729111432 52.3883607636941 9.74248889625381 52.3883653652828 9.74248628440103 52.3883215458511 9.74228148908859</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053pIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053pIBL</gml:identifier>
<oid>DENIAL43000053pIBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100877.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100877.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3881573959332 9.7414549749147 52.3881379395915 9.74146656595586 52.3880584626624 9.74151393094078 52.3881018346904 9.74171859921058 52.3882023288898 9.7416616387802 52.3881614602901 9.74146920829107 52.3881573959332 9.7414549749147</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 12</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rrBL</gml:identifier>
<oid>DENIAL43000053rrBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100878.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100878.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3885859147083 9.74142312678747 52.3884998763274 9.74151609659647 52.3885823640944 9.74169388524909 52.3886678375056 9.74159640964687 52.3885859147083 9.74142312678747</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 28</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7yBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7yBL</gml:identifier>
<oid>DENIAL430001HJ7yBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100946.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100946.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.38828891791 9.74202965434627 52.3881808064222 9.74209124725497 52.3881886914062 9.74212843845727 52.3882778130995 9.74207715116177 52.3882967707362 9.74206624262237 52.38828891791 9.74202965434627</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7zBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7zBL</gml:identifier>
<oid>DENIAL430001HJ7zBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100947.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100947.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882778130995 9.74207715116177 52.3881886914062 9.74212843845727 52.3881967598098 9.7421664850175 52.3882860583597 9.74211567097329 52.3882778130995 9.74207715116177</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001eXF9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001eXF9BL</gml:identifier>
<oid>DENIAL430001eXF9BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100964.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100964.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.388856150064 9.74229455670608 52.3888421824831 9.74230255131609 52.3888445582716 9.74231364143193 52.3888585258533 9.74230564682501 52.388856150064 9.74229455670608</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8PBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8PBL</gml:identifier>
<oid>DENIAL430001fU8PBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100967.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100967.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891083745454 9.74231261543353 52.3889773129668 9.74238233187805 52.388994331483 9.74246831599456 52.389041201872 9.74244356329086 52.3890573999625 9.74252561033896 52.3891601152252 9.74247150916183 52.3891374288835 9.74235749520752 52.3891083745454 9.74231261543353</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8RBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8RBL</gml:identifier>
<oid>DENIAL430001fU8RBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100968.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100968.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3889773129668 9.74238233187805 52.3888253053108 9.7424631875582 52.3888609422648 9.74262946601871 52.3889635501629 9.74257529004353 52.388947307804 9.74249313954686 52.388994331483 9.74246831599456 52.3889773129668 9.74238233187805</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8XBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8XBL</gml:identifier>
<oid>DENIAL430001fU8XBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100969.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100969.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3884670025771 9.74190794419316 52.3884158340557 9.74193854690763 52.3884270382086 9.74199123770473 52.3884705617613 9.74219598416985 52.3885114741163 9.74238841741953 52.3885301704972 9.74247636844396 52.3885352092848 9.74250005218642 52.3886730782564 9.74241865135334 52.3886544098439 9.74233482967388 52.3885832310151 9.74237930581324 52.3885607817599 9.74234921710423 52.3884670025771 9.74190794419316</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8YBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8YBL</gml:identifier>
<oid>DENIAL430001fU8YBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100970.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100970.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3888776400906 9.74195617942203 52.3887654378604 9.7420220836702 52.3887346575412 9.74204017070479 52.3887636706921 9.74217468549045 52.3887976249671 9.74215512354508 52.3887856474223 9.74209961264833 52.388811886884 9.74208449124164 52.3888218285028 9.74208909570152 52.3888989177528 9.74220870875488 52.3889661478921 9.74209291199267 52.3888776400906 9.74195617942203</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 34</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VlsBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VlsBL</gml:identifier>
<oid>DENIAL4300009VlsBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157101905.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157101905.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387275881142 9.74510094460299 52.3871580099592 9.74541545269451 52.3871576182129 9.74541341833213 52.3871314714509 9.74548362631818 52.3871320933104 9.74548481230855 52.3871018400232 9.74556464901424 52.3871089114247 9.74561234707499 52.3871104303897 9.74561384206041 52.3870501858606 9.74577469503853 52.3870553140981 9.74577982147247 52.3870065561902 9.74590981946172 52.3870798332084 9.74598327518368 52.3870959272239 9.74594039044731 52.3870997688323 9.74594424623452 52.3871162011972 9.74590045614449 52.3871123595874 9.74589660035963 52.3871284536644 9.74585370086765 52.3871338855053 9.74585915570353 52.3873782953836 9.74520746670831 52.387275881142 9.74510094460299</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 27</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300012aEXBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300012aEXBL</gml:identifier>
<oid>DENIAL4300012aEXBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157101969.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157101969.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871971739732 9.74486902718551 52.3871402107827 9.74502151710565 52.3871418421417 9.74502128507511 52.3871444437726 9.74502111859268 52.3871470469069 9.74502120114278 52.3871486807495 9.74502138051867 52.3871507289832 9.7450217461382 52.3871534496929 9.74502247686177 52.3871559903105 9.74502341883896 52.3871584928866 9.74502460196604 52.387161090608 9.74502611232677 52.3871629916729 9.74502741086561 52.387215524187 9.74488749779329 52.3871971739732 9.74486902718551</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009UBGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009UBGBL</gml:identifier>
<oid>DENIAL4300009UBGBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102064.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102064.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387579963909 9.74527713313087 52.3875647118132 9.74531771109067 52.3875615670198 9.74531455767465 52.3875269207334 9.74540670836445 52.3875300655244 9.74540986178451 52.3874952728286 9.7455024066077 52.3874919046898 9.74549902901013 52.3874533537162 9.74560157577733 52.3874567217593 9.74560496807217 52.3874248731504 9.74568970089652 52.38742119242 9.74568599475406 52.38738252201 9.74578892122769 52.3873861849433 9.7457925976875 52.3873846395596 9.74579671535484 52.3873720662935 9.74583019681899 52.3873447066085 9.74590308815104 52.3873406684331 9.74589903801059 52.3873056734123 9.7459922398759 52.3873097205741 9.74599629017314 52.3872606706806 9.74612693028179 52.3872571238805 9.74612337331463 52.3872227871578 9.74621480795985 52.387226342852 9.74621837977551 52.3872012415773 9.74628525480775 52.3872692834751 9.74635339212827 52.3873040313297 9.74626093584823 52.387319397719 9.74627635918523 52.3873360949863 9.74623192693232 52.3873207285911 9.74621650360482 52.3873872706714 9.74603941667074 52.3874018865996 9.74605409260672 52.3874186659883 9.74600945585605 52.3874040410649 9.74599477977759 52.3874401969587 9.74589855561042 52.3874527791409 9.74586508895853 52.3874625907417 9.74583898138818 52.3874705866534 9.7458470068554 52.3874913711729 9.74579169610782 52.3874833752574 9.74578367064675 52.3875333200276 9.7456507816982 52.3875410658188 9.74565855313054 52.3875618502505 9.7456032422058 52.3875541044556 9.74559547077942 52.3875882115138 9.74550473642167 52.3875972915435 9.74548057068138 52.3876366288598 9.74537592077227 52.3876480587499 9.74534552017778 52.387579963909 9.74527713313087</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für öffentliche Zwecke</funktion>
<gfkzshh>31001_3000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 22</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009UzhBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009UzhBL</gml:identifier>
<oid>DENIAL4300009UzhBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102065.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102065.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3871966047292 9.74628062148532 52.387129136526 9.74646051291164 52.387611474099 9.74694392956051 52.3876790619438 9.74676371566131 52.3876737998344 9.74675843983981 52.3876076878678 9.74669224406231 52.3875534403668 9.74663791575624 52.3873211636188 9.74640534345663 52.3872692834751 9.74635339212827 52.3872012415773 9.74628525480775 52.3871966047292 9.74628062148532</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für öffentliche Zwecke</funktion>
<gfkzshh>31001_3000</gfkzshh>
<name>St. Nikolai-Stift</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bürgerstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VLaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VLaBL</gml:identifier>
<oid>DENIAL4300009VLaBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102066.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102066.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3876366288598 9.74537592077227 52.3875972915435 9.74548057068138 52.3876361539115 9.74551966513103 52.3877029435415 9.74558685511895 52.3876926022583 9.74561427643177 52.3877033227756 9.74562508091534 52.3877046180876 9.7456285617321 52.3877062668882 9.74563218681384 52.3877079969484 9.74563532319069 52.3877097628146 9.74563800614698 52.3877115288039 9.74564027732554 52.3877132679557 9.74564218074776 52.3877150883546 9.74564386908545 52.3877171219391 9.74564543186163 52.3877193807087 9.7456468099586 52.387721871454 9.74564793257957 52.3877245931097 9.74564871749997 52.3877270774708 9.74564905055614 52.3877771599091 9.74569956066767 52.3877786595637 9.74570333952004 52.387780434134 9.74570704571966 52.387782278685 9.74571027031695 52.3877841522163 9.74571304821604 52.3877860223063 9.74571541928046 52.3877878641783 9.74571742514022 52.3877897869426 9.74571921678621 52.3877919220937 9.74572088593288 52.3877942812924 9.74572237771982 52.3877968718055 9.74572362690887 52.387799694342 9.74572455795301 52.3878024333664 9.74572505478672 52.3878124927211 9.74573520163932 52.3878167079288 9.74572401694997 52.3878879106775 9.74579566076691 52.3879291313595 9.74583714657297 52.3879184785312 9.74586548845025 52.3879028606236 9.74590701547385 52.3878993675696 9.74590348876653 52.3878577988634 9.74601403765654 52.3878613009036 9.74601756452076 52.3878338869797 9.74609048501444 52.3878307334031 9.74608730198756 52.3877897496916 9.74619630281998 52.3877929123477 9.74619947131062 52.3877912573123 9.74620386634137 52.3877783274931 9.74623826771554 52.3877420070057 9.74633488630513 52.3877276055656 9.74632041949745 52.3877115758236 9.7463630706845 52.387725986248 9.74637753765234 52.3876584565461 9.74655718023855 52.3876435101082 9.74654217520396 52.387627288257 9.74658533728269 52.3876422346895 9.74660034232624 52.3876076878678 9.74669224406231 52.3876737998344 9.74675843983981 52.3876944654082 9.74670352399849 52.3876989591479 9.74670803745022 52.3877385801223 9.74660277601765 52.3877340863786 9.74659826257248 52.3877827322501 9.74646904010729 52.3877865470571 9.74647286616055 52.3878213488507 9.74638042450095 52.3878175341334 9.74637658375999 52.3878445543522 9.74630481766857 52.3878574929948 9.74627044579957 52.387867203666 9.7462446743446 52.3878739665901 9.74625147424383 52.3878950795617 9.74619543401201 52.3878883167271 9.74618861942542 52.3879382690869 9.74605602373127 52.3879452553709 9.74606304779143 52.3879662311841 9.74600735772908 52.3879592538864 9.74600033382587 52.3879943018326 9.74590729312401 52.3879965710062 9.74590957958907 52.3880304484668 9.74581964888083 52.3880281792915 9.7458173624186 52.3880436138534 9.7457763905373 52.3879762205527 9.74570799933604 52.3879712112942 9.74572106623876 52.3878631645767 9.7456096122126 52.3878724780795 9.74558549436039 52.3878292631896 9.74554087477658 52.387828138935 9.74554379466763 52.3877980368125 9.74551270898049 52.3877991610663 9.74550978909062 52.3877534718713 9.74546261527583 52.3877441309615 9.74548680609808 52.3876366288598 9.74537592077227</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für öffentliche Zwecke</funktion>
<gfkzshh>31001_3000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009W6IBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009W6IBL</gml:identifier>
<oid>DENIAL4300009W6IBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102067.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102067.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882608298047 9.74689070579215 52.3881531077812 9.74717620467588 52.3881639085951 9.74718708447964 52.3881661489385 9.74718112704411 52.3882522427316 9.7472678517981 52.3883577152817 9.74698836859353 52.3882608298047 9.74689070579215</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Sport-, Turnhalle</funktion>
<gfkzshh>31001_3211</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WcJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WcJBL</gml:identifier>
<oid>DENIAL4300009WcJBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102068.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102068.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877993763655 9.74699663525165 52.387725541375 9.74719365674651 52.3877974685968 9.74726575584395 52.3877926402591 9.74727861985603 52.3878251419293 9.74731120198906 52.3878299702706 9.74729833797116 52.3878960992196 9.74736463813858 52.3878908684545 9.74737858274137 52.387923137853 9.74741092599085 52.3879283686218 9.7473969813818 52.3880020109402 9.7474708146447 52.3880096740134 9.74745041625581 52.3880479106284 9.74748884099716 52.3880055186504 9.74760138797735 52.3881030738572 9.74769968024464 52.3882601261093 9.74728370783387 52.3882500847763 9.74727357552327 52.3882522427316 9.7472678517981 52.3881661489385 9.74718112704411 52.3881639085951 9.74718708447964 52.3881229530706 9.7472957329317 52.388106420654 9.74733962466968 52.3880664151965 9.74729940682539 52.3880760077404 9.74727386858656 52.388003392509 9.7472010961601 52.3880137442632 9.74717349886986 52.3879813140086 9.74714099137481 52.3879709532724 9.74716858850079 52.3879048330174 9.74710231804898 52.3879151755733 9.74707475003012 52.3878825844991 9.74704207832986 52.3878722419509 9.74706964633621 52.3877993763655 9.74699663525165</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Ricarda-Huch-Schule Außenstelle</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 23</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WmGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WmGBL</gml:identifier>
<oid>DENIAL4300009WmGBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102069.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102069.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882130559038 9.74597491537236 52.3881753547608 9.74606952811692 52.3881722111936 9.74606618359845 52.3881532099483 9.74611385472489 52.3881563534214 9.746117213938 52.3881180949881 9.7462132129982 52.3882613498918 9.74636568700204 52.3882571567775 9.74637621087158 52.3882957009468 9.74641724098137 52.3882998941576 9.74640670241387 52.3884728605631 9.7465908163327 52.3885307878899 9.74644542280608 52.3885010134417 9.74641373906283 52.3885382675046 9.74632020576121 52.3884618040932 9.74623883180883 52.388429629482 9.74631959312132 52.3883568453887 9.74624214603031 52.3883754540115 9.74619543794603 52.3883493767968 9.74616768143757 52.3883307680923 9.74621440419899 52.3882560370858 9.74613488211985 52.3882879923895 9.74605466098166 52.3882130559038 9.74597491537236</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Comeniusschule</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZz7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZz7BL</gml:identifier>
<oid>DENIAL430001jZz7BL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102104.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102104.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3873846395596 9.74579671535484 52.3873720662935 9.74583019681899 52.3874401969587 9.74589855561042 52.3874527791409 9.74586508895853 52.3873846395596 9.74579671535484</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZz8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZz8BL</gml:identifier>
<oid>DENIAL430001jZz8BL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102105.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102105.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877912573123 9.74620386634137 52.3877783274931 9.74623826771554 52.3878445543522 9.74630481766857 52.3878574929948 9.74627044579957 52.3877912573123 9.74620386634137</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZz9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZz9BL</gml:identifier>
<oid>DENIAL430001jZz9BL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102106.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102106.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3875972915435 9.74548057068138 52.3875882115138 9.74550473642167 52.3876270831414 9.74554378695821 52.3876361539115 9.74551966513103 52.3875972915435 9.74548057068138</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZzaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZzaBL</gml:identifier>
<oid>DENIAL430001jZzaBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102107.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102107.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3878879106775 9.74579566076691 52.3878772306123 9.74582404625129 52.3879184785312 9.74586548845025 52.3879291313595 9.74583714657297 52.3878879106775 9.74579566076691</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001k0BIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001k0BIBL</gml:identifier>
<oid>DENIAL430001k0BIBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102108.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102108.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3880760077404 9.74727386858656 52.3880664151965 9.74729940682539 52.388106420654 9.74733962466968 52.3881229530706 9.7472957329317 52.3880760077404 9.74727386858656</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052MJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052MJBL</gml:identifier>
<oid>DENIAL43000052MJBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102263.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102263.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882973867108 9.74331472604188 52.3882762838118 9.74337081239865 52.3882677517742 9.74336223453679 52.3882476181065 9.7434157362259 52.3882561591298 9.74342431424511 52.3882370494585 9.74347509995785 52.3882285174285 9.74346652208365 52.38820943517 9.74351723473584 52.3882179761859 9.7435258127671 52.38819993637 9.74357373629059 52.3883023477474 9.74367664224772 52.3883116740066 9.74365186272284 52.3883217593381 9.74362503873835 52.3883334808651 9.74363681484728 52.3883481834905 9.74359773989252 52.3883482606979 9.74354973480502 52.3883420308943 9.74354391403001 52.3883492361164 9.74352330139576 52.3883704130697 9.7435469330578 52.3883708925573 9.74355646304713 52.3883743500004 9.74355994492523 52.3884205214874 9.74360631735368 52.3884565010395 9.74351065916342 52.388390629876 9.74344448580818 52.3884004865396 9.74341827505009 52.3882973867108 9.74331472604188</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 44</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052UUBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052UUBL</gml:identifier>
<oid>DENIAL43000052UUBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102264.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102264.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3885381755021 9.74454841255568 52.388519253478 9.74458788658565 52.3884539326971 9.7447241651054 52.3884360679618 9.74470141145971 52.3884457169836 9.74468108989933 52.3883892111941 9.74460975305345 52.3883520226852 9.74468881465548 52.3885076187536 9.74488343003604 52.3885387667431 9.74481705077355 52.3885994403612 9.74469062734956 52.3886182527856 9.74465143064177 52.3885381755021 9.74454841255568</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 16</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ZtBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ZtBL</gml:identifier>
<oid>DENIAL43000052ZtBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102265.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102265.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3879216392892 9.74487803321005 52.387872420575 9.74499286257415 52.3878568847827 9.74497576150192 52.3878528675944 9.74498549488315 52.3877954934566 9.7451247111678 52.3878924753491 9.74523155454289 52.3879467762243 9.7451006767337 52.3879314465606 9.74508368192459 52.3879484359778 9.74504275075111 52.3879302134914 9.74502256269938 52.3879382472249 9.74500319875653 52.3879484700361 9.74501452376411 52.3879730276481 9.74495533750422 52.3879454661875 9.74492480918214 52.3879452400336 9.74490505637028 52.3879216392892 9.74487803321005</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 66</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oKBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oKBL</gml:identifier>
<oid>DENIAL43000052oKBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102266.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102266.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387834197561 9.74455402443692 52.3878303852248 9.74456406987541 52.3878240067195 9.7445575999811 52.3878097723362 9.74459508037396 52.3878161598291 9.74460155042282 52.3878035435254 9.74463478202473 52.3878025697671 9.7446337958249 52.3878018018678 9.74463581069619 52.3877891858435 9.74463617147341 52.3877755664309 9.7446730743949 52.3877814301128 9.74469133503387 52.3877808176275 9.74469294108257 52.3877812911145 9.74469341926337 52.3877630980968 9.74474132457042 52.387840881886 9.74482020415263 52.3878452248059 9.74480871294162 52.3878584771562 9.74478298609004 52.3878684746835 9.74479297006438 52.387894262853 9.74472395939614 52.3878942666816 9.74470337291034 52.387905298129 9.74470336753379 52.3879102742239 9.74473122329208 52.387907740536 9.74474237762191 52.3879088727437 9.74475246219542 52.3879275888819 9.74477421601877 52.3879292230396 9.74480023755278 52.387972774057 9.74484292253531 52.3880133259715 9.74473661647863 52.3879172048522 9.74463863428404 52.387834197561 9.74455402443692</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 34</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052s2BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052s2BL</gml:identifier>
<oid>DENIAL43000052s2BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102267.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102267.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3877630980968 9.74474132457042 52.3877326724696 9.74482148328525 52.3877243196813 9.7448130111253 52.3877044808043 9.74486528216017 52.387712833589 9.74487375432612 52.3876780653088 9.74496534524259 52.3876795810159 9.74499731575825 52.3877954934566 9.7451247111678 52.3878528675944 9.74498549488315 52.3878117067349 9.74494017577718 52.3878051685235 9.74494193186871 52.387799180666 9.74493482195707 52.3877985594085 9.74491071309063 52.3878191207531 9.74490929591312 52.3878300989581 9.744886352105 52.3878278164203 9.74485479470765 52.387840881886 9.74482020415263 52.3877630980968 9.74474132457042</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052tiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052tiBL</gml:identifier>
<oid>DENIAL43000052tiBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102268.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102268.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387945554271 9.74456406805614 52.3879172048522 9.74463863428404 52.3880133259715 9.74473661647863 52.3880180705353 9.74472416215555 52.3880418019543 9.74466194942194 52.387945554271 9.74456406805614</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052wMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052wMBL</gml:identifier>
<oid>DENIAL43000052wMBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102269.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102269.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3880005655741 9.74497105369618 52.3879467762243 9.7451006767337 52.3878924753491 9.74523155454289 52.3880266533297 9.7453793899401 52.3880832542067 9.7452430843917 52.3880894255677 9.74522821488646 52.3880740959231 9.74521121997807 52.3881010269588 9.74514635756197 52.3880841254994 9.74512626511272 52.388064928715 9.74512657371754 52.3880431991626 9.74510080149353 52.3880185570357 9.74515626870466 52.388021416029 9.74516197412485 52.388015232908 9.74517728424519 52.3879784151444 9.7451375776422 52.3880021886849 9.74507870148131 52.3880092714678 9.74505758758787 52.3880311266937 9.74500493878855 52.3880005655741 9.74497105369618</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 65</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005339BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005339BL</gml:identifier>
<oid>DENIAL4300005339BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102270.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102270.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3888532090845 9.74313753081648 52.3887636177306 9.7431890879414 52.388814074156 9.74342334260596 52.3887811124126 9.74344230309422 52.3888282047643 9.74366101361131 52.3888126488213 9.74366995092753 52.3888122207459 9.74367007539186 52.3888100604485 9.74367113167863 52.3888082130078 9.74367268593227 52.3888067004655 9.74367454409326 52.3888055073495 9.74367654385478 52.3888045970091 9.74367856489932 52.3888039246003 9.74368052685634 52.3888033971603 9.7436826038581 52.3888029884605 9.74368502299657 52.3888027648766 9.74368779216263 52.3888028069228 9.74369088401969 52.3888032022034 9.7436942180605 52.388804030389 9.74369764595893 52.3888042352915 9.74369827274432 52.3888159497622 9.74376261106792 52.3888003701564 9.74375816127429 52.3887886704049 9.74386723277016 52.38883274355 9.7438798615131 52.3888348301043 9.743882600377 52.3887574664749 9.74403972089052 52.3886920083056 9.74395368634207 52.3886650511879 9.74400851360242 52.3886606017191 9.74400266387662 52.3886286548313 9.74406748754291 52.3886331398854 9.74407339664708 52.3886039697508 9.7441327124281 52.3885770312683 9.74409744836231 52.3886201212578 9.74400916882845 52.3885985137643 9.74398110655197 52.3886151166263 9.74394725055567 52.3885455149266 9.74385531309311 52.3885284384364 9.74389014563292 52.3884954162161 9.74384727067829 52.3883939638787 9.74405629691901 52.388379721881 9.74403788054204 52.3883287278163 9.74414351290321 52.388374580982 9.74420328178032 52.3883712658451 9.74421004420067 52.3884409698563 9.74430139580462 52.3884444217853 9.74429432709965 52.3884931817982 9.74435790695006 52.3884897300505 9.74436494627213 52.3885596010399 9.74445688895273 52.3885239418315 9.74453011365454 52.3885381755021 9.74454841255568 52.3886182527856 9.74465143064177 52.3886215688733 9.74464452128851 52.3886126954866 9.74463305726204 52.3886163663327 9.74462549262901 52.3886330167327 9.74459125560443 52.388660278735 9.74453517014505 52.3886690443484 9.74454661765644 52.3887634754626 9.74435479791695 52.3888004536294 9.74428197692156 52.388781769151 9.74425660856527 52.3889457011776 9.74393410236211 52.3889577818182 9.74393452588256 52.3889812247169 9.74391237858106 52.388986801755 9.74389048930147 52.388991250512 9.74385359261172 52.388988781424 9.7438344922796 52.3889749253663 9.74379617110917 52.3889637431361 9.74379013471997 52.3889078107734 9.74352608920049 52.3889325960641 9.74351206094759 52.3888532090845 9.74313753081648</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Ricarda-Huch-Schule</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 15</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000534RBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000534RBL</gml:identifier>
<oid>DENIAL430000534RBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102271.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102271.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3883492361164 9.74352330139576 52.3883420308943 9.74354391403001 52.3883482606979 9.74354973480502 52.3883481834905 9.74359773989252 52.3883334808651 9.74363681484728 52.3883217593381 9.74362503873835 52.3883116740066 9.74365186272284 52.3883320705481 9.743672351419 52.3883743500004 9.74355994492523 52.3883708925573 9.74355646304713 52.3883704130697 9.7435469330578 52.3883492361164 9.74352330139576</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053D9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053D9BL</gml:identifier>
<oid>DENIAL43000053D9BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102272.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102272.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387919604068 9.74432906805013 52.3879066495814 9.74436319046333 52.387834197561 9.74455402443692 52.3879172048522 9.74463863428404 52.387945554271 9.74456406805614 52.3879898203024 9.74444756773343 52.3880028933437 9.74441318277932 52.387919604068 9.74432906805013</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 36</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053E0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053E0BL</gml:identifier>
<oid>DENIAL43000053E0BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102273.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102273.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3880832542067 9.7452430843917 52.3880266533297 9.7453793899401 52.3881980897958 9.7455682779381 52.3882925272406 9.74535433286635 52.3882192872545 9.74526781355378 52.3881847839721 9.74534584685024 52.3881828474028 9.7453435660066 52.38817102715 9.74536886147869 52.3881439718038 9.74533507915804 52.3881488760025 9.74531585349329 52.3880832542067 9.7452430843917</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 64</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053eUBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053eUBL</gml:identifier>
<oid>DENIAL43000053eUBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102274.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102274.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3882138967149 9.74489065260779 52.3881810642261 9.74496182269868 52.3882440129698 9.74503935157489 52.3882510043964 9.74502417251995 52.3882664293483 9.74504316746232 52.3882665438261 9.74506779704799 52.3882219806347 9.74516288289236 52.3882097771238 9.74516626279711 52.3881942987171 9.74514719346467 52.3882021651996 9.74513011892146 52.3881392076182 9.74505257514658 52.388110713635 9.74511436964671 52.3881211310669 9.7451518684763 52.3882192872545 9.74526781355378 52.3882925272406 9.74535433286635 52.3883212213357 9.74528933827467 52.3883135558682 9.7452802309382 52.3883630272341 9.74516957819885 52.3883710221762 9.74517919068233 52.3883990770921 9.74511716805332 52.3882138967149 9.74489065260779</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053jPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053jPBL</gml:identifier>
<oid>DENIAL43000053jPBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102275.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102275.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3887199722431 9.74337581207852 52.3887024064646 9.74338553859805 52.3887113432967 9.74342839081473 52.3885721457177 9.74350650409334 52.3885951168644 9.74361508503746 52.3885976052354 9.74362683830321 52.3886084225509 9.74362942997364 52.3886288456517 9.74358138444212 52.3887477675271 9.74351217343943 52.3887199722431 9.74337581207852</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053ucBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053ucBL</gml:identifier>
<oid>DENIAL43000053ucBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102276.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102276.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.388323486625 9.74465314151569 52.3882902716241 9.74472511370702 52.388353014965 9.74480244795475 52.388361227539 9.74478465909217 52.38837368158 9.74480001857404 52.388377043707 9.74483003692948 52.3883339302623 9.74492622033975 52.3883176337029 9.74492854689453 52.3883031009339 9.74491063967426 52.3883106664665 9.74489423592018 52.3882479141958 9.7448169014662 52.3882138967149 9.74489065260779 52.3883990770921 9.74511716805332 52.3884270954614 9.74505523289687 52.3884193244159 9.74504575644255 52.3884716184676 9.74493227060042 52.3884798880325 9.74494253424048 52.3885076187536 9.74488343003604 52.3883520226852 9.74468881465548 52.388323486625 9.74465314151569</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053uuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053uuBL</gml:identifier>
<oid>DENIAL43000053uuBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102277.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102277.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3884669302068 9.74313747979691 52.3884334469251 9.74315646098151 52.3884375245245 9.74317570560447 52.3883971479587 9.74319858253107 52.3883930612809 9.74317935246546 52.3883586036045 9.74319887560688 52.3883626811972 9.74321812020106 52.3883139856274 9.74324572114388 52.388317364923 9.74326163307707 52.3882973867108 9.74331472604188 52.3884004865396 9.74341827505009 52.3884044711394 9.74342228007841 52.388412105901 9.74340198319315 52.3885175623623 9.7433423763912 52.3885144018125 9.74332742318936 52.388532149319 9.74331739115777 52.3885318961042 9.74331619665839 52.3884951615688 9.74314303816843 52.3884710078092 9.74315672443275 52.3884669302068 9.74313747979691</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053yYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053yYBL</gml:identifier>
<oid>DENIAL43000053yYBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102278.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102278.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886525635437 9.74305367975223 52.3886255397396 9.74306912533224 52.3886156054234 9.74307480689013 52.3886123478014 9.74305955815596 52.3885858839381 9.74307460167794 52.3885891060616 9.7430897763359 52.3885583295529 9.74310723076273 52.3885551072469 9.74309208549979 52.3885301954107 9.74310622930009 52.38853340891 9.74312134501884 52.3884951615688 9.74314303816843 52.3885318961042 9.74331619665839 52.3885489491003 9.74330652031215 52.3885728584129 9.74342034806452 52.38863526627 9.74338533641608 52.3886178518227 9.7433023730417 52.388619057506 9.74327219625646 52.3886636318966 9.7432465831558 52.3886902141241 9.74323130658751 52.388673784912 9.74315320888291 52.3886525635437 9.74305367975223</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053zSBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053zSBL</gml:identifier>
<oid>DENIAL43000053zSBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102279.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102279.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3887864848759 9.74290237129458 52.3886380119699 9.74298579694611 52.3886525635437 9.74305367975223 52.388673784912 9.74315320888291 52.3887275071586 9.74312259150435 52.3887282915186 9.74308506033521 52.3887440733874 9.74308594252608 52.3887469605879 9.74309289740903 52.3887447664741 9.7431015449913 52.3887636177306 9.7431890879414 52.3888532090845 9.74313753081648 52.3888059414739 9.74291221997344 52.3887864848759 9.74290237129458</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000123T4BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000123T4BL</gml:identifier>
<oid>DENIAL43000123T4BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102356.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102356.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3881455047194 9.74456399395303 52.3881063686433 9.74466535765179 52.3881464756608 9.74470672100711 52.3881893365586 9.74460921105493 52.3881455047194 9.74456399395303</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000123T5BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000123T5BL</gml:identifier>
<oid>DENIAL43000123T5BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102357.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102357.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.387919604068 9.74432906805013 52.3879066495814 9.74436319046333 52.3879898203024 9.74444756773343 52.3880028933437 9.74441318277932 52.387919604068 9.74432906805013</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000123T6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000123T6BL</gml:identifier>
<oid>DENIAL43000123T6BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102358.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102358.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3880446455966 9.7446572510379 52.3880208402375 9.74472121114639 52.3880627792638 9.74476289918996 52.3880865756558 9.74469893889244 52.3880446455966 9.7446572510379</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7ABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7ABL</gml:identifier>
<oid>DENIAL430001HJ7ABL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102361.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102361.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886525635437 9.74305367975223 52.3886255397396 9.74306912533224 52.3886636318966 9.7432465831558 52.3886902141241 9.74323130658751 52.388673784912 9.74315320888291 52.3886525635437 9.74305367975223</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7BBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7BBL</gml:identifier>
<oid>DENIAL430001HJ7BBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102362.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102362.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3885381755021 9.74454841255568 52.388519253478 9.74458788658565 52.3885994403612 9.74469062734956 52.3886182527856 9.74465143064177 52.3885381755021 9.74454841255568</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7CBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7CBL</gml:identifier>
<oid>DENIAL430001HJ7CBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102363.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102363.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3885625675541 9.74449977305027 52.388545917088 9.74453402474813 52.3886163663327 9.74462549262901 52.3886330167327 9.74459125560443 52.3885625675541 9.74449977305027</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052A6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052A6BL</gml:identifier>
<oid>DENIAL43000052A6BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330369.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330369.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3890766968986 9.74313743415212 52.3890356367822 9.74313890467783 52.3890299157973 9.74316655192477 52.3890143672182 9.74317575408025 52.389002455723 9.74316701649201 52.3889797654495 9.74318244673835 52.3890282480104 9.74340891065321 52.3890384579223 9.74345661909123 52.3891330822199 9.74340250172117 52.3891229614435 9.74335491224766 52.3891101944056 9.74329493489196 52.3890766968986 9.74313743415212</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Ulrichstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052BqBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052BqBL</gml:identifier>
<oid>DENIAL43000052BqBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330370.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330370.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891790955913 9.74312801535766 52.3891202517318 9.74316101571104 52.3891431282121 9.74327040443422 52.3892020438335 9.74323743480394 52.3892012495217 9.74323364494596 52.3891790955913 9.74312801535766</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052K8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052K8BL</gml:identifier>
<oid>DENIAL43000052K8BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330371.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330371.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891442454374 9.74327574264467 52.3891101944056 9.74329493489196 52.3891229614435 9.74335491224766 52.3891330822199 9.74340250172117 52.3891477175066 9.74339413656426 52.3891576518373 9.74338845501108 52.3891605147839 9.7433535152606 52.389155077061 9.7433275320251 52.3891442454374 9.74327574264467</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<name>Ke.</name>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052QEBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052QEBL</gml:identifier>
<oid>DENIAL43000052QEBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330372.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330372.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389290207628 9.74264340047955 52.3892583934126 9.74266146994085 52.3892346184736 9.7426749720275 52.3892348105215 9.74267588631765 52.3891727161267 9.74271112511163 52.3891442764765 9.7427272673491 52.3891412844494 9.74272840738996 52.3891689337984 9.74285806645051 52.3891734924841 9.74287945016081 52.3892047022129 9.74286172341268 52.3892294751958 9.74297838848198 52.3891858146337 9.74300309175816 52.38919971417 9.74306886313277 52.3892146915003 9.74306043012401 52.3892236570793 9.74310301875096 52.3892311185459 9.74309883853062 52.3893925827284 9.7430082829661 52.389413937188 9.74298652603847 52.3894019615061 9.74295509875434 52.389402432013 9.74295462172981 52.3893792585966 9.74289386691712 52.3893802448351 9.74289286954248 52.3893706450879 9.74285819058919 52.3893662704479 9.74286045359961 52.3893009485818 9.74269392461292 52.3892982677017 9.74268131569238 52.389290207628 9.74264340047955</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 12; Voßstraße 38</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052QRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052QRBL</gml:identifier>
<oid>DENIAL43000052QRBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330373.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330373.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892041457165 9.74323201840571 52.3892012495217 9.74323364494596 52.3892020438335 9.74323743480394 52.3891431282121 9.74327040443422 52.3891442454374 9.74327574264467 52.389155077061 9.7433275320251 52.3891605147839 9.7433535152606 52.3892550780673 9.74337771889616 52.3892593000089 9.7433182471628 52.3892205733008 9.74331036685928 52.3892041457165 9.74323201840571</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052nlBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052nlBL</gml:identifier>
<oid>DENIAL43000052nlBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330374.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330374.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3893572488104 9.74372756672651 52.3893285332427 9.74381754439862 52.3893156523218 9.74383428550372 52.3892472126095 9.74377770687195 52.3892235907561 9.74385401575086 52.3892103984007 9.74384309629704 52.3891890140346 9.74390958260995 52.3892145353603 9.74393146581617 52.3892130679884 9.74393605525699 52.389245904151 9.74396420383025 52.389247371524 9.74395961438699 52.3892765591574 9.74398464516943 52.3892750184794 9.74398945380198 52.3893100455214 9.74401947612457 52.3893115861081 9.74401468218237 52.3893522647002 9.74404954595798 52.3894347183276 9.74379362833659 52.3893572488104 9.74372756672651</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052v6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052v6BL</gml:identifier>
<oid>DENIAL43000052v6BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330376.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330376.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892311185459 9.74309883853062 52.3892236570793 9.74310301875096 52.3891892998746 9.74312229419061 52.3892172155783 9.74325527909954 52.3892499306912 9.74323693132053 52.3892380940451 9.74318054024756 52.3892471976269 9.7431754324677 52.3892311185459 9.74309883853062</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005341BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005341BL</gml:identifier>
<oid>DENIAL4300005341BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330377.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330377.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894143081629 9.7429861502057 52.389413937188 9.74298652603847 52.3893925827284 9.7430082829661 52.3892311185459 9.74309883853062 52.3892471976269 9.7431754324677 52.3892555425469 9.74321520404983 52.3892592597516 9.74321312106789 52.3893068889 9.7431863979727 52.3893022624179 9.74316436646258 52.3893210846013 9.7431507079647 52.3893224937665 9.74313392094494 52.389330042082 9.74313022710293 52.3893400280552 9.74313062992481 52.3893571477 9.74317613292893 52.3893502080556 9.74318311389855 52.3893723944706 9.74324210357913 52.3893845532221 9.74327443037077 52.3894854350913 9.74317308563954 52.3894726885704 9.7431412926347 52.3894143081629 9.7429861502057</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 42</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053GMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053GMBL</gml:identifier>
<oid>DENIAL43000053GMBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330378.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330378.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894854350913 9.74317308563954 52.3893845532221 9.74327443037077 52.3893646392364 9.74329443328758 52.3893857642136 9.74335064261291 52.389404556291 9.7433317670504 52.3894218082994 9.74337765448509 52.3894253188115 9.74337412795704 52.3894339227514 9.74339700519221 52.3894242055426 9.7434267750228 52.3894045341251 9.74340963380493 52.3893897841288 9.74345482194145 52.3894100009484 9.74347244256748 52.3895112011301 9.74356066544928 52.389567698528 9.74338901045217 52.3894854350913 9.74317308563954</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 44</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053L8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053L8BL</gml:identifier>
<oid>DENIAL43000053L8BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330379.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330379.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891780447143 9.74365823794831 52.3890915444793 9.74370573186314 52.3891229124858 9.74385291107976 52.3891527891063 9.74387846761404 52.3891513586195 9.7438829107243 52.3891875835467 9.74391402572282 52.3891890140346 9.74390958260995 52.3892103984007 9.74384309629704 52.3892235907561 9.74385401575086 52.3892472126095 9.74377770687195 52.3892483963977 9.74377389147119 52.3892365683284 9.7437633329432 52.3892220581683 9.74375037819985 52.3892204284581 9.74375647846488 52.3891933108103 9.74373252597484 52.3891780447143 9.74365823794831</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053eCBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053eCBL</gml:identifier>
<oid>DENIAL43000053eCBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330380.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330380.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3890356929352 9.74276234281441 52.3889041399062 9.74283582605694 52.3889381737766 9.74298958785153 52.3890684371051 9.74291533393373 52.3890654938551 9.74290155979005 52.3890356929352 9.74276234281441</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053fPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053fPBL</gml:identifier>
<oid>DENIAL43000053fPBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330381.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330381.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891477175066 9.74339413656426 52.3891330822199 9.74340250172117 52.3890384579223 9.74345661909123 52.3890402044631 9.7434648186124 52.3890915444793 9.74370573186314 52.3891780447143 9.74365823794831 52.3891906481144 9.743651308181 52.3891957543357 9.74361993282703 52.3891477175066 9.74339413656426</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Ulrichstraße 1A</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053nKBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053nKBL</gml:identifier>
<oid>DENIAL43000053nKBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330382.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330382.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891361302641 9.74270592631586 52.3890356929352 9.74276234281441 52.3890654938551 9.74290155979005 52.3890684371051 9.74291533393373 52.3891689337984 9.74285806645051 52.3891412844494 9.74272840738996 52.3891361302641 9.74270592631586</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053wSBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053wSBL</gml:identifier>
<oid>DENIAL43000053wSBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330383.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330383.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894100009484 9.74347244256748 52.3893646504552 9.7436114269003 52.3893531584308 9.74360175571497 52.3893580665812 9.74358614429072 52.3893126349811 9.74354792416132 52.3892975074172 9.74359595657534 52.3893068799052 9.74360384346453 52.3892952205244 9.74364507173955 52.3893501281054 9.74369187125789 52.3893426902784 9.7437151548487 52.3893572488104 9.74372756672651 52.3894347183276 9.74379362833659 52.3894432184708 9.74376726198592 52.3895112011301 9.74356066544928 52.3894100009484 9.74347244256748</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7EBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7EBL</gml:identifier>
<oid>DENIAL430001HJ7EBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330428.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330428.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891727161267 9.74271112511163 52.3891442764765 9.7427272673491 52.3891412844494 9.74272840738996 52.3891689337984 9.74285806645051 52.3891734924841 9.74287945016081 52.3892047022129 9.74286172341268 52.3891727161267 9.74271112511163</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7FBL</gml:identifier>
<oid>DENIAL430001HJ7FBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330429.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330429.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894726885704 9.7431412926347 52.3893723944706 9.74324210357913 52.3893845532221 9.74327443037077 52.3894854350913 9.74317308563954 52.3894726885704 9.7431412926347</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7GBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7GBL</gml:identifier>
<oid>DENIAL430001HJ7GBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330430.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330430.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891229614435 9.74335491224766 52.3890282480104 9.74340891065321 52.3890384579223 9.74345661909123 52.3891330822199 9.74340250172117 52.3891229614435 9.74335491224766</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7HBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7HBL</gml:identifier>
<oid>DENIAL430001HJ7HBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330431.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330431.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892471976269 9.7431754324677 52.3892380940451 9.74318054024756 52.3892499306912 9.74323693132053 52.3892513272707 9.7432435967522 52.3892641480603 9.74323640600363 52.3892592597516 9.74321312106789 52.3892555425469 9.74321520404983 52.3892471976269 9.7431754324677</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001NjccBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001NjccBL</gml:identifier>
<oid>DENIAL430001NjccBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330442.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330442.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892946299778 9.74262209399078 52.3892580600584 9.7426429784963 52.3892583934126 9.74266146994085 52.389290207628 9.74264340047955 52.3892982677017 9.74268131569238 52.3893080094402 9.74266907691374 52.3892946299778 9.74262209399078</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052D4BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052D4BL</gml:identifier>
<oid>DENIAL43000052D4BL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331433.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331433.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.390131962109 9.74392517120563 52.3901040484863 9.74404198202747 52.3901595309943 9.744077403999 52.3901532541011 9.74409763623226 52.3901891549491 9.74412738003985 52.3901523428414 9.74424667160684 52.3902360240804 9.74431566125229 52.3903139171016 9.74406449698751 52.3903072309092 9.74403834504142 52.390131962109 9.74392517120563</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 52</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052KmBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052KmBL</gml:identifier>
<oid>DENIAL43000052KmBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331434.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331434.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896472814901 9.74361222371334 52.3895743413366 9.74383368201988 52.3896514113947 9.74388320581703 52.3896736103088 9.74381871628582 52.3896588970013 9.74380518488404 52.3896687051478 9.74377669495221 52.3897004258848 9.74379208457426 52.3897066036594 9.74376616395694 52.3897281307206 9.7437798686734 52.3897175851993 9.74382409905988 52.3897968788553 9.74387458615818 52.389831128726 9.74373093223576 52.3896472814901 9.74361222371334</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 46</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NeBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NeBL</gml:identifier>
<oid>DENIAL43000052NeBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331435.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331435.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899815409657 9.74382805131283 52.389942156355 9.74399329423623 52.3899584274845 9.74400357502673 52.3899306536418 9.74412101957221 52.3899947351588 9.74416150890389 52.3900147597821 9.74407682106414 52.3900115973119 9.7440636159612 52.3900176502167 9.74403754615094 52.3900319343439 9.74404641224336 52.3900382057201 9.74405847934319 52.3900924600344 9.74409048610317 52.3901040484863 9.74404198202747 52.390131962109 9.74392517120563 52.3899815409657 9.74382805131283</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 50</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052PZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052PZBL</gml:identifier>
<oid>DENIAL43000052PZBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331436.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331436.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899763206377 9.74443024765681 52.3899397640996 9.74454888143346 52.3899885724132 9.74458907029732 52.3899998567445 9.74458602731218 52.3900092943517 9.74455501827296 52.3900324254962 9.74457382019941 52.3900245185195 9.74459305501143 52.3899903661539 9.74470394096088 52.3900377986242 9.74474274026039 52.3900313284123 9.74476652525471 52.390083127419 9.74480863103816 52.3901628476178 9.744551591881 52.3900895670097 9.74449141750586 52.3900626268254 9.74446928924221 52.3900547702472 9.74449479965623 52.3899763206377 9.74443024765681</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 29</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000530FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000530FBL</gml:identifier>
<oid>DENIAL430000530FBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331437.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331437.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897826074262 9.74486740678235 52.3897697704305 9.74490854187055 52.3897511946756 9.74489304942452 52.3897034155762 9.74504621704011 52.389738529547 9.74507524271288 52.3897325181835 9.74509468556622 52.3897721220446 9.74512741652215 52.3897781335062 9.74510795896271 52.3898105911649 9.7451347798636 52.3898485263622 9.74501146777879 52.3898541620082 9.74499315003981 52.3898326868761 9.74497550735312 52.3898269987037 9.74497933510365 52.3898108232819 9.74496529372229 52.3898066121444 9.74494445904526 52.3898207428893 9.74489918707821 52.3897826074262 9.74486740678235</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 12</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005340BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005340BL</gml:identifier>
<oid>DENIAL4300005340BL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331438.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331438.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3895262818374 9.7441044620187 52.3894496032117 9.74435978609043 52.3894408545886 9.74435277649672 52.3894138654752 9.74444263603477 52.3894181144387 9.74444605790836 52.3894190053069 9.74444307517983 52.3894231738266 9.74444642222701 52.3893461651933 9.74470263593857 52.3893798890011 9.74472971270112 52.3893701549799 9.74476209757391 52.3894652078216 9.74483840530938 52.3894849148109 9.74477281656221 52.3895185492608 9.74479980379192 52.3895569071418 9.74467213501088 52.3896250079479 9.7447267847127 52.389709162211 9.74444660490358 52.3896416068651 9.74439240554778 52.3896800289003 9.74426447263568 52.3896442294826 9.74423575940251 52.3896640466041 9.74416976052327 52.3895984949033 9.74411716767981 52.3895886325123 9.74414997683448 52.3895709653633 9.74413580788373 52.3895698816514 9.74413943395402 52.3895262818374 9.7441044620187</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Bonifatiusschule</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053AuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053AuBL</gml:identifier>
<oid>DENIAL43000053AuBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331439.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331439.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901145091501 9.74421548450588 52.3900935284737 9.74428350705573 52.3900529668396 9.74425006984603 52.3900277919456 9.74433167328588 52.3900140537697 9.74432034754492 52.3899999379863 9.74436613446506 52.3900143111811 9.74437798522049 52.3900141276881 9.74437856992907 52.3900534462082 9.74441095767036 52.3900545655578 9.74443022682105 52.3900975339609 9.74446551216557 52.3900895670097 9.74449141750586 52.3901628476178 9.744551591881 52.3902360240804 9.74431566125229 52.3901523428414 9.74424667160684 52.3901145091501 9.74421548450588</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053EIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053EIBL</gml:identifier>
<oid>DENIAL43000053EIBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331440.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331440.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899326601006 9.74495438411396 52.38990787275 9.74503433294226 52.3899091135989 9.74505570545568 52.3899046160844 9.74507032457668 52.389888758002 9.74505728772997 52.3898918880042 9.74504709812542 52.3898485263622 9.74501146777879 52.3898105911649 9.7451347798636 52.3898455621128 9.74516367101591 52.389840220684 9.74518095035181 52.389877212988 9.74521150673063 52.3898825543287 9.74519424207734 52.3899470135373 9.74524749442524 52.3900164106202 9.74502372859781 52.3899326601006 9.74495438411396</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 25</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053evBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053evBL</gml:identifier>
<oid>DENIAL43000053evBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331441.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331441.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389831128726 9.74373093223576 52.3897968788553 9.74387458615818 52.3897912922031 9.74389800393833 52.3898600814321 9.7439418929998 52.3898522787255 9.74397457537433 52.3898450373452 9.74397949394682 52.3898293391393 9.74404531262837 52.3898908217459 9.74408447960062 52.3899164654306 9.74397693304362 52.389942156355 9.74399329423623 52.3899815409657 9.74382805131283 52.389831128726 9.74373093223576</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 48</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053iFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053iFBL</gml:identifier>
<oid>DENIAL43000053iFBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331442.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331442.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899903661539 9.74470394096088 52.3899549561871 9.7448189201341 52.3899527014909 9.74483716259525 52.3899269141881 9.7448175664168 52.3899350416153 9.74478903355078 52.389933438489 9.74477378269159 52.3898830737311 9.74473234780593 52.3898464707395 9.74485117133664 52.3899250989848 9.74491587384809 52.3899171872618 9.74494155951429 52.3899326601006 9.74495438411396 52.3900164106202 9.74502372859781 52.390083127419 9.74480863103816 52.3900313284123 9.74476652525471 52.3900377986242 9.74474274026039 52.3899903661539 9.74470394096088</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 27</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052GfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052GfBL</gml:identifier>
<oid>DENIAL43000052GfBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332419.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332419.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3890565403104 9.74618156049169 52.3890410827903 9.74622614764281 52.3890249969401 9.74621360641255 52.3890189872606 9.746229904193 52.3889722183568 9.74635664940815 52.3889694559066 9.74636414111366 52.3890751293336 9.7464669046589 52.3891185354991 9.74632598104568 52.389071617316 9.74627558082075 52.389092624117 9.74621499667295 52.3890565403104 9.74618156049169</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 63</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052GyBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052GyBL</gml:identifier>
<oid>DENIAL43000052GyBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332420.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332420.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3895512071218 9.74619763164978 52.3895374860716 9.7462420134615 52.3895325401462 9.74623791838895 52.389487485526 9.74638363546252 52.3894924315391 9.74638771585394 52.3894765352557 9.74643912900984 52.3894631193306 9.746428058002 52.3894614122873 9.74643356910977 52.3895551186458 9.74651079834965 52.3896316484766 9.74626411537709 52.3895512071218 9.74619763164978</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052HMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052HMBL</gml:identifier>
<oid>DENIAL43000052HMBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332421.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332421.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389320401074 9.74509025882637 52.3892865083839 9.74519980979657 52.3892750640002 9.74523679450537 52.3892858524505 9.7452696277053 52.3893036352254 9.74525402760096 52.3893181109186 9.74529809086944 52.3893359138071 9.74528215312682 52.3894330113119 9.74536208186921 52.3894771498768 9.74521886131032 52.38944689145 9.74519401728965 52.3894524355607 9.74517596270259 52.3893587173827 9.74509904486613 52.3893531731911 9.74511711411794 52.389320401074 9.74509025882637</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052HbBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052HbBL</gml:identifier>
<oid>DENIAL43000052HbBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332422.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332422.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894771498768 9.74521886131032 52.3894330113119 9.74536208186921 52.3894279631732 9.74537846958501 52.3894688542332 9.74541236843858 52.3894631187105 9.74543083123008 52.3894595412162 9.74542786141106 52.3894393061654 9.7454930147886 52.3895046135111 9.74554719239545 52.3895248485917 9.74548203894713 52.3895216109431 9.74547935404508 52.3895273464734 9.74546089123561 52.3895675576348 9.74549424977713 52.3895703561726 9.74548530374551 52.3896175742248 9.74533422895903 52.3895897756423 9.74531138061362 52.3895870487867 9.7452947002312 52.3895665457837 9.74527830823724 52.3895589771076 9.74528236875805 52.3895398226354 9.74526598479849 52.3895369988495 9.74525469577075 52.3895165316138 9.74523833380598 52.3895063260218 9.74524282014885 52.3894771498768 9.74521886131032</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052J5BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052J5BL</gml:identifier>
<oid>DENIAL43000052J5BL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332423.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332423.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896175742248 9.74533422895903 52.3895703561726 9.74548530374551 52.3896628181423 9.7455617901543 52.3896643602742 9.74555676113698 52.3896862123265 9.74557449855812 52.3896905467929 9.74556008253953 52.3897306115636 9.74542704968328 52.3896872856236 9.74539147847552 52.3896921320091 9.74537571914242 52.3896543962963 9.74534472408476 52.3896495498223 9.7453604981011 52.3896175742248 9.74533422895903</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052SeBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052SeBL</gml:identifier>
<oid>DENIAL43000052SeBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332424.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332424.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892631525369 9.74644353802367 52.3892629137971 9.74644432750684 52.3892172901432 9.74659326670306 52.3893157972719 9.7466747795319 52.3893617991598 9.74652433291848 52.3893259057706 9.74649492582789 52.389328237378 9.74648732393935 52.3893017264697 9.74646561353533 52.3892993948637 9.74647321542049 52.3892631525369 9.74644353802367</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 61</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052pgBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052pgBL</gml:identifier>
<oid>DENIAL43000052pgBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332425.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332425.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896175226588 9.74594245873499 52.3895541236123 9.74614721911147 52.3895411005377 9.74618927624976 52.3895512071218 9.74619763164978 52.3896316484766 9.74626411537709 52.389644661939 9.7462221608761 52.389708168898 9.7460174167026 52.3896175226588 9.74594245873499</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 19</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052rQBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052rQBL</gml:identifier>
<oid>DENIAL43000052rQBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332426.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332426.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3889215355189 9.74597400138695 52.388834904339 9.74623153143559 52.3889089701652 9.74630532734108 52.3889215874122 9.74631758965181 52.3889244417963 9.74630977622246 52.3889722183568 9.74635664940815 52.3890189872606 9.746229904193 52.38896714663 9.74617880400685 52.3890088905394 9.74604906437573 52.3889215355189 9.74597400138695</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052vBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052vBBL</gml:identifier>
<oid>DENIAL43000052vBBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332427.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332427.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894614122873 9.74643356910977 52.3894602374958 9.74643736991533 52.3894691456726 9.74644472059499 52.3894278802472 9.74657834867319 52.3893617991598 9.74652433291848 52.3893157972719 9.7466747795319 52.3894657489806 9.7467988791931 52.3895551186458 9.74651079834965 52.3894614122873 9.74643356910977</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 15</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053dABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053dABL</gml:identifier>
<oid>DENIAL43000053dABL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332428.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332428.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891414016366 9.74527526212103 52.38908767949 9.74545263194103 52.3890691391004 9.74551137708998 52.389173712095 9.74559914647867 52.3892067043443 9.74549415094667 52.3892192212038 9.74549383281979 52.389262239247 9.74552975123076 52.3892911917812 9.74543376867661 52.3892280689478 9.74538103898442 52.3892363544345 9.74535455188622 52.3892287435662 9.7453481931633 52.3891414016366 9.74527526212103</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053fjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053fjBL</gml:identifier>
<oid>DENIAL43000053fjBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332429.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332429.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3889948250771 9.74574625176487 52.3889215355189 9.74597400138695 52.3890088905394 9.74604906437573 52.3890280477733 9.74598949233927 52.3890532285893 9.74601113581342 52.3890539620995 9.74601168578373 52.3890581924067 9.74601425665069 52.3890625239882 9.74601592265276 52.389066853048 9.74601669309346 52.3890710844163 9.74601661596499 52.389075137271 9.74601577005373 52.3890789485228 9.74601425513679 52.389082473857 9.74601218196525 52.38908568683 9.74600966337209 52.3890885766267 9.74600680729751 52.389091145109 9.74600371199825 52.3890934036881 9.74600046330585 52.3890953703923 9.74599713356684 52.3890970673475 9.74599378181595 52.3890985187564 9.74599045474891 52.3890997493747 9.74598718813903 52.3891008468191 9.74598379712468 52.3891018640725 9.74598006449088 52.3891027697119 9.74597597353121 52.3891035268368 9.74597151386199 52.3891040930961 9.74596668428699 52.389104421201 9.74596149613681 52.3891044601123 9.74595597690474 52.3891041570874 9.74595017383887 52.3891034607132 9.74594415695506 52.3891023249294 9.74593802076184 52.3891007138435 9.74593188387813 52.3890986068774 9.74592588579309 52.3890960035186 9.745920180315 52.3890929267706 9.7459149258282 52.3890894244104 9.74591027322816 52.3890887621927 9.7459095193802 52.3890639478989 9.74588535465824 52.3890840942855 9.745821464249 52.3889948250771 9.74574625176487</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053hYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053hYBL</gml:identifier>
<oid>DENIAL43000053hYBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332430.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332430.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892207156648 9.74500865621266 52.3891674226485 9.74518932548921 52.3891414016366 9.74527526212103 52.3892287435662 9.7453481931633 52.3892587675684 9.74525193471695 52.3892518809616 9.74524620538114 52.3892704273334 9.74518649013461 52.3892865083839 9.74519980979657 52.389320401074 9.74509025882637 52.3892943103798 9.74506887962294 52.3893004053309 9.74504901222064 52.3892621411787 9.74501768554069 52.3892560461402 9.7450375676233 52.3892207156648 9.74500865621266</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053noBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053noBL</gml:identifier>
<oid>DENIAL43000053noBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332431.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332431.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896138385273 9.74566141821959 52.3895828307081 9.74575965906456 52.3896241741926 9.74579450648127 52.3896402798738 9.74577826102314 52.3896488535083 9.74579874308281 52.3896459287139 9.74581202193838 52.3896396588792 9.74581541361349 52.3896038295857 9.74593113335948 52.3896175226588 9.74594245873499 52.389708168898 9.7460174167026 52.3897847434859 9.74577060053411 52.3897085583799 9.7457063346411 52.3896847164045 9.74568622714107 52.389676001195 9.74571383870088 52.3896138385273 9.74566141821959</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 21</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053uMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053uMBL</gml:identifier>
<oid>DENIAL43000053uMBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332432.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332432.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891185354991 9.74632598104568 52.3890751293336 9.7464669046589 52.3892172901432 9.74659326670306 52.3892629137971 9.74644432750684 52.3891185354991 9.74632598104568</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 62</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053wUBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053wUBL</gml:identifier>
<oid>DENIAL43000053wUBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332433.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332433.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897306115636 9.74542704968328 52.3896905467929 9.74556008253953 52.3897272040669 9.74558957546102 52.3897323470443 9.74558523898775 52.3897465127068 9.7455971894341 52.3897417148543 9.74561237648317 52.3897389604229 9.74561005237584 52.3897085583799 9.7457063346411 52.3897847434859 9.74577060053411 52.389858702148 9.74553220366672 52.3898260109441 9.74550536381449 52.3898300496733 9.74549222121112 52.3897913658207 9.74546046054704 52.389787501326 9.7454730623692 52.3897592374437 9.74544986802819 52.3897590722025 9.74545040895208 52.3897306115636 9.74542704968328</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 23</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053yJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053yJBL</gml:identifier>
<oid>DENIAL43000053yJBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332434.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332434.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3890691391004 9.74551137708998 52.3890051600942 9.74571412731629 52.3889948250771 9.74574625176487 52.3890840942855 9.745821464249 52.3890925633094 9.74582860161502 52.3891336086134 9.74569837928948 52.3891544370376 9.74571590828463 52.3891427672896 9.74575296242582 52.3892025968014 9.74580325651081 52.3892381207834 9.74569030984815 52.3891644916347 9.74562846849268 52.389173712095 9.74559914647867 52.3890691391004 9.74551137708998</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJclBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJclBL</gml:identifier>
<oid>DENIAL430001HJclBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332509.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332509.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3895541236123 9.74614721911147 52.3895411005377 9.74618927624976 52.3895512071218 9.74619763164978 52.3896316484766 9.74626411537709 52.389644661939 9.7462221608761 52.3895541236123 9.74614721911147</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SWMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SWMBL</gml:identifier>
<oid>DENIAL4300009SWMBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333785.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333785.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3887242215573 9.74704998311685 52.3886686411129 9.74719235967503 52.3887297884247 9.74725596121271 52.3887237841751 9.74727137716831 52.3887884238958 9.74733859394343 52.3887944281541 9.74732317797461 52.388854226789 9.74738536111884 52.3888808718006 9.74731473379953 52.3888779396953 9.74730923261656 52.3889055672409 9.74723677029631 52.3887242215573 9.74704998311685</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SaBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SaBBL</gml:identifier>
<oid>DENIAL4300009SaBBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333786.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333786.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3888886839962 9.74662052051146 52.3888354916377 9.7467677876183 52.3888309527845 9.74678037767504 52.3888502674536 9.74679841051387 52.3888614732414 9.74679642484599 52.3888705789678 9.74680523358783 52.3888751060372 9.74682154742547 52.3889574688581 9.74689833517543 52.3889670692844 9.7468985706959 52.3889786233913 9.74690975723997 52.3889824055642 9.74692159141258 52.3890027448231 9.74694109643161 52.3890589079493 9.74678470970185 52.3890052643649 9.74673299060951 52.389008110158 9.74672511826885 52.3889432697735 9.74666257153086 52.3889404239846 9.74667044386409 52.3888886839962 9.74662052051146</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SbFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SbFBL</gml:identifier>
<oid>DENIAL4300009SbFBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333787.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333787.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3883277826209 9.74754777601732 52.3882065703624 9.7478621404518 52.388296522111 9.74795004859189 52.3883068643062 9.74792256868657 52.3883699961327 9.74798790879994 52.3883732670302 9.7479796470904 52.3883695005679 9.74797529267646 52.3884127025069 9.74786835736898 52.3884107173478 9.74786523800319 52.3884151383358 9.74785282251641 52.3884211246155 9.747835995784 52.3883639913454 9.7477817191575 52.3884180172958 9.74763931804699 52.3883277826209 9.74754777601732</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Friedrich-Heeren-Straße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SusBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SusBL</gml:identifier>
<oid>DENIAL4300009SusBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333789.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333789.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.388449048635 9.74723330791674 52.3883277826209 9.74754777601732 52.3884180172958 9.74763931804699 52.3884723998018 9.7474959527848 52.3885475384548 9.74757200187509 52.3886030022108 9.74742966829107 52.3885279784945 9.74735248981956 52.3885384994145 9.74732515959472 52.388449048635 9.74723330791674</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Friedrich-Heeren-Straße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TAaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TAaBL</gml:identifier>
<oid>DENIAL4300009TAaBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333790.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333790.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886313440114 9.74676052185208 52.388511386119 9.74707163490559 52.388604633271 9.74716740042657 52.388616639958 9.74713827308857 52.3886686411129 9.74719235967503 52.3887242215573 9.74704998311685 52.388700765019 9.74702582618197 52.3886954704312 9.74703280482994 52.3886861561208 9.74702286108261 52.388685910398 9.74701052829268 52.388671949071 9.74699614185467 52.3886882829238 9.74695377430122 52.3886871358039 9.74694323371264 52.3886914516824 9.74693178611656 52.388698839989 9.74692640041034 52.3887247344757 9.74685925767776 52.3887257491388 9.74685518974333 52.3886313440114 9.74676052185208</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009UMsBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009UMsBL</gml:identifier>
<oid>DENIAL4300009UMsBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333793.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333793.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3887216162682 9.74755168146452 52.3886668081665 9.74769267446659 52.3886821825151 9.74770823116644 52.3886902814234 9.74770706021059 52.3886991341648 9.74771605585891 52.3887016751352 9.74772795721912 52.3887492455517 9.74777606255336 52.388756931311 9.74777482584861 52.3887668738997 9.74778492733285 52.3887693724246 9.74779643124716 52.3887860867399 9.74781334786253 52.3888402390915 9.74767371013886 52.3888090827175 9.74764166402093 52.3888121631367 9.74763366348684 52.3887527982472 9.74757257478447 52.3887497177391 9.74758059000505 52.3887216162682 9.74755168146452</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009Uw8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Uw8BL</gml:identifier>
<oid>DENIAL4300009Uw8BL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333796.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333796.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891915024275 9.74731222120203 52.3891726418931 9.74738021791233 52.3891739949694 9.74739230504106 52.3891680485907 9.74740994099576 52.3891637637611 9.74741220506356 52.3891495402138 9.74746346939456 52.38913709842 9.74745191499685 52.3891301163166 9.74745561765115 52.3891204938661 9.74744749064041 52.3891187218148 9.747434838053 52.3890943388505 9.74741217859002 52.3890462081837 9.74756213188568 52.3891044860323 9.74762024900476 52.3890969684358 9.7476403858227 52.3891985675874 9.74771905817242 52.3892929715495 9.74738731997087 52.3891915024275 9.74731222120203</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009V6LBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009V6LBL</gml:identifier>
<oid>DENIAL4300009V6LBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333799.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333799.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3887538694743 9.74644274975453 52.3887513100784 9.74644940725845 52.3886313440114 9.74676052185208 52.3887257491388 9.74685518974333 52.3887501355033 9.74679337026337 52.3887488204727 9.74677952057515 52.388756144686 9.74676008584087 52.3887648605681 9.74675517803093 52.3887766972005 9.74672448999239 52.3887973668671 9.74674577843741 52.3888069586379 9.74674026823281 52.3888354916377 9.7467677876183 52.3888886839962 9.74662052051146 52.3888358719154 9.74656952118448 52.3888477537375 9.74653736435984 52.3887538694743 9.74644274975453</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VB7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VB7BL</gml:identifier>
<oid>DENIAL4300009VB7BL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333800.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333800.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3889055672409 9.74723677029631 52.3888779396953 9.74730923261656 52.3888808718006 9.74731473379953 52.388854226789 9.74738536111884 52.388916709656 9.74744816285967 52.3889125946577 9.74745911424323 52.38897745543 9.74752405766282 52.3889857683882 9.7475018329951 52.3890462081837 9.74756213188568 52.3890943388505 9.74741217859002 52.3889055672409 9.74723677029631</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VbrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VbrBL</gml:identifier>
<oid>DENIAL4300009VbrBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333802.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333802.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3890589079493 9.74678470970185 52.3890027448231 9.74694109643161 52.3890213480049 9.74695789775278 52.3890328614184 9.74696129552096 52.3890438017362 9.74697144311726 52.389049225378 9.7469838781108 52.3891304976722 9.74705964882528 52.389140503912 9.7470611108851 52.3891540095635 9.74707362358957 52.389157034197 9.74708440171649 52.3891763937656 9.74710243558079 52.3892298353321 9.74694282846193 52.3891771294764 9.74689496009703 52.3891788145699 9.74689008054001 52.3891131850336 9.74682865148013 52.3891109700056 9.74683487399028 52.3890589079493 9.74678470970185</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VvRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VvRBL</gml:identifier>
<oid>DENIAL4300009VvRBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333803.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333803.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3886030022108 9.74742966829107 52.3885475384548 9.74757200187509 52.3885636811861 9.74758832088682 52.3885722178677 9.74758332206679 52.3885818547342 9.74759343299462 52.388582923698 9.74760779280255 52.3886314855984 9.7476569285448 52.3886396312447 9.74765405381628 52.388648473235 9.7476633284562 52.3886508977857 9.74767657972076 52.3886668081665 9.74769267446659 52.3887216162682 9.74755168146452 52.3886940060587 9.74752328087123 52.3886970955524 9.74751526580854 52.3886361315882 9.74745254872192 52.3886330420987 9.74746056377804 52.3886030022108 9.74742966829107</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WiDBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WiDBL</gml:identifier>
<oid>DENIAL4300009WiDBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333804.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333804.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892298353321 9.74694282846193 52.3891763937656 9.74710243558079 52.3892346603071 9.74715668738693 52.3891915024275 9.74731222120203 52.3892929715495 9.74738731997087 52.3893873834811 9.74705559519136 52.3892927348016 9.74696819518146 52.3892844899435 9.74699246380786 52.3892298353321 9.74694282846193</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052C3BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052C3BL</gml:identifier>
<oid>DENIAL43000052C3BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277682.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277682.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897151405762 9.74186968081268 52.3895987475878 9.74193578074301 52.3896157979605 9.74201960630124 52.3896249150144 9.7420295312007 52.3896420392327 9.74210874392869 52.3896757128785 9.74208948543505 52.3896852571342 9.74210153357487 52.3897054416917 9.74208995462693 52.3897060840575 9.74207212593424 52.3897525069591 9.74204560154072 52.3897151405762 9.74186968081268</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 13</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052JwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052JwBL</gml:identifier>
<oid>DENIAL43000052JwBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277684.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277684.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892462683561 9.74193364714679 52.3891736164625 9.74205956670806 52.3892135430648 9.74212121894552 52.3892329186667 9.74215113887709 52.3892748842819 9.74221594074561 52.3893329655 9.74211534549769 52.3893424728629 9.74209889998136 52.3893284242394 9.7420768428067 52.3893266744943 9.74205768102007 52.3893056513791 9.74202525004231 52.3892862666638 9.7419953446584 52.3892462683561 9.74193364714679</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NJBL</gml:identifier>
<oid>DENIAL43000052NJBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277685.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277685.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891327157901 9.7414997956748 52.3889808838911 9.74176194416144 52.3890585913558 9.74188194949901 52.3890737999055 9.74190542190832 52.3890772547673 9.74191075518592 52.3891500333259 9.74178611620738 52.3891454549881 9.74177929463755 52.3891390951399 9.74176982756713 52.3891300277126 9.74175628879389 52.3890905606805 9.74169730442588 52.3890806526572 9.7416973734633 52.3890805661465 9.74166530845213 52.3891130414976 9.74166507395966 52.389173176164 9.74156239674783 52.3891327157901 9.7414997956748</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 29</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NlBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NlBL</gml:identifier>
<oid>DENIAL43000052NlBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277687.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277687.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891500333259 9.74178611620738 52.3890772547673 9.74191075518592 52.3890800952478 9.74191513771046 52.3891014565877 9.74194811783995 52.3891736164625 9.74205956670806 52.3892462683561 9.74193364714679 52.389259929777 9.74190996804085 52.3892323261899 9.74186740512103 52.3892307809895 9.74187008302558 52.3892193465597 9.74188989069754 52.3891735830479 9.74182138128868 52.3891519126147 9.74178893968502 52.3891500333259 9.74178611620738</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052OMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052OMBL</gml:identifier>
<oid>DENIAL43000052OMBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277688.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277688.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3893322386839 9.74164525119711 52.3892733499882 9.74171985340141 52.3892749358495 9.74172502310781 52.3892759208797 9.74172421671958 52.3892802291199 9.74173826353959 52.3892810108926 9.74173689534804 52.3892869159174 9.74175866893082 52.3893495929297 9.7417279644353 52.3893454289784 9.74170525016207 52.389343426832 9.74170624522824 52.3893322386839 9.74164525119711</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052SnBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052SnBL</gml:identifier>
<oid>DENIAL43000052SnBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277689.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277689.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894013825276 9.74179466473541 52.3893545630301 9.74182135887223 52.3893958386469 9.74201474217533 52.3894426671767 9.74198804836985 52.3894013825276 9.74179466473541</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052weBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052weBL</gml:identifier>
<oid>DENIAL43000052weBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277695.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277695.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3890969948158 9.74144413649827 52.3890336492208 9.74155276995911 52.3890330695396 9.74159931260566 52.3890168297855 9.74159689503089 52.3890128651172 9.74158397085253 52.3889631285099 9.74148951842736 52.3888819380477 9.74160365675855 52.3889113681081 9.74165461096728 52.3889808838911 9.74176194416144 52.3891327157901 9.7414997956748 52.3890969948158 9.74144413649827</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 27</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000538pBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000538pBL</gml:identifier>
<oid>DENIAL430000538pBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277699.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277699.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389826547989 9.74166679102681 52.3897887622686 9.74179979227988 52.3898008419927 9.74180895862667 52.3897921313974 9.74186892906693 52.3897800139084 9.74187580880137 52.3897682163075 9.74182025567827 52.3897114817271 9.74185244126585 52.3897151405762 9.74186968081268 52.3897525069591 9.74204560154072 52.3897756597908 9.74203236772987 52.3897795291988 9.74205043375709 52.3898210526614 9.7420267073209 52.3898171922394 9.74200864142948 52.3898856671609 9.74196951114158 52.3898808107811 9.74194682904356 52.3899038739136 9.7418719634472 52.3899128719962 9.7418793588723 52.3899320898811 9.74181694874096 52.3899231007842 9.74180955347598 52.3899404372239 9.74175325421224 52.3898354959268 9.74167358306868 52.389826547989 9.74166679102681</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 15</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053ADBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053ADBL</gml:identifier>
<oid>DENIAL43000053ADBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277701.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277701.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389236346802 9.74157194890456 52.3891758951391 9.74167356292429 52.3892035528736 9.74171753725875 52.3892577055376 9.74165981339588 52.3892594829882 9.74165737448927 52.389236346802 9.74157194890456</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053GiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053GiBL</gml:identifier>
<oid>DENIAL43000053GiBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277703.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277703.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894546548917 9.7420319220312 52.3893949061941 9.74206589341119 52.3893594402782 9.74212575250011 52.3893512167739 9.74213961859417 52.3893441195307 9.74213018314407 52.3893329655 9.74211534549769 52.3892748842819 9.74221594074561 52.3892852308444 9.74223194042481 52.389311408971 9.74227240776631 52.3893419829158 9.74228003285731 52.3893621218975 9.74226855617709 52.3893681931977 9.74229103800501 52.3894661629683 9.74223094903908 52.3894620584329 9.74221167421465 52.3894895870182 9.74219600117632 52.3894546548917 9.7420319220312</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053gTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053gTBL</gml:identifier>
<oid>DENIAL43000053gTBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277708.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277708.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3895368438195 9.7415094039365 52.3893857663488 9.74157249864663 52.3893322386839 9.74164525119711 52.389343426832 9.74170624522824 52.3893454289784 9.74170525016207 52.3893772544385 9.7416896635675 52.3893814183927 9.74171237785566 52.3893850888716 9.74171057315743 52.3893861259954 9.74171006153361 52.3895377853607 9.74163591191649 52.3895641886985 9.74162332022367 52.3895368438195 9.7415094039365</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053iBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053iBBL</gml:identifier>
<oid>DENIAL43000053iBBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277709.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277709.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3895007106336 9.74188341076539 52.3894777686807 9.74189742692842 52.3894830715082 9.74192060122486 52.3894578169163 9.74193494595384 52.3894758854656 9.74201984633708 52.3894546548917 9.7420319220312 52.3894895870182 9.74219600117632 52.3895217358078 9.74217761361599 52.3895289475643 9.74218599301253 52.3895558427636 9.74217239596338 52.3895574488651 9.74215715507448 52.3895749895109 9.74214711887238 52.3895826938943 9.7421572258214 52.3896097024587 9.74214132356416 52.389611279927 9.74212634668092 52.3896420392327 9.74210874392869 52.3896249150144 9.7420295312007 52.3896157979605 9.74201960630124 52.3895987475878 9.74193578074301 52.3895100453012 9.74198615109277 52.3895058798275 9.7419665519666 52.3895142736218 9.74194274032325 52.3895007106336 9.74188341076539</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053k9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053k9BL</gml:identifier>
<oid>DENIAL43000053k9BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277710.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277710.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899118871842 9.74140150991155 52.3898354959268 9.74167358306868 52.3899404372239 9.74175325421224 52.3899545199557 9.7417025431931 52.3899668934362 9.74170501361209 52.3899795929965 9.74165837923326 52.3899704054672 9.74164535253141 52.3899838625718 9.74159690866401 52.3899969693267 9.74159714302848 52.3900093300535 9.74155148746599 52.3900001528846 9.74153824052804 52.3900165719722 9.74147910427073 52.3899130952519 9.74140241184444 52.3899118871842 9.74140150991155</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053sLBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053sLBL</gml:identifier>
<oid>DENIAL43000053sLBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277715.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277715.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3893850888716 9.74171057315743 52.3893814183927 9.74171237785566 52.3893495929297 9.7417279644353 52.3892869159174 9.74175866893082 52.3893061768089 9.74182980532132 52.3893033499668 9.74183471002618 52.3893065855737 9.74184632896024 52.3894003801173 9.7417939425862 52.3893850888716 9.74171057315743</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053y1BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053y1BL</gml:identifier>
<oid>DENIAL43000053y1BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277718.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277718.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892810108926 9.74173689534804 52.3892802291199 9.74173826353959 52.3892166587459 9.7418482892488 52.3892307809895 9.74187008302558 52.3892323261899 9.74186740512103 52.389259929777 9.74190996804085 52.3893033499668 9.74183471002618 52.3893061768089 9.74182980532132 52.3892869159174 9.74175866893082 52.3892810108926 9.74173689534804</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HInfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HInfBL</gml:identifier>
<oid>DENIAL430001HInfBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277853.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277853.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891300277126 9.74175628879389 52.3890585913558 9.74188194949901 52.3890737999055 9.74190542190832 52.3891454549881 9.74177929463755 52.3891390951399 9.74176982756713 52.3891300277126 9.74175628879389</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HIngBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HIngBL</gml:identifier>
<oid>DENIAL430001HIngBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277854.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277854.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3891519126147 9.74178893968502 52.3890800952478 9.74191513771046 52.3891014565877 9.74194811783995 52.3891735830479 9.74182138128868 52.3891519126147 9.74178893968502</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HInhBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HInhBL</gml:identifier>
<oid>DENIAL430001HInhBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277855.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277855.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3892862666638 9.7419953446584 52.3892135430648 9.74212121894552 52.3892329186667 9.74215113887709 52.3893056513791 9.74202525004231 52.3892862666638 9.7419953446584</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HIniBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HIniBL</gml:identifier>
<oid>DENIAL430001HIniBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277856.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277856.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3893329655 9.74211534549769 52.3892748842819 9.74221594074561 52.3892852308444 9.74223194042481 52.3893441195307 9.74213018314407 52.3893329655 9.74211534549769</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HInjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HInjBL</gml:identifier>
<oid>DENIAL430001HInjBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277857.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277857.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3893424728629 9.74209889998136 52.3893329655 9.74211534549769 52.3893441195307 9.74213018314407 52.3893512167739 9.74213961859417 52.3893594402782 9.74212575250011 52.3893424728629 9.74209889998136</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052F6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052F6BL</gml:identifier>
<oid>DENIAL43000052F6BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277935.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277935.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3908186298508 9.74197601546382 52.3908152445297 9.7419868184114 52.3908045122486 9.74197783604506 52.390775116951 9.7420717593696 52.3907784439274 9.74207454846288 52.3907582600001 9.74213901548385 52.3907665865188 9.74214597368495 52.3907352920439 9.74224594874119 52.3908245304235 9.74231926094993 52.3909078511994 9.7420506348523 52.3908186298508 9.74197601546382</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 41</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052MpBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052MpBL</gml:identifier>
<oid>DENIAL43000052MpBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277936.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277936.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902252126148 9.74151256357452 52.3902090324502 9.74157230659476 52.390196066536 9.74157398493913 52.3901871480674 9.74160835388704 52.3901937174669 9.7416288458801 52.3901818631229 9.74167259975666 52.3901698366909 9.74167499917512 52.3901603101279 9.74171170907853 52.3901665939618 9.74172899279177 52.3901510948703 9.74178620484962 52.3902465652798 9.74186504207704 52.3902574325072 9.74187401186893 52.3903226060243 9.74163457705469 52.3903386718579 9.74161599266068 52.3903319608269 9.74158941450262 52.3903169962046 9.74157864208554 52.3902252126148 9.74151256357452</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052PuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052PuBL</gml:identifier>
<oid>DENIAL43000052PuBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277937.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277937.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3907352920439 9.74224594874119 52.3907021620616 9.74235043365183 52.390708753822 9.74236304978844 52.390715786893 9.74236838455467 52.3907079716924 9.74239596841963 52.3906933685756 9.74238490779964 52.3906291432264 9.74233286764247 52.390627491695 9.74233815955673 52.3905895222635 9.74246021172794 52.3906238390098 9.74248886987247 52.3906204900618 9.74249959986865 52.3907381165916 9.74259785620679 52.3908245304235 9.74231926094993 52.3907352920439 9.74224594874119</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 39</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052RZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052RZBL</gml:identifier>
<oid>DENIAL43000052RZBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277938.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277938.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901510948703 9.74178620484962 52.3901224403309 9.74188102103289 52.3901106415043 9.74187150663049 52.3900914160281 9.74193512184475 52.3901032147573 9.74194465095324 52.3900937030569 9.74197611491002 52.3900989505461 9.74199950903506 52.3900873902212 9.74200642751375 52.3900993455861 9.74205975010773 52.3901091190543 9.74205390379352 52.3901147863147 9.74207917123063 52.3901356432604 9.74209653774594 52.3901289086462 9.74211812919802 52.39016716135 9.74214996811714 52.3901738136799 9.74212859569524 52.3902341307294 9.74217880606274 52.3902854090487 9.74201758060001 52.3902351994068 9.74197992773002 52.3902136842638 9.7419900738363 52.3901965711239 9.74197497436061 52.3902081554178 9.74193988604159 52.3902209294022 9.74195016627768 52.3902465652798 9.74186504207704 52.3901510948703 9.74178620484962</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053AFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053AFBL</gml:identifier>
<oid>DENIAL43000053AFBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277939.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277939.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3906226795329 9.74156501439651 52.3905796781559 9.74170251555628 52.3905713567879 9.74172912109353 52.390736432092 9.74186526127357 52.3907403411518 9.74185265961665 52.3907873532599 9.74170070653702 52.3907536421756 9.7416729260628 52.3907528819592 9.7416507971497 52.3907281299111 9.74162947110558 52.3907248973943 9.7416359856435 52.3907186341368 9.74164408053884 52.3906938315161 9.74162365006925 52.3906922579008 9.74160792931683 52.3906933803918 9.74159954252771 52.3906693079491 9.74157880104051 52.3906578754519 9.74159400989437 52.3906226795329 9.74156501439651</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Goebenstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053E2BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053E2BL</gml:identifier>
<oid>DENIAL43000053E2BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277940.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277940.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902854090487 9.74201758060001 52.3902341307294 9.74217880606274 52.3903901049846 9.74230812265554 52.3904312336074 9.74217689541967 52.3904439216715 9.74213641771063 52.3903019190555 9.74202993674198 52.3902854090487 9.74201758060001</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053mBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053mBBL</gml:identifier>
<oid>DENIAL43000053mBBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277942.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277942.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904312336074 9.74217689541967 52.3903901049846 9.74230812265554 52.3904197181511 9.74233273398382 52.3904160570193 9.74234450205112 52.3904513941811 9.74237388247382 52.3904550553157 9.74236211439961 52.3905197461221 9.74241591091311 52.3905160850743 9.74242766430647 52.3905525223061 9.74245795972082 52.3905555125511 9.74244565134712 52.3905861363445 9.74247110274342 52.3905895222635 9.74246021172794 52.390627491695 9.74233815955673 52.3905688360832 9.74228968101999 52.3905651377978 9.74230163954295 52.3905361677254 9.74227770021965 52.390537434125 9.74227360684802 52.3905147339294 9.74225484252871 52.3905134675304 9.74225893589879 52.3904857764119 9.74223606143388 52.3904892543273 9.7422248339824 52.3904312336074 9.74217689541967</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rXBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rXBL</gml:identifier>
<oid>DENIAL43000053rXBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277944.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277944.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3907873532599 9.74170070653702 52.3907403411518 9.74185265961665 52.3907988767134 9.74190023934622 52.3908123839501 9.74189253044638 52.3908192806607 9.74186945713523 52.390852505108 9.74189598055276 52.390842614517 9.74192908455579 52.3908389288752 9.7419261425037 52.3908316110958 9.7419332204258 52.3908186298508 9.74197601546382 52.3909078511994 9.7420506348523 52.3909659461683 9.7418633048534 52.3909610725766 9.74183906423249 52.3909312072322 9.7418145074834 52.3908870132375 9.74177955618332 52.3908922396113 9.7417619067244 52.3908545137381 9.74173206029202 52.3908492873687 9.74174970973951 52.3907873532599 9.74170070653702</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 43</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052AWBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052AWBL</gml:identifier>
<oid>DENIAL43000052AWBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278607.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278607.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897893922153 9.74290633674909 52.3897178945644 9.74298005036602 52.3897494834018 9.74306221037916 52.3898210885167 9.74298857212112 52.3897893922153 9.74290633674909</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052AcBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052AcBL</gml:identifier>
<oid>DENIAL43000052AcBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278608.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278608.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3903346948868 9.74338992007422 52.3902866815504 9.74354633496698 52.3902218338508 9.74350041094351 52.3902202406661 9.74350642379916 52.3901882668145 9.74362703164911 52.3903687023719 9.74375498629852 52.3903834753243 9.74374189154974 52.3904606053761 9.74349319608921 52.3903699447549 9.74341884426718 52.3903346948868 9.74338992007422</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 47</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052FsBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052FsBL</gml:identifier>
<oid>DENIAL43000052FsBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278609.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278609.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3898910871052 9.74280146245367 52.3898330365318 9.74286132452542 52.3899014398975 9.74292661592959 52.389926795046 9.74283477264049 52.3898910871052 9.74280146245367</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052OVBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052OVBL</gml:identifier>
<oid>DENIAL43000052OVBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278610.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278610.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896298673342 9.74274983369501 52.3895431144164 9.74283902925813 52.3895454937476 9.74284525568313 52.3895807771718 9.74293752851275 52.3895926297735 9.74296851301063 52.3896312212733 9.74306942332891 52.3897178945644 9.74298005036602 52.3897893922153 9.74290633674909 52.3898330365318 9.74286132452542 52.3898910871052 9.74280146245367 52.3898470756359 9.74276040101267 52.3898073185513 9.74280059992653 52.3897410236592 9.74286761209611 52.3897391727362 9.74287601583349 52.3897038759293 9.74291176344031 52.3896937065669 9.7429162215565 52.3896796155018 9.74287948315302 52.3896677357235 9.7428485275513 52.3896298673342 9.74274983369501</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 37</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052mwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052mwBL</gml:identifier>
<oid>DENIAL43000052mwBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278611.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278611.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901316443696 9.74333541443752 52.3901073051196 9.74342720146041 52.390092223247 9.7434165146756 52.3900602326174 9.7435369456211 52.3901601788034 9.74360726515247 52.3901882668145 9.74362703164911 52.3902202406661 9.74350642379916 52.3902000121442 9.74349209430278 52.3902241675869 9.74340095061334 52.3901316443696 9.74333541443752</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 45</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oGBL</gml:identifier>
<oid>DENIAL43000052oGBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278612.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278612.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897423592421 9.74263359051887 52.3897234008051 9.74268898027742 52.3898073185513 9.74280059992653 52.3898470756359 9.74276040101267 52.3897764438328 9.74267486718487 52.3897423592421 9.74263359051887</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oNBL</gml:identifier>
<oid>DENIAL43000052oNBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278613.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278613.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902579979179 9.74256290665047 52.3902060253531 9.74273148190275 52.3903703681731 9.74286668660965 52.3904217939272 9.74270074681607 52.3903277196899 9.74262157821829 52.3903333063268 9.74260384695676 52.3902975600383 9.74257376889926 52.3902919734059 9.74259150015035 52.3902579979179 9.74256290665047</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052s3BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052s3BL</gml:identifier>
<oid>DENIAL43000052s3BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278614.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278614.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896091922877 9.74251748592318 52.3895580299865 9.74254707487823 52.3895538799088 9.74252790208291 52.3895154856152 9.74255010808528 52.3895196356893 9.74256928086597 52.3895082391744 9.74257587857222 52.3895044500975 9.74258654212702 52.3894917848273 9.74259617503407 52.3894892646516 9.74260234860238 52.3894785292336 9.74265111650574 52.3894848089888 9.74267761360034 52.3894836303833 9.74268347170206 52.3895431144164 9.74283902925813 52.3896298673342 9.74274983369501 52.3896316772572 9.74274795375757 52.3896506933207 9.74273634080926 52.389633446326 9.74268961587093 52.3896003012291 9.74272490003716 52.3895984160541 9.74273446406386 52.3895879283236 9.74273378840083 52.3895656903953 9.74267437167646 52.3895877952407 9.7426619582602 52.3895847747479 9.74264759488543 52.3896307978961 9.74262175511083 52.3896091922877 9.74251748592318</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 35</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052tdBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052tdBL</gml:identifier>
<oid>DENIAL43000052tdBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278615.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278615.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900054817513 9.7432464776204 52.3899811579628 9.74333867614696 52.3899641242941 9.74332669287604 52.38993255042 9.74344663091519 52.3900378557433 9.7435211252688 52.3900602326174 9.7435369456211 52.390092223247 9.7434165146756 52.3900697749019 9.74340061969742 52.3900747017838 9.74338202524778 52.3900769573693 9.74338362080269 52.3900962701852 9.7433105294816 52.3900054817513 9.7432464776204</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 43</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052wiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052wiBL</gml:identifier>
<oid>DENIAL43000052wiBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278616.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278616.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900935541028 9.74242798093064 52.3900429589142 9.74259343412407 52.3902060253531 9.74273148190275 52.3902579979179 9.74256290665047 52.3902209946425 9.74253255776981 52.3902203134991 9.74251217913373 52.3901999291884 9.74249543750722 52.3901888125753 9.74250613991817 52.3901588754488 9.74248158194723 52.3901592677887 9.7424620589645 52.3901399388914 9.74244618739935 52.3901285626915 9.74245670911347 52.3900935541028 9.74242798093064</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 1A</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000531CBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000531CBL</gml:identifier>
<oid>DENIAL430000531CBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278617.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278617.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389834617402 9.74239215998165 52.3897069656561 9.74246291907888 52.3897335631911 9.74259118067043 52.3897423592421 9.74263359051887 52.3897764438328 9.74267486718487 52.3897961097536 9.74263422812503 52.3897721387234 9.74260738985724 52.3897719270262 9.74258813611024 52.3898245235195 9.74255923239719 52.3898359635932 9.74256716855413 52.389840126751 9.74258712052104 52.3898345420633 9.74259023026901 52.3898566395753 9.74269633044056 52.3898936662172 9.74267573256938 52.3898705041681 9.74256448595602 52.389834617402 9.74239215998165</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 16</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053AfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053AfBL</gml:identifier>
<oid>DENIAL43000053AfBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278618.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278618.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3898507018641 9.74311038989708 52.3898259630321 9.7431999802212 52.3897864027049 9.74334326611972 52.3898495591996 9.74338792667521 52.3898690538225 9.74340172935939 52.38993255042 9.74344663091519 52.3899641242941 9.74332669287604 52.3899948781105 9.74320990029178 52.3899692694319 9.743191880396 52.3899516948085 9.74319872691599 52.3899432200687 9.74322393320963 52.3899481424482 9.7432503784753 52.3899438417545 9.74326661753214 52.3899109745731 9.74324337658779 52.3898914798392 9.74322958865323 52.3898613158707 9.74320824471756 52.3898651930577 9.7431935856144 52.3898806257006 9.74317994350194 52.3898884200553 9.74315284486827 52.3898803858916 9.74313228410424 52.3898507018641 9.74311038989708</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 41</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053D0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053D0BL</gml:identifier>
<oid>DENIAL43000053D0BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278619.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278619.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3905148993024 9.74297127314653 52.3905091699698 9.74297164718457 52.3905079403357 9.74297560889568 52.3904972861896 9.74300999274462 52.3904954050853 9.74301604490537 52.3904820328663 9.74302228617167 52.3904248911207 9.74321071606144 52.3904314746732 9.74321604337747 52.3905234559699 9.74329056402384 52.3905873341127 9.74308459816548 52.3905979972701 9.74305021441592 52.3906006859937 9.74304154538568 52.3905187096644 9.74297439369892 52.3905148993024 9.74297127314653</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 35</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053HYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053HYBL</gml:identifier>
<oid>DENIAL43000053HYBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278620.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278620.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899012952864 9.7425489853037 52.3898705041681 9.74256448595602 52.3898936662172 9.74267573256938 52.389926795046 9.74283477264049 52.3899318878786 9.74283839959959 52.3899502956491 9.74276906966941 52.3899469911886 9.74272692811162 52.3899173282081 9.74258575637489 52.3898971896159 9.74256997411911 52.3899012952864 9.7425489853037</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053JrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053JrBL</gml:identifier>
<oid>DENIAL43000053JrBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278621.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278621.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900673738367 9.74293451580483 52.3900388765902 9.74304277954089 52.3900359477024 9.74305389847534 52.3900528560985 9.74306579138766 52.3900745737819 9.74306205622004 52.390077253209 9.74305200581544 52.3901358968774 9.74309375434303 52.390132563852 9.74310623313931 52.3901481463496 9.74314168919297 52.3901625120348 9.74315189363115 52.3901946217246 9.74303105267311 52.3901397634593 9.74299210099196 52.3901314113245 9.74302355483336 52.3901110934932 9.7430091212232 52.3901208356544 9.74297250342681 52.3900673738367 9.74293451580483</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053dYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053dYBL</gml:identifier>
<oid>DENIAL43000053dYBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278622.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278622.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904217939272 9.74270074681607 52.3903703681731 9.74286668660965 52.3903690006513 9.74287113093136 52.3903987321339 9.74289549479665 52.3904075160787 9.74286685473946 52.3904882043411 9.7429329704704 52.3904907468214 9.74292468107021 52.3905252725241 9.74295297564322 52.3905187096644 9.74297439369892 52.3906006859937 9.74304154538568 52.3906490369466 9.74288566353492 52.390511975567 9.74277413403285 52.3905167397754 9.74275851969365 52.3904582496922 9.7427109105067 52.3904534853978 9.74272653952399 52.3904217939272 9.74270074681607</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 3; Jakobistraße 37</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053fABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053fABL</gml:identifier>
<oid>DENIAL43000053fABL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278623.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278623.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389926795046 9.74283477264049 52.3899014398975 9.74292661592959 52.3898969135846 9.74294299816074 52.3899251479764 9.74296380990824 52.3899311059765 9.74294421883882 52.3900073389899 9.74299823876352 52.3900149506354 9.74302594887663 52.3900388765902 9.74304277954089 52.3900673738367 9.74293451580483 52.3899616040963 9.74285947129247 52.3899318878786 9.74283839959959 52.389926795046 9.74283477264049</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053kZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053kZBL</gml:identifier>
<oid>DENIAL43000053kZBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278624.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278624.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896761216138 9.74245678813076 52.3896431816046 9.74247517696992 52.3896475455405 9.74249608736965 52.3896091922877 9.74251748592318 52.3896307978961 9.74262175511083 52.3896380319684 9.74265662962807 52.389654478544 9.7426475891822 52.3896604878655 9.74262554502516 52.3896839235927 9.74261165502726 52.3897014906407 9.74262175127038 52.389720048258 9.74261155595028 52.3897176579346 9.7425999216473 52.3897335631911 9.74259118067043 52.3897069656561 9.74246291907888 52.3896804945425 9.74247769869515 52.3896761216138 9.74245678813076</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 14</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053pcBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053pcBL</gml:identifier>
<oid>DENIAL43000053pcBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278625.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278625.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897178945644 9.74298005036602 52.3896312212733 9.74306942332891 52.3896756238012 9.74318555234429 52.3896860876027 9.74321291342852 52.3897076785974 9.74326936606912 52.3897363346669 9.74330746609556 52.3897864027049 9.74334326611972 52.3898259630321 9.7431999802212 52.3897931378918 9.74317577023775 52.3897731462606 9.74312375283552 52.3897626373061 9.74309642034978 52.3897494834018 9.74306221037916 52.3897178945644 9.74298005036602</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 39</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053q0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053q0BL</gml:identifier>
<oid>DENIAL43000053q0BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278626.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278626.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902808369038 9.74293016465174 52.3902403628586 9.74305724306706 52.3902967705708 9.74310571389722 52.390336561303 9.74297578775701 52.3902808369038 9.74293016465174</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rGBL</gml:identifier>
<oid>DENIAL43000053rGBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278627.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278627.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899506252717 9.74231870701121 52.3899503273749 9.74232748954209 52.3899001367914 9.74235553758953 52.3898963572342 9.74233748768821 52.3898578504493 9.74235900148001 52.3898616209214 9.74237706590986 52.389834617402 9.74239215998165 52.3898705041681 9.74256448595602 52.3899012952864 9.7425489853037 52.3899369928073 9.74253101005963 52.3899580309015 9.74253527193684 52.3899610682067 9.7425254920402 52.3900429589142 9.74259343412407 52.3900935541028 9.74242798093064 52.3900618362406 9.74240208534233 52.3900673713984 9.74238395653345 52.3900318878186 9.74235498536125 52.3900263526653 9.74237311415931 52.3899758241366 9.74233185551497 52.3899761889815 9.74232100212521 52.3899506252717 9.74231870701121</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053tvBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053tvBL</gml:identifier>
<oid>DENIAL43000053tvBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278628.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278628.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901946217246 9.74303105267311 52.3901625120348 9.74315189363115 52.3901742731989 9.74316023215932 52.3902023085816 9.74314976998586 52.3902050731717 9.74313904502024 52.3902657838618 9.74318091667323 52.3902625218201 9.74319354364148 52.3902780328498 9.74323893243218 52.3902894373513 9.74324536936253 52.3903209503428 9.74312650192785 52.3902680613261 9.74308893502391 52.3902598108221 9.743119949796 52.3902379804109 9.74310443265922 52.390247501956 9.74306858990703 52.3901946217246 9.74303105267311</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053vEBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053vEBL</gml:identifier>
<oid>DENIAL43000053vEBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278629.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278629.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904314746732 9.74321604337747 52.3903699447549 9.74341884426718 52.3904606053761 9.74349319608921 52.3905234559699 9.74329056402384 52.3904314746732 9.74321604337747</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ3XBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ3XBL</gml:identifier>
<oid>DENIAL430001HJ3XBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278693.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278693.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3905079403357 9.74297560889568 52.3904972861896 9.74300999274462 52.3905873341127 9.74308459816548 52.3905979972701 9.74305021441592 52.3905079403357 9.74297560889568</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ3YBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ3YBL</gml:identifier>
<oid>DENIAL430001HJ3YBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278694.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278694.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901974343209 9.74349027289908 52.3901701846384 9.74359307635204 52.3901621682512 9.74359971599974 52.3901601788034 9.74360726515247 52.3901882668145 9.74362703164911 52.3902202406661 9.74350642379916 52.3902000121442 9.74349209430278 52.3901974343209 9.74349027289908</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ3ZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ3ZBL</gml:identifier>
<oid>DENIAL430001HJ3ZBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278695.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278695.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900697749019 9.74340061969742 52.3900378557433 9.7435211252688 52.3900602326174 9.7435369456211 52.390092223247 9.7434165146756 52.3900697749019 9.74340061969742</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ40BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ40BL</gml:identifier>
<oid>DENIAL430001HJ40BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278696.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278696.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3898914798392 9.74322958865323 52.3898495591996 9.74338792667521 52.3898690538225 9.74340172935939 52.3899109745731 9.74324337658779 52.3898914798392 9.74322958865323</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ41BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ41BL</gml:identifier>
<oid>DENIAL430001HJ41BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278697.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278697.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897626373061 9.74309642034978 52.3896756238012 9.74318555234429 52.3896860876027 9.74321291342852 52.3897731462606 9.74312375283552 52.3897626373061 9.74309642034978</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ42BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ42BL</gml:identifier>
<oid>DENIAL430001HJ42BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278698.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278698.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3896677357235 9.7428485275513 52.3895807771718 9.74293752851275 52.3895926297735 9.74296851301063 52.3896796155018 9.74287948315302 52.3896677357235 9.7428485275513</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052sCBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052sCBL</gml:identifier>
<oid>DENIAL43000052sCBL</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160008039.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160008039.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3909054537105 9.74309780264296 52.3907876262514 9.7434777064667 52.3908710082005 9.7435457501371 52.3908758651545 9.74354971128178 52.3909369089915 9.74334989791363 52.3909347676854 9.74332440986749 52.3909484035979 9.74328052396764 52.390961247069 9.74329117331306 52.3909976219431 9.74317406102618 52.3909054537105 9.74309780264296</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 42, 44</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000536dBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000536dBL</gml:identifier>
<oid>DENIAL430000536dBL</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160008041.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160008041.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3906893897005 9.74379446944996 52.3906438272622 9.74394135985879 52.390651250481 9.74397754643868 52.3908626029399 9.74416139520954 52.3909164295297 9.74399568647507 52.3909337115391 9.74394248657109 52.3908980160965 9.74391152616072 52.390873034392 9.74398675688932 52.3908264325147 9.74394736912437 52.3908123977614 9.74399173293341 52.3907847818604 9.74396838824542 52.3907988166049 9.74392402445649 52.3907550495223 9.74388705040005 52.3907647386354 9.7438546194854 52.3906893897005 9.74379446944996</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 49</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000537FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000537FBL</gml:identifier>
<oid>DENIAL430000537FBL</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160008043.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160008043.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3907876262514 9.7434777064667 52.3906893897005 9.74379446944996 52.3907647386354 9.7438546194854 52.3907751691941 9.7438629506412 52.3908710082005 9.7435457501371 52.3907876262514 9.7434777064667</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 40</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052A2BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052A2BL</gml:identifier>
<oid>DENIAL43000052A2BL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503245.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503245.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3903539133777 9.74528514844339 52.3903335925839 9.74534965517447 52.390318487715 9.74533693938192 52.390305497084 9.74537817510845 52.3902637630802 9.74551074075838 52.3902986058529 9.74553998302793 52.3902930362002 9.74555780236392 52.3903273079823 9.74558634440415 52.3903333647455 9.74556684334151 52.3903640693229 9.74559220996462 52.3904055084278 9.74545794919598 52.3903894807001 9.74544473286243 52.3903800331809 9.74543878386428 52.390376173746 9.74542064398445 52.3903841633537 9.74541113865608 52.3903899249162 9.7453928228677 52.3904029729188 9.7454037994275 52.390424495838 9.74533543338364 52.3903897249319 9.74530619240184 52.3903874680035 9.7453133696365 52.3903539133777 9.74528514844339</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ByBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ByBL</gml:identifier>
<oid>DENIAL43000052ByBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503246.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503246.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3907312142265 9.74437999439797 52.3906837654549 9.74452507449828 52.3907005663113 9.7445397437176 52.3906985772111 9.74455151042368 52.3907105270675 9.74456127802872 52.3907137951355 9.74455342704792 52.3907545423916 9.74458592767704 52.3907562507375 9.74458019593292 52.3907758505108 9.74459583809226 52.3908058653602 9.74459228732992 52.3908071959755 9.74462225843798 52.3908876825849 9.74468740470604 52.3909149792006 9.74459728299323 52.3909287186425 9.74460840334246 52.3909422706871 9.74456363471806 52.3907312142265 9.74437999439797</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 56</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052PTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052PTBL</gml:identifier>
<oid>DENIAL43000052PTBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503247.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503247.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3908255607078 9.74562684920502 52.3907928561845 9.74573467478577 52.3907813084556 9.74572531039098 52.3907477405575 9.74583601617971 52.3907589573312 9.74584511050507 52.3907461399176 9.74588736337686 52.3907497210424 9.74591397784949 52.3908255818476 9.74597405204389 52.3908316469808 9.74599312574978 52.3908509814203 9.74600804402658 52.3908825074401 9.7459915585495 52.3908853642271 9.74600615494025 52.3909275702777 9.74598408899833 52.3909246263739 9.74596905027062 52.3909883819991 9.74593570896994 52.3909620785788 9.74580130406054 52.3909071423565 9.74582757886274 52.3909084351808 9.74583214146699 52.390885983123 9.74584538543779 52.3908633957355 9.74582593036092 52.3909044092606 9.74569076472033 52.3908255607078 9.74562684920502</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052Z9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052Z9BL</gml:identifier>
<oid>DENIAL43000052Z9BL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503249.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503249.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902632593922 9.74507157308911 52.3902467589725 9.74512478491393 52.3902440132435 9.7451225050416 52.3902247321729 9.74518467800421 52.3902274868904 9.74518695803077 52.3901985972874 9.74528012239983 52.3901956815927 9.74527770740304 52.3901787496756 9.74533232251667 52.3901816653692 9.74533473751612 52.3901612186967 9.74540066726254 52.3901676089557 9.74543092892731 52.3901925783802 9.74545189311797 52.3901865780754 9.74547099832204 52.3902217874863 9.74550055527995 52.3902280171689 9.74548071918132 52.3902637630802 9.74551074075838 52.390305497084 9.74537817510845 52.3902870206499 9.74536262516814 52.3902802643229 9.74534193838947 52.3902904025655 9.74530678243673 52.3902955740037 9.74531076371471 52.3903090854367 9.74526392326535 52.3903085420696 9.7452616951706 52.3903461350605 9.74513991902211 52.3902632593922 9.74507157308911</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052npBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052npBL</gml:identifier>
<oid>DENIAL43000052npBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503250.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503250.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904908676838 9.74433749405206 52.3904741655657 9.74439137899983 52.3904700692398 9.74438798900676 52.3904579925187 9.74442691871101 52.3904620888435 9.74443030870674 52.3904394123924 9.74450347580521 52.3904353429461 9.74450010095174 52.3904237523544 9.74453749579779 52.3904278128101 9.74454087050252 52.3904095597965 9.74459974020025 52.3904993205418 9.74467695959912 52.390504721473 9.74468162065705 52.39055854896 9.74451445908991 52.3905766326668 9.74450102347847 52.390562184149 9.74444117716868 52.3905795588213 9.74443182952297 52.3905726603844 9.74440513007495 52.3904908676838 9.74433749405206</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 38</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oJBL</gml:identifier>
<oid>DENIAL43000052oJBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503251.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503251.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3906277801968 9.74513879871552 52.3905422386905 9.74542200152624 52.390642611437 9.7455029137569 52.3906553733859 9.7454608803653 52.3906647062625 9.74546647479182 52.3906837684863 9.74540338655107 52.3906755212148 9.74539672298599 52.3906918011864 9.74534284575415 52.3907005494696 9.74534989982434 52.3907194920802 9.74528723562662 52.3907104128455 9.7452799114792 52.3907284832516 9.74522011279232 52.3906277801968 9.74513879871552</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Slicherstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052tYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052tYBL</gml:identifier>
<oid>DENIAL43000052tYBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503253.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503253.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3905422386905 9.74542200152624 52.3905172505665 9.74550522480719 52.3905223527809 9.74553158553365 52.3905199531173 9.74553858403267 52.3905051589287 9.74554503570208 52.3904939159702 9.74549304622255 52.3904148149423 9.74542780485548 52.3904055084278 9.74545794919598 52.3903640693229 9.74559220996462 52.3903982530537 9.74562045669387 52.3903928197157 9.74563804323672 52.3904666790463 9.74569902321779 52.3904720849611 9.74568150966615 52.3905653081174 9.74575845174529 52.3905898225625 9.74567908533907 52.3905996967486 9.74568723117506 52.3906330039018 9.74557935740303 52.3906218596725 9.74557016152816 52.390642611437 9.7455029137569 52.3905422386905 9.74542200152624</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000535kBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000535kBL</gml:identifier>
<oid>DENIAL430000535kBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503256.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503256.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3903364098288 9.74483565703645 52.3903339503433 9.74484359501618 52.3903317770731 9.74484178033809 52.3903174700842 9.74488791688185 52.3903196433536 9.74488973156161 52.3902809711408 9.74501445806208 52.3902788156673 9.74501267306737 52.3902643158481 9.74505943813804 52.390266471321 9.74506122313443 52.3902632593922 9.74507157308911 52.3903461350605 9.74513991902211 52.3903579948801 9.74514969988636 52.3903931739467 9.74503574469458 52.3903940830979 9.74501559844452 52.3904138809562 9.74503118522272 52.3904046528432 9.74505889159268 52.3904080940579 9.74507064677205 52.3904593963806 9.74511023206027 52.3904841040813 9.74503008990398 52.3904705895107 9.74501895862795 52.390480300068 9.74498745431563 52.3904138451427 9.74493272798638 52.3904220321076 9.74490616496355 52.3903364098288 9.74483565703645</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 34</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053B3BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053B3BL</gml:identifier>
<oid>DENIAL43000053B3BL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503258.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503258.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3907120249424 9.74485439737668 52.3906263667867 9.74513767278123 52.3906277801968 9.74513879871552 52.3907284832516 9.74522011279232 52.3907463882024 9.74516088438053 52.390758133059 9.74515895138174 52.3907701839726 9.74511844879799 52.3907639950776 9.74510187132862 52.3907790696738 9.74505092730847 52.3907910651197 9.74504774941137 52.3908029904187 9.74500720056704 52.39079597735 9.74499300453313 52.3908131837923 9.74493617418509 52.3907159070781 9.74485753400903 52.3907120249424 9.74485439737668</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Slicherstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053JBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053JBBL</gml:identifier>
<oid>DENIAL43000053JBBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503261.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503261.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904095597965 9.74459974020025 52.3903933440972 9.74465203138084 52.3903905089258 9.74464967654996 52.3903756788667 9.74469750903377 52.3903785140371 9.74469986386691 52.3903640235159 9.74474659991078 52.390361259893 9.74474430505968 52.3903470353296 9.74479020793281 52.3903497900546 9.74479248794128 52.3903364098288 9.74483565703645 52.3904220321076 9.74490616496355 52.3904331139254 9.74491528610293 52.3904602354758 9.7448272932858 52.3904593771406 9.74481797688008 52.3904556353099 9.74481397562439 52.390459983146 9.74480313040057 52.3905193232402 9.7448512563019 52.3905495199397 9.74475177940978 52.3904913427851 9.74470171874077 52.3904993205418 9.74467695959912 52.3904095597965 9.74459974020025</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 36</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053bPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053bPBL</gml:identifier>
<oid>DENIAL43000053bPBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503262.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503262.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3905315488878 9.74420629025425 52.3904908676838 9.74433749405206 52.3905726603844 9.74440513007495 52.3905892977854 9.74439293385935 52.3906036107946 9.74444860450663 52.3906300283796 9.74447091527483 52.3906273927754 9.74448255352666 52.3906820511761 9.74453032119672 52.3906837654549 9.74452507449828 52.3907312142265 9.74437999439797 52.3905315488878 9.74420629025425</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 54</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053vJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053vJBL</gml:identifier>
<oid>DENIAL43000053vJBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503265.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503265.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3908071959755 9.74462225843798 52.3907755706912 9.74462598781009 52.3907769395816 9.74465701759295 52.3907260550188 9.74482509636222 52.3907168058786 9.74481762249746 52.3907121507555 9.74483300340157 52.3907211315955 9.74484025232542 52.3907159070781 9.74485753400903 52.3908131837923 9.74493617418509 52.3908294171255 9.74488253095548 52.3908382905499 9.74488970462471 52.3908528985396 9.7448414565033 52.3908437925862 9.74483408788993 52.3908568764332 9.7447908692264 52.3908657140899 9.74479801288931 52.3908808361983 9.74474806872135 52.3908715781566 9.74474058000125 52.3908876825849 9.74468740470604 52.3908071959755 9.74462225843798</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Slicherstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052GhBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052GhBL</gml:identifier>
<oid>DENIAL43000052GhBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505458.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505458.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3907255577792 9.74714061341979 52.3907076546211 9.74720651262385 52.3906972911094 9.74719899005466 52.3906832998018 9.74725050996442 52.3906936365272 9.74725800270068 52.3906699617607 9.74734517101398 52.3906603946159 9.74733824967369 52.3906448291455 9.74739557686141 52.3906545841394 9.74740264833575 52.3906363768392 9.74746970310401 52.3906990056982 9.74751509627261 52.3907490181058 9.74752963705908 52.3907822206749 9.74740728781582 52.3907719555044 9.74739985501865 52.3907866006518 9.74734589200707 52.3907963377621 9.7473529484962 52.3908199669365 9.74726588203483 52.390826732789 9.74727078692291 52.3908323018109 9.74725026366629 52.3908254644123 9.74724529879181 52.3908327824128 9.74721832450293 52.3907255577792 9.74714061341979</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052HHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052HHBL</gml:identifier>
<oid>DENIAL43000052HHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505459.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505459.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900149538549 9.74689440742757 52.3899758754671 9.74701905100241 52.3899605722648 9.74700644895341 52.3899538260957 9.74702830389165 52.3899110444079 9.74716702109552 52.3899790867448 9.74721651619889 52.3900391194107 9.74726017456665 52.3900605048278 9.74717959619142 52.3900867284541 9.74719695285553 52.3901129042387 9.74709670527339 52.3901066001902 9.74709127927236 52.3900443753181 9.7470459529213 52.3900344966858 9.74705275151875 52.3900254889025 9.74704694190339 52.3900364090024 9.74701191729855 52.3900521833015 9.74702252881811 52.3900760031429 9.7469436666203 52.3900149538549 9.74689440742757</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 59</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052MIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052MIBL</gml:identifier>
<oid>DENIAL43000052MIBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505461.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505461.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3905805523302 9.74612948014274 52.390579799695 9.74613192152887 52.3905334596542 9.74628332215122 52.3905767235926 9.7463187028411 52.390480657334 9.7466778164104 52.3905195321637 9.74670633425744 52.3905164862528 9.74671742170719 52.3905011461157 9.7467732832233 52.3905916837399 9.74683973412714 52.3906070328981 9.74678387267212 52.3906107231244 9.74677041547458 52.3906149113191 9.74677348395816 52.390620837068 9.74675198218695 52.3906163447116 9.74674867345028 52.3906221136417 9.74672780091744 52.3906263910837 9.7467309737696 52.39063100958 9.74671431400197 52.3906265352946 9.74671099087823 52.3906315859518 9.74669281011173 52.3906358275292 9.74669596766086 52.3906405925457 9.74667888420083 52.390636100373 9.746675546083 52.3906404790066 9.74665985213472 52.3906447293888 9.74666303922011 52.3906489788254 9.74664787211099 52.3906444778477 9.7466445044569 52.3906491132903 9.74662800660558 52.3906533098286 9.74663117808485 52.3906585151528 9.74661270600612 52.3906539874838 9.74660929381919 52.3906583556342 9.74659383480285 52.3906625610702 9.74659702112478 52.3906672965982 9.74658033391419 52.390662769021 9.74657690703634 52.3906675502364 9.74656010303356 52.390671710911 9.7465632592075 52.3906764919389 9.74654648458692 52.3906719465672 9.74654302802138 52.3906767365818 9.74652625355017 52.3906808702885 9.74652940926658 52.390685669198 9.74651264963572 52.3906811060317 9.74650916338248 52.3906858586913 9.74649260870063 52.3906899743269 9.74649577880479 52.3906946991808 9.74647935590512 52.3906901362919 9.74647582557395 52.3906947412163 9.74645988558764 52.3906985794743 9.74646284527829 52.3907130551256 9.74641287626223 52.3907081969697 9.74640912052873 52.3907138122649 9.74638978830486 52.3907178830481 9.74639294294973 52.3907220000088 9.74637881690898 52.3907174193231 9.74637525689555 52.3907224640843 9.74635800174716 52.3907265257859 9.74636117093166 52.3907304584978 9.74634774714341 52.3907258601104 9.74634414274854 52.3907314555605 9.7463251040766 52.3907354724079 9.74632825780702 52.3907395698046 9.74631438124192 52.3907349536225 9.74631074715938 52.3907410536063 9.74629011521998 52.3907449629505 9.74629320835417 52.3907527619054 9.74626691804618 52.3907358366095 9.746253480444 52.3907507078076 9.7462035032937 52.3907316179668 9.74618829518802 52.3907167386203 9.74623813992837 52.390710816726 9.74623341109075 52.3907089154373 9.74623978609689 52.3906963025318 9.74622968356295 52.3906981943666 9.74622338187433 52.3906908414638 9.74621746799294 52.3906889039393 9.74622388647111 52.3906769711808 9.74621428035545 52.3906788537469 9.74620802259794 52.3906707496128 9.7462014788581 52.390668793739 9.74620795580502 52.3906551796537 9.74619694000396 52.3906570617551 9.74619075571646 52.3906495481509 9.74618466279479 52.3906473262929 9.74619197287434 52.3906354658194 9.7461823092151 52.3906374211353 9.74617592043308 52.3905805523302 9.74612948014274</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 16; Harnischstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NHBL</gml:identifier>
<oid>DENIAL43000052NHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505462.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505462.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900089772004 9.74589167442844 52.3899241694282 9.74616517091915 52.3900243002459 9.74624729929055 52.3900334405878 9.74622072343059 52.3901100889926 9.74597652274249 52.3900721877403 9.7459447158643 52.3900089772004 9.74589167442844</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 30</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052Q7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052Q7BL</gml:identifier>
<oid>DENIAL43000052Q7BL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505465.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505465.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.389965348402 9.74669589467517 52.3899126623691 9.74686546590361 52.3899537861652 9.74689945860804 52.3900063111768 9.74672976698614 52.3899867420887 9.74671358096239 52.389965348402 9.74669589467517</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052RLBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052RLBL</gml:identifier>
<oid>DENIAL43000052RLBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505467.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505467.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901926966024 9.74701827364975 52.3901682545917 9.74710310635073 52.3901806729953 9.74711267670994 52.390171076305 9.74714598974747 52.3901635160373 9.74714017514691 52.3901645732437 9.74713648987368 52.3901310756506 9.7471106930649 52.3901129042387 9.74709670527339 52.3900867284541 9.74719695285553 52.3900605048278 9.74717959619142 52.3900391194107 9.74726017456665 52.3900644909438 9.74727863369238 52.3900848777482 9.7472934524839 52.3901902748283 9.74737011797706 52.3902354265195 9.74720212366848 52.3902199821977 9.74718909294439 52.3902531874949 9.74706483460708 52.3901926966024 9.74701827364975</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 58</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052TABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052TABL</gml:identifier>
<oid>DENIAL43000052TABL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505468.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505468.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899861438025 9.74662895775101 52.3899710749468 9.74667746107565 52.389992441389 9.74669519098114 52.3899867420887 9.74671358096239 52.3900063111768 9.74672976698614 52.3900378469882 9.74675586830655 52.3900589209278 9.74668753998557 52.3899861438025 9.74662895775101</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052TuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052TuBL</gml:identifier>
<oid>DENIAL43000052TuBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505469.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505469.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902401463824 9.74659599202911 52.3902115333944 9.74670212112981 52.3902172791912 9.74670625920624 52.3902136428171 9.74671973189351 52.3902325985035 9.74673339481369 52.3902359033642 9.74672116559896 52.390320308599 9.74678206065092 52.390349178101 9.74667518622491 52.3902401463824 9.74659599202911</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ZPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ZPBL</gml:identifier>
<oid>DENIAL43000052ZPBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505471.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505471.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899126623691 9.74686546590361 52.389895335927 9.74692121960493 52.3899373392347 9.74695261150928 52.3899537861652 9.74689945860804 52.3899126623691 9.74686546590361</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052nFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052nFBL</gml:identifier>
<oid>DENIAL43000052nFBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505473.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505473.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904429955294 9.74694826010118 52.3903578069565 9.74725885571013 52.3903539079954 9.74727687941098 52.3903769962804 9.74729386000661 52.3904526596038 9.74734950951815 52.3904706034231 9.74728430210379 52.3904809394966 9.74729189766573 52.3904949729833 9.74724081956771 52.390484448868 9.74723310327932 52.3905093227342 9.74714254626642 52.3905197752173 9.74715021724288 52.3905344532373 9.7470967252532 52.3905237769395 9.74708890355723 52.3905423938484 9.74702101810067 52.3904492957938 9.74695286313779 52.3904429955294 9.74694826010118</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052wNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052wNBL</gml:identifier>
<oid>DENIAL43000052wNBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505474.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505474.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902354265195 9.74720212366848 52.3901902748283 9.74737011797706 52.3903729946514 9.74750301995235 52.3904108686488 9.74750352753185 52.3904233741841 9.74745808135454 52.3904356700483 9.74746712077838 52.3904523441039 9.74740652092396 52.3904395560371 9.74739712051881 52.3904526596038 9.74734950951815 52.3903769962804 9.74729386000661 52.390369137752 9.74732242663245 52.3903113902155 9.74727995265166 52.3903169754731 9.74725828369957 52.3902354265195 9.74720212366848</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 57</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000533xBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000533xBL</gml:identifier>
<oid>DENIAL430000533xBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505475.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505475.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3906363768392 9.74746970310401 52.3906249994119 9.7475116270375 52.3906155396875 9.74750478095848 52.3905872901388 9.7476087563391 52.3905973671654 9.74761608310882 52.3905859811614 9.74765793334783 52.3908077557302 9.74781924221389 52.3908592999858 9.74763282342931 52.3907670919866 9.74756472580493 52.3907551161141 9.74759038690637 52.390695578381 9.74754667695472 52.3906990056982 9.74751509627261 52.3906363768392 9.74746970310401</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 56</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005363BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005363BL</gml:identifier>
<oid>DENIAL4300005363BL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505476.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505476.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3898229148589 9.74649173113476 52.3897251838022 9.74680688739532 52.3898032183955 9.74687146563116 52.3898231898591 9.74688799642981 52.3898651572089 9.74675289511514 52.3898760058043 9.7467619098019 52.3898895407605 9.74671855331041 52.3898781469522 9.74670902980609 52.389920582207 9.74657383318649 52.3898229148589 9.74649173113476</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 24</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000536NBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000536NBL</gml:identifier>
<oid>DENIAL430000536NBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505477.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505477.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902707469112 9.74680004844001 52.3902592489576 9.74684258735298 52.3902966679141 9.74686958173786 52.3903081568878 9.7468270426444 52.3902707469112 9.74680004844001</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053CpBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053CpBL</gml:identifier>
<oid>DENIAL43000053CpBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505479.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505479.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904151574232 9.7459977423179 52.3903667093105 9.74615839421256 52.3905307515085 9.74629218168113 52.3905334596542 9.74628332215122 52.390579799695 9.74613192152887 52.3904151574232 9.7459977423179</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053g5BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053g5BL</gml:identifier>
<oid>DENIAL43000053g5BL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505482.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505482.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3904248757284 9.74675960807896 52.3903932628683 9.74688089622101 52.3904403274621 9.7469166207456 52.390442469851 9.7469090889693 52.3904580476706 9.74692091692231 52.3904492957938 9.74695286313779 52.3905423938484 9.74702101810067 52.3905570536453 9.74696755512375 52.3905665754929 9.74697453438293 52.3905854406259 9.74690577129861 52.3905755340784 9.74689849165592 52.3905916837399 9.74683973412714 52.3905011461157 9.7467732832233 52.3904901587513 9.7468132740438 52.3904780957869 9.74682570817913 52.39047335022 9.74681551789269 52.3904678005277 9.74681164759835 52.3904726839253 9.74679290567375 52.3904248757284 9.74675960807896</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053kHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053kHBL</gml:identifier>
<oid>DENIAL43000053kHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505483.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505483.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3908172100973 9.74680584771442 52.3908009329267 9.74686486791452 52.3907902926652 9.74685703213998 52.3907726796689 9.74692114364488 52.3907834991609 9.74692907062817 52.3907588903335 9.74701897151312 52.3907478200674 9.74701089332716 52.3907309401776 9.74707279812382 52.3907418316691 9.74708071165723 52.3907255577792 9.74714061341979 52.3908327824128 9.74721832450293 52.3908336326162 9.74721894136244 52.3909241757231 9.74688474408638 52.3908172100973 9.74680584771442</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053pHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053pHBL</gml:identifier>
<oid>DENIAL43000053pHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505485.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505485.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897251838022 9.74680688739532 52.3896810827117 9.74694956410932 52.3896874923945 9.7469809574974 52.3896949956694 9.74698725597301 52.3898860244908 9.7471469809926 52.3899029988883 9.74716116894244 52.3899110444079 9.74716702109552 52.3899538260957 9.74702830389165 52.3899293022542 9.74700800771512 52.3897952888269 9.74689706240991 52.3898032183955 9.74687146563116 52.3897251838022 9.74680688739532</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 60</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053qtBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053qtBL</gml:identifier>
<oid>DENIAL43000053qtBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505486.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505486.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899241694282 9.74616517091915 52.3899072187526 9.74621984382492 52.3899030062637 9.74621634888321 52.389883660209 9.7462787549169 52.3898878727887 9.74628223516971 52.3898736660737 9.74632806388974 52.3899367224357 9.74637416721036 52.3899440477422 9.74634742856016 52.3899711817432 9.74636728347355 52.3899759395777 9.7463499062157 52.3899933278808 9.7463626313818 52.3899912573507 9.74637017901508 52.3900410596646 9.74640662481361 52.3900595560062 9.74634922993859 52.3900431923394 9.74633512602588 52.3900536137282 9.74629931399161 52.390020672191 9.74627370360044 52.3900181818433 9.7462651532578 52.3900243002459 9.74624729929055 52.3899241694282 9.74616517091915</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 28</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rTBL</gml:identifier>
<oid>DENIAL43000053rTBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505487.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505487.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3903167104776 9.74613597882231 52.3902790076286 9.74626360079846 52.3903239084158 9.74630031672515 52.3903623660596 9.74617276615951 52.3903167104776 9.74613597882231</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053sHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053sHBL</gml:identifier>
<oid>DENIAL43000053sHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505488.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505488.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902501039724 9.74586316041763 52.3902063326428 9.74600647719456 52.3902011642116 9.74602339211304 52.3902289906396 9.7460460800513 52.3903667093105 9.74615839421256 52.3904151574232 9.7459977423179 52.3902781539659 9.74588604308368 52.3902501039724 9.74586316041763</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053uRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053uRBL</gml:identifier>
<oid>DENIAL43000053uRBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505489.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505489.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3898736660737 9.74632806388974 52.3898229148589 9.74649173113476 52.389920582207 9.74657383318649 52.3899229610048 9.7465758424337 52.3899425673576 9.74651352903429 52.3899584854951 9.74650564193848 52.3899686892709 9.74651426363817 52.3899646726421 9.74653100680659 52.3900156831193 9.74656832545245 52.390046798116 9.74645464168059 52.3899367224357 9.74637416721036 52.3898736660737 9.74632806388974</gml:posList>
</gml:LinearRing>
</gml:exterior>
<gml:interior>
<gml:LinearRing>
<gml:posList>52.3899706029028 9.74640627390503 52.3899918996134 9.74642223911706 52.3899824169203 9.74645603901538 52.3899611201215 9.7464400884839 52.3899706029028 9.74640627390503</gml:posList>
</gml:LinearRing>
</gml:interior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 26</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053vzBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053vzBL</gml:identifier>
<oid>DENIAL43000053vzBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505490.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505490.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3900642337099 9.74571346031454 52.3900089772004 9.74589167442844 52.3900721877403 9.7459447158643 52.3900847535383 9.74590957174614 52.3901187995732 9.74593683165946 52.3901175045778 9.74594686115502 52.3901425988417 9.74596654925913 52.390155697803 9.74596516834518 52.3902063326428 9.74600647719456 52.3902501039724 9.74586316041763 52.390223484986 9.74584146280361 52.3902262094172 9.74582859185857 52.3901914849715 9.7457991309799 52.3901869808839 9.74581050242528 52.39013424575 9.74576577858632 52.3901374241022 9.74575220995641 52.3901036531828 9.74572266240333 52.3900991888579 9.74573628282625 52.3900752113956 9.74571770111743 52.3900642337099 9.74571346031454</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009RXIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009RXIBL</gml:identifier>
<oid>DENIAL4300009RXIBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505639.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505639.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899181129343 9.74753360080421 52.389875841552 9.74768962186551 52.3899051783077 9.74771085202663 52.3900223464273 9.74779562298244 52.3900670138307 9.74782794252983 52.3900694714049 9.74781891730688 52.390108994916 9.74767378227685 52.3900768842983 9.74765046257885 52.3900742715532 9.74763000720242 52.3900473987692 9.74760868638976 52.3900366657414 9.74761979072599 52.3899919397891 9.74758819047161 52.3899901324726 9.74756832184634 52.3899622533068 9.74754691063561 52.3899525600113 9.7475585174623 52.3899474408214 9.74755481603755 52.3899181129343 9.74753360080421</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SEvBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SEvBL</gml:identifier>
<oid>DENIAL4300009SEvBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505643.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505643.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3897454199373 9.74732780690636 52.3897007483521 9.74749377946265 52.3896851428547 9.74755173655551 52.3898295003957 9.74765611342696 52.3898467015411 9.74766855670038 52.389875841552 9.74768962186551 52.3899181129343 9.74753360080421 52.3898889551021 9.74751250603085 52.3898829858016 9.7475081730719 52.3898817635384 9.74748819682357 52.3898562392846 9.74747114577922 52.3898455389986 9.74748133957466 52.3898009369101 9.74745005028248 52.3898014028344 9.74744745717008 52.3897696491516 9.74742455528486 52.3897602020545 9.74739153812454 52.3897722412733 9.74734731907026 52.3897454199373 9.74732780690636</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VYwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VYwBL</gml:identifier>
<oid>DENIAL4300009VYwBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505662.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505662.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3895724192166 9.74720193413178 52.3895611557127 9.74720878271093 52.3894967387672 9.74743625656212 52.3895839857728 9.74750124101079 52.389598069755 9.74745072326463 52.3895926828245 9.74744670877004 52.3896078891546 9.74739215420204 52.3896266719187 9.74740613758502 52.3896186960347 9.74743477519946 52.3897007483521 9.74749377946265 52.3897454199373 9.74732780690636 52.3895724192166 9.74720193413178</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistung mit Wohnen</funktion>
<gfkzshh>31001_2310</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WqeBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WqeBL</gml:identifier>
<oid>DENIAL4300009WqeBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505667.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505667.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3894967387672 9.74743625656212 52.3894164859126 9.74771965467688 52.3895240439362 9.74780145560268 52.3895342961732 9.74776545043968 52.3895932961109 9.74781031131952 52.3896131822596 9.74773229495921 52.3895334160207 9.74767291754695 52.3895382272404 9.74765565905952 52.3895427495397 9.74765707269212 52.3895546168711 9.74761161666408 52.3895632904323 9.74761767049541 52.3895771478204 9.74756460679055 52.3895883506054 9.74753750791096 52.3895945181188 9.74750907490091 52.3895839857728 9.74750124101079 52.3894967387672 9.74743625656212</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 20</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcmBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcmBL</gml:identifier>
<oid>DENIAL430001HJcmBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505799.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505799.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899293022542 9.74700800771512 52.3898860244908 9.7471469809926 52.3899029988883 9.74716116894244 52.3899110444079 9.74716702109552 52.3899538260957 9.74702830389165 52.3899293022542 9.74700800771512</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcnBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcnBL</gml:identifier>
<oid>DENIAL430001HJcnBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505800.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505800.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3901129042387 9.74709670527339 52.3900867284541 9.74719695285553 52.3900644909438 9.74727863369238 52.3900848777482 9.7472934524839 52.3901310756506 9.7471106930649 52.3901129042387 9.74709670527339</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcoBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcoBL</gml:identifier>
<oid>DENIAL430001HJcoBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505801.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505801.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3905164862528 9.74671742170719 52.3905011461157 9.7467732832233 52.3905916837399 9.74683973412714 52.3906070328981 9.74678387267212 52.3905164862528 9.74671742170719</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcrBL</gml:identifier>
<oid>DENIAL430001HJcrBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505804.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505804.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3902078907728 9.74620545842556 52.3901954244831 9.74624618831635 52.3904227729196 9.74643204988978 52.3904360621414 9.74639199500032 52.3903239084158 9.74630031672515 52.3902790076286 9.74626360079846 52.3902078907728 9.74620545842556</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZLQBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLQBL</gml:identifier>
<oid>DENIAL430001jZLQBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505825.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505825.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3898889551021 9.74751250603085 52.3898467015411 9.74766855670038 52.389875841552 9.74768962186551 52.3899181129343 9.74753360080421 52.3898889551021 9.74751250603085</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZLRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLRBL</gml:identifier>
<oid>DENIAL430001jZLRBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505826.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::4258" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505826.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>52.3899181129343 9.74753360080421 52.389875841552 9.74768962186551 52.3899051783077 9.74771085202663 52.3899474408214 9.74755481603755 52.3899181129343 9.74753360080421</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
</wfs:FeatureCollection>