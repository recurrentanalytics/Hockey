<?xml version='1.0' encoding='utf-8'?><wfs:FeatureCollection xmlns="http://repository.gdi-de.org/schemas/adv/produkt/alkis-vereinfacht/2.0" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:wfs="http://www.opengis.net/wfs/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" timeStamp="2026-11-27T11:53:28.033+01:00" numberReturned="265" numberMatched="unknown" xsi:schemaLocation="http://repository.gdi-de.org/schemas/adv/produkt/alkis-vereinfacht/2.0 http://download.lgln.niedersachsen.de/aaa-suite/schema/AAA-vereinfacht/2.0/schema/ALKIS-vereinfacht.xsd http://www.opengis.net/wfs/2.0 http://download.lgln.niedersachsen.de/aaa-suite/schema/ogc/wfs/2.0/wfs.xsd http://www.opengis.net/gml/3.2 http://download.lgln.niedersachsen.de/aaa-suite/schema/ogc/gml/3.2.1/gml.xsd">
<wfs:boundedBy>
<gml:Envelope srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:lowerCorner>550453.868 5804339.374</gml:lowerCorner>
<gml:upperCorner>550903.853 5804788.275</gml:upperCorner>
</gml:Envelope>
</wfs:boundedBy>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053jNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053jNBL</gml:identifier>
<oid>DENIAL43000053jNBL</oid>
<aktualit>2017-01-23Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41345557.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41345557.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550754.754 5804532.998 550760.484 5804530.076 550765.539 5804539.985 550759.809 5804542.908 550754.754 5804532.998</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude zur Versorgung</funktion>
<gfkzshh>31001_2500</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 19</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300012aFjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300012aFjBL</gml:identifier>
<oid>DENIAL4300012aFjBL</oid>
<aktualit>2012-07-05Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41722413.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41722413.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550687.66 5804371.698 550692.874 5804368.788 550694.039 5804370.77 550689.177 5804373.74 550687.66 5804371.698</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8MBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8MBL</gml:identifier>
<oid>DENIAL430001fU8MBL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767081.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767081.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550468.55 5804527.129 550475.281 5804517.69 550487.424 5804528.484 550479.578 5804537.094 550477.506 5804535.114 550469.55 5804528.019 550468.55 5804527.129</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 30</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8OBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8OBL</gml:identifier>
<oid>DENIAL430001fU8OBL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767082.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767082.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550479.578 5804537.094 550487.424 5804528.484 550497.407 5804538.282 550492.794 5804550.716 550484.755 5804542.074 550479.578 5804537.094</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8SBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8SBL</gml:identifier>
<oid>DENIAL430001fU8SBL</oid>
<aktualit>2017-03-06Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767085.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767085.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550488.736 5804520.35 550489.855 5804518.736 550491.883 5804515.813 550492.097 5804515.96 550513.242 5804530.468 550510.521 5804537.985 550505.342 5804536.08 550505.47 5804535.717 550504.832 5804535.479 550505.729 5804533.052 550506.361 5804533.282 550506.521 5804532.843 550506.592 5804532.649 550488.736 5804520.35</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8TBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8TBL</gml:identifier>
<oid>DENIAL430001fU8TBL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767086.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767086.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550532.24 5804531.078 550537.752 5804515.72 550548.996 5804519.757 550543.543 5804535.17 550532.24 5804531.078</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8VBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8VBL</gml:identifier>
<oid>DENIAL430001fU8VBL</oid>
<aktualit>2017-03-06Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767087.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767087.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550479.117 5804507.582 550483.43 5804496.218 550492.121 5804499.338 550489.98 5804505.008 550487.148 5804512.507 550479.117 5804507.582</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Ulrichstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU90BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU90BL</gml:identifier>
<oid>DENIAL430001fU90BL</oid>
<aktualit>2016-06-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.41767090.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.41767090.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550508.691 5804542.996 550510.095 5804539.04 550516.952 5804541.473 550515.147 5804546.559 550515.194 5804546.576 550514.894 5804547.424 550511.908 5804546.364 550508.691 5804542.996</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TDTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TDTBL</gml:identifier>
<oid>DENIAL4300009TDTBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336650.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336650.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550841.749 5804362.996 550846.383 5804360.241 550851.313 5804356.692 550851.417 5804356.617 550853.187 5804359.581 550854.928 5804358.541 550854.148 5804357.234 550855.659 5804356.331 550854.503 5804354.394 550862.453 5804348.665 550864.887 5804352.777 550866.169 5804352.018 550866.411 5804352.428 550868.498 5804355.953 550867.206 5804356.718 550869.112 5804359.939 550864.361 5804362.75 550863.54 5804361.363 550861.339 5804362.665 550857.882 5804362.376 550857.712 5804364.404 550859.458 5804367.275 550860.009 5804368.182 550848.919 5804374.981 550848.326 5804373.989 550841.749 5804362.996</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TOIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TOIBL</gml:identifier>
<oid>DENIAL4300009TOIBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336652.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336652.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550866.586 5804389.281 550866.626 5804389.26 550872.691 5804386.055 550879.108 5804382.675 550884.15 5804392.496 550872.619 5804398.454 550866.586 5804389.281</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bürgerstraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009Uz8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Uz8BL</gml:identifier>
<oid>DENIAL4300009Uz8BL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336668.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336668.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550848.919 5804374.981 550860.009 5804368.182 550860.707 5804369.329 550862.554 5804372.366 550863.87 5804372.497 550865.362 5804369.116 550867.381 5804368.075 550866.514 5804366.394 550871.353 5804363.899 550873.224 5804366.921 550874.393 5804366.197 550876.584 5804369.736 550876.807 5804370.096 550875.5 5804370.905 550877.292 5804373.799 550875.213 5804375.087 550869.368 5804378.706 550868.293 5804376.971 550866.808 5804377.891 550866.245 5804376.983 550864.429 5804378.107 550866.066 5804380.751 550864.363 5804381.805 550856.074 5804386.939 550849.56 5804376.052 550848.919 5804374.981</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 20</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009Vg0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Vg0BL</gml:identifier>
<oid>DENIAL4300009Vg0BL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336679.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336679.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550856.074 5804386.939 550864.363 5804381.805 550866.952 5804386.703 550865.641 5804387.396 550866.626 5804389.26 550866.586 5804389.281 550872.619 5804398.454 550866.86 5804401.429 550864.217 5804400.55 550856.074 5804386.939</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 22</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HZMxBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HZMxBL</gml:identifier>
<oid>DENIAL430001HZMxBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336833.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336833.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550848.919 5804374.981 550860.009 5804368.182 550860.707 5804369.329 550849.56 5804376.052 550848.919 5804374.981</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HZMyBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HZMyBL</gml:identifier>
<oid>DENIAL430001HZMyBL</oid>
<aktualit>2026-04-02Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153336834.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153336834.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550848.326 5804373.989 550859.458 5804367.275 550860.009 5804368.182 550848.919 5804374.981 550848.326 5804373.989</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TJDBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TJDBL</gml:identifier>
<oid>DENIAL4300009TJDBL</oid>
<aktualit>2026-04-08Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.153337988.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.153337988.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550873.102 5804415.826 550873.793 5804413.299 550874.025 5804413.417 550885.076 5804407.692 550885.1 5804407.737 550889.636 5804416.245 550883.918 5804419.526 550884.886 5804421.213 550885.883 5804420.641 550887.638 5804423.7 550889.681 5804422.653 550893.224 5804428.856 550883.69 5804433.256 550873.322 5804415.827 550873.102 5804415.826</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 24</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052AzBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052AzBL</gml:identifier>
<oid>DENIAL43000052AzBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848823.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848823.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550522.812 5804376.219 550533.504 5804357.162 550534.322 5804357.621 550534.818 5804356.736 550553.79 5804367.371 550553.334 5804368.184 550554.129 5804368.629 550543.419 5804387.723 550542.635 5804387.283 550542.175 5804388.103 550523.232 5804377.467 550523.664 5804376.697 550522.812 5804376.219</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1D</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052LwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052LwBL</gml:identifier>
<oid>DENIAL43000052LwBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848825.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848825.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550481.081 5804400.48 550483.62 5804395.957 550484.957 5804396.707 550482.418 5804401.229 550481.081 5804400.48</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052UIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052UIBL</gml:identifier>
<oid>DENIAL43000052UIBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848827.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848827.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550457.065 5804420.787 550467.844 5804401.605 550468.687 5804402.079 550469.154 5804401.249 550477.89 5804406.165 550479.226 5804406.917 550488.087 5804411.904 550487.615 5804412.743 550488.491 5804413.235 550483.45 5804422.208 550482.754 5804423.447 550477.768 5804432.323 550476.915 5804431.845 550476.482 5804432.616 550457.687 5804422.062 550457.489 5804421.951 550457.884 5804421.248 550457.065 5804420.787</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1G; Spichernstraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052WiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052WiBL</gml:identifier>
<oid>DENIAL43000052WiBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848829.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848829.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550488.054 5804437.997 550492.995 5804429.198 550493.691 5804427.959 550498.692 5804419.054 550499.576 5804419.551 550500.092 5804418.632 550519.055 5804429.287 550518.609 5804430.08 550519.438 5804430.546 550514.422 5804439.48 550513.733 5804440.708 550508.707 5804449.661 550507.891 5804449.203 550507.45 5804449.989 550488.457 5804439.343 550488.935 5804438.491 550488.054 5804437.997</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052meBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052meBL</gml:identifier>
<oid>DENIAL43000052meBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848830.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848830.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550498.753 5804369.307 550501.143 5804365.051 550502.39 5804365.751 550500 5804370.006 550498.753 5804369.307</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oQBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oQBL</gml:identifier>
<oid>DENIAL43000052oQBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848831.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848831.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550474.443 5804389.864 550485.205 5804370.714 550486.017 5804371.171 550486.517 5804370.281 550495.4 5804375.279 550496.645 5804375.979 550505.49 5804380.956 550505.01 5804381.809 550505.847 5804382.279 550495.09 5804401.425 550494.255 5804400.956 550493.844 5804401.688 550484.957 5804396.707 550483.62 5804395.957 550474.852 5804391.043 550475.257 5804390.321 550474.443 5804389.864</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1E</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052saBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052saBL</gml:identifier>
<oid>DENIAL43000052saBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848832.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848832.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550536.376 5804424.484 550547.112 5804405.347 550547.925 5804405.804 550548.373 5804405.006 550567.385 5804415.682 550566.929 5804416.494 550567.778 5804416.971 550557.03 5804436.109 550556.198 5804435.642 550555.76 5804436.424 550536.768 5804425.788 550537.23 5804424.963 550536.376 5804424.484</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052uNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052uNBL</gml:identifier>
<oid>DENIAL43000052uNBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848834.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848834.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550491.884 5804358.789 550502.555 5804339.757 550503.376 5804340.217 550503.849 5804339.374 550506.269 5804340.732 550522.832 5804350.028 550522.349 5804350.889 550523.18 5804351.356 550512.466 5804370.447 550511.636 5804369.981 550511.227 5804370.71 550502.39 5804365.751 550501.143 5804365.051 550492.274 5804360.075 550492.73 5804359.263 550491.884 5804358.789</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kriegerstraße 1C</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005307BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005307BL</gml:identifier>
<oid>DENIAL4300005307BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848836.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848836.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550467.844 5804401.605 550474.443 5804389.864 550475.257 5804390.321 550474.852 5804391.043 550483.62 5804395.957 550481.081 5804400.48 550477.89 5804406.165 550469.154 5804401.249 550468.687 5804402.079 550467.844 5804401.605</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005354BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005354BL</gml:identifier>
<oid>DENIAL4300005354BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848837.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848837.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550513.733 5804440.708 550514.422 5804439.48 550519.421 5804442.287 550518.732 5804443.515 550513.733 5804440.708</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000535sBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000535sBL</gml:identifier>
<oid>DENIAL430000535sBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848838.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848838.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550518.732 5804443.515 550519.421 5804442.287 550524.71 5804445.256 550524.02 5804446.485 550518.732 5804443.515</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005365BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005365BL</gml:identifier>
<oid>DENIAL4300005365BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848839.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848839.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550477.89 5804406.165 550481.081 5804400.48 550482.418 5804401.229 550479.226 5804406.917 550477.89 5804406.165</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000539yBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000539yBL</gml:identifier>
<oid>DENIAL430000539yBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848840.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848840.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550482.754 5804423.447 550483.45 5804422.208 550488.12 5804424.83 550487.424 5804426.07 550482.754 5804423.447</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053CVBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053CVBL</gml:identifier>
<oid>DENIAL43000053CVBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848841.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848841.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550487.424 5804426.07 550488.12 5804424.83 550493.691 5804427.959 550492.995 5804429.198 550487.424 5804426.07</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053J8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053J8BL</gml:identifier>
<oid>DENIAL43000053J8BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848842.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848842.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550495.4 5804375.279 550498.753 5804369.307 550500 5804370.006 550496.645 5804375.979 550495.4 5804375.279</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053tjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053tjBL</gml:identifier>
<oid>DENIAL43000053tjBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848844.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848844.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550553.68 5804393.497 550564.377 5804374.426 550565.285 5804374.936 550565.755 5804374.098 550584.728 5804384.754 550584.234 5804385.634 550585.102 5804386.122 550574.399 5804405.181 550573.554 5804404.707 550573.123 5804405.476 550554.14 5804394.84 550554.603 5804394.014 550553.68 5804393.497</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053u1BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053u1BL</gml:identifier>
<oid>DENIAL43000053u1BL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848845.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848845.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550485.205 5804370.714 550491.884 5804358.789 550492.73 5804359.263 550492.274 5804360.075 550501.143 5804365.051 550498.753 5804369.307 550495.4 5804375.279 550486.517 5804370.281 550486.017 5804371.171 550485.205 5804370.714</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053wtBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053wtBL</gml:identifier>
<oid>DENIAL43000053wtBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848846.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848846.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550519.031 5804455.369 550524.02 5804446.485 550524.71 5804445.256 550529.721 5804436.332 550530.576 5804436.812 550531.03 5804436.004 550549.963 5804446.64 550549.514 5804447.44 550550.39 5804447.932 550539.677 5804467.004 550538.813 5804466.519 550538.357 5804467.332 550519.435 5804456.706 550519.909 5804455.862 550519.031 5804455.369</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053xFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053xFBL</gml:identifier>
<oid>DENIAL43000053xFBL</oid>
<aktualit>2026-07-17Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.156848847.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.156848847.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550571.07 5804362.496 550581.718 5804343.521 550582.628 5804344.031 550583.128 5804343.14 550602.121 5804353.786 550601.684 5804354.564 550602.547 5804355.049 550591.872 5804374.064 550591.005 5804373.581 550590.476 5804374.538 550571.463 5804363.862 550571.952 5804362.991 550571.07 5804362.496</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052J8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052J8BL</gml:identifier>
<oid>DENIAL43000052J8BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100284.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100284.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550663.34 5804404.757 550670.226 5804400.637 550671.731 5804402.869 550674.326 5804401.361 550669.703 5804395.082 550673.146 5804392.547 550674.434 5804394.079 550679.65 5804390.248 550685.718 5804398.387 550681.745 5804400.804 550684.4 5804404.974 550668.942 5804414.221 550663.34 5804404.757</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052JEBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052JEBL</gml:identifier>
<oid>DENIAL43000052JEBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100285.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100285.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550661.375 5804385.081 550661.685 5804384.853 550670.69 5804378.233 550679.65 5804390.248 550674.434 5804394.079 550673.146 5804392.547 550669.703 5804395.082 550669.075 5804395.544 550661.375 5804385.081</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 68</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052JqBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052JqBL</gml:identifier>
<oid>DENIAL43000052JqBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100286.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100286.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550574.089 5804446.635 550578.553 5804438.595 550577.484 5804438.002 550579.555 5804434.302 550580.621 5804434.899 550582.598 5804431.367 550592.56 5804436.942 550589.361 5804442.946 550586.861 5804443.835 550587.551 5804445.774 550588.86 5804445.308 550591.492 5804447.827 550590.697 5804448.659 550583.688 5804455.984 550574.089 5804446.635</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052R9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052R9BL</gml:identifier>
<oid>DENIAL43000052R9BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100287.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100287.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550650.591 5804412.385 550663.34 5804404.757 550668.942 5804414.221 550656.303 5804421.781 550650.591 5804412.385</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052rzBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052rzBL</gml:identifier>
<oid>DENIAL43000052rzBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100288.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100288.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550583.688 5804455.984 550590.697 5804448.659 550592.214 5804450.111 550594.778 5804448.58 550594.265 5804447.722 550598.207 5804445.368 550599.415 5804447.389 550605.874 5804443.532 550604.869 5804441.849 550609.61 5804439.017 550614.317 5804446.896 550589.945 5804461.376 550589.562 5804461.704 550589.334 5804461.576 550583.688 5804455.984</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 41</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ygBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ygBL</gml:identifier>
<oid>DENIAL43000052ygBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100289.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100289.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550592.276 5804414.424 550599.474 5804401.547 550609.245 5804407.009 550621.209 5804413.697 550619.775 5804418.267 550619.197 5804418.871 550609.226 5804413.302 550609.079 5804411.037 550606.889 5804411.179 550607.008 5804413.011 550602.967 5804420.329 550592.276 5804414.424</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052zWBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052zWBL</gml:identifier>
<oid>DENIAL43000052zWBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100290.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100290.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550582.598 5804431.367 550584.508 5804427.954 550583.383 5804427.325 550585.039 5804424.364 550586.233 5804425.032 550588.582 5804420.831 550587.388 5804420.163 550588.964 5804417.344 550590.245 5804418.06 550592.276 5804414.424 550602.967 5804420.329 550603.249 5804420.484 550598.916 5804428.424 550597.496 5804427.659 550592.995 5804436.108 550592.56 5804436.942 550582.598 5804431.367</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005308BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005308BL</gml:identifier>
<oid>DENIAL4300005308BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100291.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100291.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550622.936 5804363.611 550642.99 5804348.654 550649.607 5804357.478 550649.206 5804357.777 550633.867 5804369.256 550632.614 5804367.801 550630.114 5804369.759 550622.936 5804363.611</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000530BBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000530BBL</gml:identifier>
<oid>DENIAL430000530BBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100292.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100292.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550608.687 5804437.472 550625.348 5804427.496 550631.026 5804436.901 550614.317 5804446.896 550609.61 5804439.017 550608.687 5804437.472</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 39</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000534JBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000534JBL</gml:identifier>
<oid>DENIAL430000534JBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100293.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100293.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550606.637 5804388.735 550613.837 5804375.862 550623.579 5804381.353 550616.404 5804394.195 550606.637 5804388.735</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053DlBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053DlBL</gml:identifier>
<oid>DENIAL43000053DlBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100294.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100294.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550649.214 5804364.332 550652.23 5804361.833 550655.339 5804366.002 550659.344 5804363.016 550670.69 5804378.233 550661.685 5804384.853 550650.544 5804369.697 550652.241 5804368.45 550649.214 5804364.332</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 69</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053dWBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053dWBL</gml:identifier>
<oid>DENIAL43000053dWBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100295.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100295.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550613.837 5804375.862 550621.374 5804362.387 550622.936 5804363.611 550630.114 5804369.759 550623.579 5804381.353 550613.837 5804375.862</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053g0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053g0BL</gml:identifier>
<oid>DENIAL43000053g0BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100296.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100296.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550638.02 5804419.91 550650.591 5804412.385 550656.303 5804421.781 550643.664 5804429.341 550638.02 5804419.91</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 35</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053s7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053s7BL</gml:identifier>
<oid>DENIAL43000053s7BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100297.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100297.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550625.348 5804427.496 550638.02 5804419.91 550643.664 5804429.341 550631.026 5804436.901 550625.348 5804427.496</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 37</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053tfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053tfBL</gml:identifier>
<oid>DENIAL43000053tfBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100298.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100298.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550599.474 5804401.547 550606.637 5804388.735 550616.404 5804394.195 550609.245 5804407.009 550599.474 5804401.547</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Lützerodestraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052BaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052BaBL</gml:identifier>
<oid>DENIAL43000052BaBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100862.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100862.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550529.637 5804493.597 550533.028 5804484.128 550558.491 5804493.241 550554.035 5804505.686 550545.629 5804502.695 550546.596 5804499.978 550543.195 5804498.767 550543.318 5804498.561 550529.637 5804493.597</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052UNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052UNBL</gml:identifier>
<oid>DENIAL43000052UNBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100865.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100865.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550455.69 5804425.229 550457.458 5804422.083 550456.606 5804421.604 550457.065 5804420.787 550457.884 5804421.248 550457.489 5804421.951 550457.687 5804422.062 550476.482 5804432.616 550476.915 5804431.845 550477.768 5804432.323 550482.754 5804423.447 550487.424 5804426.07 550492.995 5804429.198 550488.054 5804437.997 550488.935 5804438.491 550488.457 5804439.343 550507.45 5804449.989 550507.891 5804449.203 550508.707 5804449.661 550513.733 5804440.708 550518.732 5804443.515 550524.02 5804446.485 550519.031 5804455.369 550519.909 5804455.862 550519.435 5804456.706 550538.357 5804467.332 550538.813 5804466.519 550539.677 5804467.004 550539.158 5804467.929 550538.28 5804467.435 550537.358 5804469.071 550530.081 5804464.963 550529.331 5804466.282 550481.35 5804439.633 550455.69 5804425.229</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052uqBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052uqBL</gml:identifier>
<oid>DENIAL43000052uqBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100868.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100868.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550501.998 5804560.656 550509.955 5804553.259 550512.74 5804556.254 550512.484 5804556.634 550514.754 5804558.979 550514.852 5804559.613 550515.583 5804560.505 550516.901 5804560.892 550517.412 5804560.361 550516.932 5804559.978 550516.836 5804559.091 550516.587 5804558.328 550517.838 5804557.319 550518.248 5804556.561 550517.713 5804555.938 550519.855 5804550.011 550516.598 5804548.834 550517.158 5804547.286 550516.406 5804547.014 550515.194 5804546.576 550515.147 5804546.559 550516.952 5804541.473 550527.357 5804545.249 550521.681 5804562.1 550516.787 5804576.629 550501.998 5804560.656</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 36</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000534fBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000534fBL</gml:identifier>
<oid>DENIAL430000534fBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100869.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100869.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550473.52 5804475.397 550477.511 5804464.259 550491.43 5804469.241 550488.057 5804478.465 550487.363 5804480.365 550473.52 5804475.397</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000539FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000539FBL</gml:identifier>
<oid>DENIAL430000539FBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100872.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100872.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550528.591 5804512.431 550530.891 5804506.029 550535.623 5804507.729 550535.263 5804508.729 550537.762 5804509.627 550539.499 5804512.621 550541.538 5804512.187 550540.291 5804509.604 550543.073 5804501.786 550545.629 5804502.695 550554.035 5804505.686 550548.996 5804519.757 550537.752 5804515.72 550530.197 5804513.008 550528.591 5804512.431</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000539mBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000539mBL</gml:identifier>
<oid>DENIAL430000539mBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100873.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100873.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550501.711 5804484.083 550505.303 5804474.206 550507.883 5804475.13 550519.166 5804479.167 550515.567 5804489.09 550504.323 5804485.027 550501.711 5804484.083</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053BTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053BTBL</gml:identifier>
<oid>DENIAL43000053BTBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100874.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100874.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550488.057 5804478.465 550491.43 5804469.241 550502.781 5804473.303 550505.303 5804474.206 550501.711 5804484.083 550500.947 5804486.184 550498.466 5804485.285 550493.035 5804483.317 550492.463 5804484.894 550488.368 5804483.406 550489.92 5804479.145 550488.057 5804478.465</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053EcBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053EcBL</gml:identifier>
<oid>DENIAL43000053EcBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100875.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100875.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550515.567 5804489.09 550519.166 5804479.167 550533.028 5804484.128 550529.637 5804493.597 550529.454 5804494.107 550515.567 5804489.09</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053pIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053pIBL</gml:identifier>
<oid>DENIAL43000053pIBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100877.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100877.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550459.507 5804470.255 550460.318 5804468.099 550463.632 5804459.292 550477.511 5804464.259 550473.52 5804475.397 550460.471 5804470.717 550459.507 5804470.255</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Spichernstraße 12</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rrBL</gml:identifier>
<oid>DENIAL43000053rrBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100878.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100878.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550456.851 5804517.896 550463.276 5804508.391 550475.281 5804517.69 550468.55 5804527.129 550456.851 5804517.896</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 28</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7yBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7yBL</gml:identifier>
<oid>DENIAL430001HJ7yBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100946.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100946.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550498.466 5804485.285 550502.781 5804473.303 550505.303 5804474.206 550501.711 5804484.083 550500.947 5804486.184 550498.466 5804485.285</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7zBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7zBL</gml:identifier>
<oid>DENIAL430001HJ7zBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100947.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100947.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550501.711 5804484.083 550505.303 5804474.206 550507.883 5804475.13 550504.323 5804485.027 550501.711 5804484.083</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001eXF9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001eXF9BL</gml:identifier>
<oid>DENIAL430001eXF9BL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100964.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100964.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550515.846 5804548.562 550516.406 5804547.014 550517.158 5804547.286 550516.598 5804548.834 550515.846 5804548.562</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8PBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8PBL</gml:identifier>
<oid>DENIAL430001fU8PBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100967.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100967.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550516.787 5804576.629 550521.681 5804562.1 550527.513 5804564.053 550525.775 5804569.249 550531.34 5804571.108 550527.541 5804582.495 550519.808 5804579.892 550516.787 5804576.629</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8RBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8RBL</gml:identifier>
<oid>DENIAL430001fU8RBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100968.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100968.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550521.681 5804562.1 550527.357 5804545.249 550538.632 5804549.329 550534.828 5804560.704 550529.256 5804558.84 550527.513 5804564.053 550521.681 5804562.1</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8XBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8XBL</gml:identifier>
<oid>DENIAL430001fU8XBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100969.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100969.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550489.98 5804505.008 550492.121 5804499.338 550495.694 5804500.621 550509.578 5804505.605 550522.627 5804510.29 550528.591 5804512.431 550530.197 5804513.008 550524.5 5804528.286 550518.817 5804526.151 550521.925 5804518.265 550519.903 5804515.747 550489.98 5804505.008</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001fU8YBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001fU8YBL</gml:identifier>
<oid>DENIAL430001fU8YBL</oid>
<aktualit>2026-07-20Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157100970.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157100970.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550492.794 5804550.716 550497.407 5804538.282 550498.673 5804534.871 550507.794 5804538.192 550506.424 5804541.955 550502.66 5804540.584 550501.601 5804543.492 550501.903 5804544.601 550509.955 5804553.259 550501.998 5804560.656 550492.794 5804550.716</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 34</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VlsBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VlsBL</gml:identifier>
<oid>DENIAL4300009VlsBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157101905.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157101905.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550708.639 5804374.756 550730.178 5804361.866 550730.04 5804361.821 550734.848 5804358.962 550734.928 5804359.032 550740.396 5804355.723 550743.634 5804356.543 550743.734 5804356.713 550754.75 5804350.125 550755.093 5804350.699 550763.996 5804345.367 550768.911 5804353.569 550765.974 5804355.329 550766.232 5804355.759 550763.233 5804357.556 550762.975 5804357.126 550760.037 5804358.886 550760.402 5804359.494 550715.771 5804386.222 550708.639 5804374.756</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 27</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300012aEXBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300012aEXBL</gml:identifier>
<oid>DENIAL4300012aEXBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157101969.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157101969.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550692.946 5804365.839 550703.389 5804359.61 550703.37133995 5804359.7912898 550703.3570291 5804360.08054677 550703.35966451 5804360.37014553 550703.37 5804360.552 550703.39253556 5804360.78007683 550703.43914788 5804361.08320765 550703.50034346 5804361.36645531 550703.57799414 5804361.64564075 550703.67780577 5804361.93563841 550703.764 5804362.148 550694.182 5804367.893 550692.946 5804365.839</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009UBGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009UBGBL</gml:identifier>
<oid>DENIAL4300009UBGBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102064.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102064.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550720.281 5804408.702 550723.06 5804407.034 550722.849 5804406.682 550729.16 5804402.893 550729.371 5804403.245 550735.709 5804399.44 550735.483 5804399.063 550742.506 5804394.847 550742.733 5804395.224 550748.536 5804391.741 550748.288 5804391.329 550755.337 5804387.1 550755.583 5804387.51 550755.865 5804387.341 550758.158 5804385.966 550763.15 5804382.974 550762.879 5804382.522 550769.262 5804378.695 550769.533 5804379.148 550778.48 5804373.784 550778.242 5804373.387 550784.504 5804369.632 550784.743 5804370.03 550789.323 5804367.285 550793.882 5804374.901 550787.55 5804378.701 550788.582 5804380.421 550785.539 5804382.247 550784.507 5804380.527 550772.379 5804387.804 550773.361 5804389.44 550770.304 5804391.275 550769.322 5804389.638 550762.732 5804393.592 550760.44 5804394.968 550758.652 5804396.041 550759.189 5804396.936 550755.401 5804399.209 550754.864 5804398.314 550745.763 5804403.776 550746.283 5804404.643 550742.495 5804406.916 550741.975 5804406.049 550735.761 5804409.779 550734.106 5804410.772 550726.939 5804415.074 550724.857 5804416.324 550720.281 5804408.702</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für öffentliche Zwecke</funktion>
<gfkzshh>31001_3000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 22</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009UzhBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009UzhBL</gml:identifier>
<oid>DENIAL4300009UzhBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102065.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102065.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550789.013 5804366.766 550801.333 5804359.388 550833.678 5804413.377 550821.336 5804420.768 550820.983 5804420.179 550816.554 5804412.779 550812.919 5804406.707 550797.358 5804380.708 550793.882 5804374.901 550789.323 5804367.285 550789.013 5804366.766</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für öffentliche Zwecke</funktion>
<gfkzshh>31001_3000</gfkzshh>
<name>St. Nikolai-Stift</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bürgerstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VLaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VLaBL</gml:identifier>
<oid>DENIAL4300009VLaBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102066.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102066.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550726.939 5804415.074 550734.106 5804410.772 550736.722 5804415.122 550741.218 5804422.598 550743.096 5804421.467 550743.819 5804422.667 550744.05439967 5804422.81351686 550744.29921185 5804422.99945271 550744.5106723 5804423.19408402 550744.6912344 5804423.39237984 550744.84377305 5804423.59040045 550744.97131502 5804423.78517796 550745.08412636 5804423.9888415 550745.18814821 5804424.21612911 550745.27934359 5804424.468334 550745.35288668 5804424.74616179 550745.40318296 5804425.0494363 550745.423 5804425.326 550748.803 5804430.932 550749.05844739 5804431.10145481 550749.30863515 5804431.30143693 550749.52596752 5804431.50886492 550749.7128669 5804431.71920291 550749.87208336 5804431.92887265 550750.00647842 5804432.13514752 550750.12620253 5804432.35026955 550750.23734645 5804432.58892895 550750.33616332 5804432.85238422 550750.41820507 5804433.14139785 550750.47832959 5804433.4559957 550750.509 5804433.761 550751.188 5804434.887 550750.422 5804435.348 550755.216 5804443.318 550757.992 5804447.932 550759.933 5804446.767 550762.777 5804445.059 550762.541 5804444.668 550770.112 5804440.122 550770.348 5804440.514 550775.342 5804437.516 550775.129 5804437.163 550782.594 5804432.681 550782.806 5804433.035 550783.107 5804432.854 550785.463 5804431.44 550792.08 5804427.468 550791.112 5804425.856 550794.033 5804424.103 550795.001 5804425.716 550807.304 5804418.331 550806.3 5804416.658 550809.256 5804414.884 550810.26 5804416.557 550816.554 5804412.779 550820.983 5804420.179 550817.222 5804422.439 550817.524 5804422.942 550810.315 5804427.275 550810.013 5804426.772 550801.163 5804432.092 550801.419 5804432.519 550795.088 5804436.325 550794.831 5804435.898 550789.916 5804438.853 550787.562 5804440.268 550785.797 5804441.33 550786.252 5804442.087 550782.414 5804444.396 550781.958 5804443.639 550772.877 5804449.102 550773.347 5804449.884 550769.533 5804452.178 550769.063 5804451.397 550762.691 5804455.23 550762.844 5804455.484 550756.685 5804459.189 550756.532 5804458.935 550753.726 5804460.623 550749.149 5804453.079 550750.044 5804452.531 550742.583 5804440.435 550740.931 5804441.454 550737.944 5804436.616 550738.144 5804436.493 550736.063 5804433.123 550735.863 5804433.246 550732.705 5804428.131 550734.362 5804427.109 550726.939 5804415.074</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für öffentliche Zwecke</funktion>
<gfkzshh>31001_3000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009W6IBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009W6IBL</gml:identifier>
<oid>DENIAL4300009W6IBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102067.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102067.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550829.31 5804485.566 550848.863 5804473.785 550849.591 5804474.994 550849.183 5804475.239 550854.986 5804484.876 550835.845 5804496.411 550829.31 5804485.566</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Sport-, Turnhalle</funktion>
<gfkzshh>31001_3211</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WcJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WcJBL</gml:identifier>
<oid>DENIAL4300009WcJBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102068.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102068.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550837.049 5804434.314 550850.542 5804426.24 550855.366 5804434.291 550856.247 5804433.763 550858.427 5804437.401 550857.546 5804437.929 550861.982 5804445.331 550862.937 5804444.759 550865.101 5804448.371 550864.146 5804448.943 550869.086 5804457.186 550867.689 5804458.024 550870.26 5804462.304 550877.968 5804457.668 550884.545 5804468.588 550856.056 5804485.764 550855.378 5804484.64 550854.986 5804484.876 550849.183 5804475.239 550849.591 5804474.994 550857.032 5804470.515 550860.038 5804468.707 550857.347 5804464.229 550855.598 5804465.278 550850.729 5804457.15 550848.839 5804458.282 550846.664 5804454.652 550848.554 5804453.519 550844.12 5804446.118 550842.232 5804447.249 550840.046 5804443.601 550841.934 5804442.47 550837.049 5804434.314</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Ricarda-Huch-Schule Außenstelle</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Edenstraße 23</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WmGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WmGBL</gml:identifier>
<oid>DENIAL4300009WmGBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102069.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102069.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550767.042 5804479.609 550773.524 5804475.482 550773.3 5804475.13 550776.566 5804473.05 550776.791 5804473.402 550783.368 5804469.214 550793.58 5804485.255 550794.301 5804484.796 550797.049 5804489.112 550796.327 5804489.571 550808.658 5804508.939 550798.697 5804515.28 550796.575 5804511.946 550790.167 5804516.024 550784.717 5804507.462 550790.25 5804503.94 550785.063 5804495.79 550781.863 5804497.827 550780.004 5804494.907 550783.205 5804492.87 550777.879 5804484.502 550772.383 5804488 550767.042 5804479.609</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Comeniusschule</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZz7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZz7BL</gml:identifier>
<oid>DENIAL430001jZz7BL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102104.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102104.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550755.865 5804387.341 550758.158 5804385.966 550762.732 5804393.592 550760.44 5804394.968 550755.865 5804387.341</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZz8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZz8BL</gml:identifier>
<oid>DENIAL430001jZz8BL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102105.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102105.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550783.107 5804432.854 550785.463 5804431.44 550789.916 5804438.853 550787.562 5804440.268 550783.107 5804432.854</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZz9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZz9BL</gml:identifier>
<oid>DENIAL430001jZz9BL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102106.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102106.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550734.106 5804410.772 550735.761 5804409.779 550738.374 5804414.13 550736.722 5804415.122 550734.106 5804410.772</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZzaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZzaBL</gml:identifier>
<oid>DENIAL430001jZzaBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102107.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102107.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550755.216 5804443.318 550757.16 5804442.15 550759.933 5804446.767 550757.992 5804447.932 550755.216 5804443.318</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001k0BIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001k0BIBL</gml:identifier>
<oid>DENIAL430001k0BIBL</oid>
<aktualit>2026-07-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102108.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102108.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550855.598 5804465.278 550857.347 5804464.229 550860.038 5804468.707 550857.032 5804470.515 550855.598 5804465.278</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052MJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052MJBL</gml:identifier>
<oid>DENIAL43000052MJBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102263.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102263.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550585.91 5804487.125 550589.751 5804484.817 550589.177 5804483.862 550592.841 5804481.66 550593.415 5804482.616 550596.893 5804480.526 550596.319 5804479.571 550599.792 5804477.484 550600.366 5804478.44 550603.648 5804476.467 550610.534 5804487.93 550608.837 5804488.95 550607 5804490.053 550607.788 5804491.365 550605.112 5804492.973 550601.845 5804492.948 550601.456 5804492.251 550600.045 5804493.038 550601.629 5804495.41 550602.277 5804495.47 550602.51 5804495.857 550605.613 5804501.025 550599.062 5804504.96 550594.634 5804497.587 550592.839 5804498.665 550585.91 5804487.125</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 44</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052UUBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052UUBL</gml:identifier>
<oid>DENIAL43000052UUBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102264.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102264.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550669.591 5804514.771 550672.299 5804512.694 550681.648 5804505.524 550680.12 5804503.521 550678.726 5804504.58 550673.936 5804498.245 550679.359 5804494.164 550692.425 5804511.607 550687.872 5804515.025 550679.199 5804521.685 550676.51 5804523.75 550669.591 5804514.771</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 16</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ZtBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ZtBL</gml:identifier>
<oid>DENIAL43000052ZtBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102265.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102265.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550692.729 5804446.426 550700.6 5804441.032 550699.454 5804439.292 550700.121 5804438.852 550709.661 5804432.568 550716.821 5804443.43 550707.852 5804449.378 550706.713 5804447.661 550703.908 5804449.522 550702.555 5804447.481 550701.228 5804448.361 550701.987 5804449.506 550697.931 5804452.196 550695.885 5804449.109 550694.541 5804449.07 550692.729 5804446.426</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 66</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oKBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oKBL</gml:identifier>
<oid>DENIAL43000052oKBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102266.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102266.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550670.779 5804436.473 550671.467 5804436.056 550671.034 5804435.342 550673.601 5804433.785 550674.034 5804434.5 550676.31 5804433.12 550676.244 5804433.011 550676.382 5804432.927 550676.421 5804431.524 550678.948 5804430.035 550680.184 5804430.7 550680.294 5804430.633 550680.326 5804430.686 550683.607 5804428.696 550688.886 5804437.403 550688.099 5804437.878 550686.333 5804439.334 550687.001 5804440.453 550682.275 5804443.273 550680.874 5804443.259 550680.861 5804444.486 550682.751 5804445.059 550683.513 5804444.785 550684.198 5804444.918 550685.657 5804447.015 550687.426 5804447.215 550690.281 5804452.089 550683 5804456.525 550676.442 5804445.765 550670.779 5804436.473</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 34</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052s2BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052s2BL</gml:identifier>
<oid>DENIAL43000052s2BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102267.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102267.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550683.607 5804428.696 550689.097 5804425.368 550688.53 5804424.433 550692.11 5804422.263 550692.677 5804423.198 550698.95 5804419.395 550701.124 5804419.586 550709.661 5804432.568 550700.121 5804438.852 550697.084 5804434.242 550697.211 5804433.516 550696.734 5804432.845 550695.094 5804432.759 550694.974 5804435.045 550693.4 5804436.25 550691.255 5804435.974 550688.886 5804437.403 550683.607 5804428.696</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052tiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052tiBL</gml:identifier>
<oid>DENIAL43000052tiBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102268.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102268.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550671.335 5804448.866 550676.442 5804445.765 550683 5804456.525 550682.147 5804457.044 550677.886 5804459.64 550671.335 5804448.866</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052wMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052wMBL</gml:identifier>
<oid>DENIAL43000052wMBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102269.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102269.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550698.969 5804455.27 550707.852 5804449.378 550716.821 5804443.43 550726.728 5804458.458 550717.387 5804464.658 550716.368 5804465.334 550715.229 5804463.617 550710.784 5804466.567 550709.436 5804464.673 550709.479 5804462.538 550707.75 5804460.103 550711.553 5804457.401 550711.938 5804457.723 550712.987 5804457.046 550710.327 5804452.923 550706.293 5804455.526 550704.848 5804456.299 550701.24 5804458.693 550698.969 5804455.27</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 65</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005339BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005339BL</gml:identifier>
<oid>DENIAL4300005339BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102270.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102270.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550573.216 5804548.824 550576.827 5804538.895 550592.711 5804544.671 550594.039 5804541.018 550608.869 5804546.409 550609.495 5804544.685 550609.50395973 5804544.6374732 550609.57831368 5804544.39792713 550609.68619783 5804544.1935279 550609.81438069 5804544.02659135 550609.95183453 5804543.895283 550610.09041333 5804543.79544206 550610.22469894 5804543.72202439 550610.36664786 5804543.66481179 550610.53174432 5804543.62104584 550610.7204494 5804543.59811487 550610.93081068 5804543.60495517 550611.15724922 5804543.65125446 550611.38957989 5804543.74577053 550611.432 5804543.769 550615.797 5804545.117 550615.512 5804543.381 550622.948 5804542.156 550623.757 5804547.067 550623.941 5804547.301 550634.722 5804538.806 550628.942 5804531.465 550632.704 5804528.505 550632.311 5804528.006 550636.759 5804524.498 550637.156 5804525.001 550641.226 5804521.798 550638.857 5804518.777 550632.8 5804523.508 550630.915 5804521.085 550628.592 5804522.908 550622.415 5804515.102 550624.805 5804513.227 550621.925 5804509.524 550636.266 5804498.386 550635.029 5804496.789 550642.276 5804491.191 550646.291 5804496.333 550646.755 5804495.969 550652.892 5804503.786 550652.407 5804504.165 550656.678 5804509.633 550657.161 5804509.254 550663.338 5804517.09 550668.362 5804513.175 550669.591 5804514.771 550676.51 5804523.75 550676.036 5804524.114 550675.266 5804523.119 550674.747 5804523.522 550672.398 5804525.35 550668.55 5804528.343 550669.319 5804529.326 550656.157 5804539.695 550651.159 5804543.757 550649.454 5804541.661 550627.319 5804559.669 550627.334 5804561.013 550625.8 5804563.605 550624.304 5804564.21 550621.788 5804564.679 550620.491 5804564.391 550617.899 5804562.823 550617.501 5804561.575 550599.596 5804555.169 550598.613 5804557.916 550573.216 5804548.824</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Ricarda-Huch-Schule</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 15</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000534RBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000534RBL</gml:identifier>
<oid>DENIAL430000534RBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102271.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102271.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550600.045 5804493.038 550601.456 5804492.251 550601.845 5804492.948 550605.112 5804492.973 550607.788 5804491.365 550607 5804490.053 550608.837 5804488.95 550610.208 5804491.233 550602.51 5804495.857 550602.277 5804495.47 550601.629 5804495.41 550600.045 5804493.038</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053D9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053D9BL</gml:identifier>
<oid>DENIAL43000053D9BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102272.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102272.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550655.372 5804445.815 550657.709 5804444.398 550670.779 5804436.473 550676.442 5804445.765 550671.335 5804448.866 550663.356 5804453.708 550661.001 5804455.138 550655.372 5804445.815</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Drostestraße 36</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053E0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053E0BL</gml:identifier>
<oid>DENIAL43000053E0BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102273.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102273.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550717.387 5804464.658 550726.728 5804458.458 550739.386 5804477.659 550724.718 5804488.013 550718.914 5804479.806 550724.264 5804476.023 550724.111 5804475.806 550725.846 5804474.509 550723.578 5804471.476 550722.264 5804472.008 550717.387 5804464.658</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 64</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053eUBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053eUBL</gml:identifier>
<oid>DENIAL43000053eUBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102274.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102274.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550693.253 5804478.942 550698.134 5804475.34 550703.338 5804482.396 550702.297 5804483.163 550703.572 5804484.892 550705.248 5804484.922 550711.77 5804480.032 550712.014 5804478.677 550710.734 5804476.942 550709.563 5804477.805 550704.358 5804470.748 550708.596 5804467.622 550711.136 5804468.807 550718.914 5804479.806 550724.718 5804488.013 550720.262 5804491.159 550719.651 5804490.3 550712.064 5804495.725 550712.709 5804496.621 550708.456 5804499.698 550693.253 5804478.942</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053jPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053jPBL</gml:identifier>
<oid>DENIAL43000053jPBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102275.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102275.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550589.584 5804534.171 550590.266 5804532.224 550593.172 5804533.248 550598.647 5804517.82 550606.01 5804520.451 550606.807 5804520.736 550606.971 5804521.941 550603.678 5804524.179 550598.832 5804537.358 550589.584 5804534.171</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053ucBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053ucBL</gml:identifier>
<oid>DENIAL43000053ucBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102276.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102276.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550676.964 5804490.965 550681.9 5804487.321 550687.091 5804494.354 550685.871 5804495.255 550686.902 5804496.651 550688.941 5804497.046 550695.536 5804492.318 550695.713 5804490.507 550694.511 5804488.878 550693.386 5804489.708 550688.195 5804482.674 550693.253 5804478.942 550708.456 5804499.698 550704.209 5804502.771 550703.573 5804501.9 550695.79 5804507.637 550696.479 5804508.564 550692.425 5804511.607 550679.359 5804494.164 550676.964 5804490.965</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053uuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053uuBL</gml:identifier>
<oid>DENIAL43000053uuBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102277.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102277.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550573.654 5804505.859 550574.984 5804502.148 550576.289 5804502.615 550577.892 5804498.14 550576.588 5804497.672 550577.956 5804493.853 550579.261 5804494.32 550581.195 5804488.923 550582.274 5804489.31 550585.91 5804487.125 550592.839 5804498.665 550593.107 5804499.111 550591.717 5804499.946 550587.54 5804511.634 550586.526 5804511.272 550585.823 5804513.239 550585.742 5804513.21 550574 5804509.003 550574.959 5804506.326 550573.654 5804505.859</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053yYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053yYBL</gml:identifier>
<oid>DENIAL43000053yYBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102278.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102278.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550567.739 5804526.448 550568.821 5804523.453 550569.219 5804522.352 550568.185 5804521.979 550569.239 5804519.046 550570.268 5804519.415 550571.491 5804516.004 550570.464 5804515.635 550571.455 5804512.874 550572.48 5804513.242 550574 5804509.003 550585.742 5804513.21 550585.064 5804515.1 550592.783 5804517.839 550590.329 5804524.756 550584.703 5804522.761 550582.648 5804522.874 550580.854 5804527.814 550579.784 5804530.76 550574.488 5804528.878 550567.739 5804526.448</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053zSBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053zSBL</gml:identifier>
<oid>DENIAL43000053zSBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102279.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102279.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550557.289 5804541.238 550563.136 5804524.782 550567.739 5804526.448 550574.488 5804528.878 550572.343 5804534.832 550569.788 5804534.893 550569.83 5804536.649 550570.3 5804536.975 550570.891 5804536.737 550576.827 5804538.895 550573.216 5804548.824 550557.937 5804543.409 550557.289 5804541.238</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000123T4BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000123T4BL</gml:identifier>
<oid>DENIAL43000123T4BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102356.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102356.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550671.101 5804471.106 550678.044 5804466.824 550680.813 5804471.314 550674.128 5804476.013 550671.101 5804471.106</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000123T5BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000123T5BL</gml:identifier>
<oid>DENIAL43000123T5BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102357.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102357.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550655.372 5804445.815 550657.709 5804444.398 550663.356 5804453.708 550661.001 5804455.138 550655.372 5804445.815</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000123T6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000123T6BL</gml:identifier>
<oid>DENIAL43000123T6BL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102358.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102358.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550677.563 5804459.953 550681.943 5804457.35 550684.732 5804462.044 550680.352 5804464.646 550677.563 5804459.953</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7ABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7ABL</gml:identifier>
<oid>DENIAL430001HJ7ABL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102361.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102361.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550567.739 5804526.448 550568.821 5804523.453 550580.854 5804527.814 550579.784 5804530.76 550574.488 5804528.878 550567.739 5804526.448</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7BBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7BBL</gml:identifier>
<oid>DENIAL430001HJ7BBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102362.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102362.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550669.591 5804514.771 550672.299 5804512.694 550679.199 5804521.685 550676.51 5804523.75 550669.591 5804514.771</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7CBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7CBL</gml:identifier>
<oid>DENIAL430001HJ7CBL</oid>
<aktualit>2026-07-22Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157102363.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157102363.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550666.253 5804517.45 550668.603 5804515.622 550674.747 5804523.522 550672.398 5804525.35 550666.253 5804517.45</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052A6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052A6BL</gml:identifier>
<oid>DENIAL43000052A6BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330369.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330369.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550572.954 5804573.682 550573.101 5804569.116 550574.989 5804568.499 550575.633 5804566.776 550575.052 5804565.445 550576.128 5804562.932 550591.484 5804568.483 550594.719 5804569.652 550590.928 5804580.139 550587.701 5804578.98 550583.634 5804577.518 550572.954 5804573.682</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Ulrichstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052BqBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052BqBL</gml:identifier>
<oid>DENIAL43000052BqBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330370.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330370.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550572.196 5804585.065 550574.509 5804578.543 550581.927 5804581.164 550579.616 5804587.694 550579.359 5804587.603 550572.196 5804585.065</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052K8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052K8BL</gml:identifier>
<oid>DENIAL43000052K8BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330371.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330371.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550582.289 5804581.292 550583.634 5804577.518 550587.701 5804578.98 550590.928 5804580.139 550590.342 5804581.761 550589.944 5804582.862 550587.563 5804583.156 550585.801 5804582.533 550582.289 5804581.292</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<rellage>Unter der Erdoberfläche</rellage>
<name>Ke.</name>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052QEBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052QEBL</gml:identifier>
<oid>DENIAL43000052QEBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330372.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330372.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550539.09 5804597.085 550540.356 5804593.559 550541.302 5804590.924 550541.364 5804590.946 550543.833 5804584.064 550544.964 5804580.912 550545.045 5804580.58 550553.837 5804583.746 550555.287 5804584.268 550554.045 5804587.727 550561.956 5804590.564 550563.687 5804585.725 550568.147 5804587.317 550567.556 5804588.977 550570.444 5804590.004 550570.151 5804590.831 550563.804 5804608.727 550562.299 5804611.087 550560.174 5804609.733 550560.141 5804609.785 550556.033 5804607.165 550555.964 5804607.274 550553.615 5804606.182 550553.774 5804605.697 550542.516 5804598.315 550541.661 5804598.008 550539.09 5804597.085</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 12; Voßstraße 38</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052QRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052QRBL</gml:identifier>
<oid>DENIAL43000052QRBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330373.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330373.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550579.245 5804587.924 550579.359 5804587.603 550579.616 5804587.694 550581.927 5804581.164 550582.289 5804581.292 550585.801 5804582.533 550587.563 5804583.156 550589.102 5804593.691 550585.05 5804594.119 550584.558 5804589.806 550579.245 5804587.924</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052nlBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052nlBL</gml:identifier>
<oid>DENIAL43000052nlBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330374.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330374.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550612.793 5804605.3 550618.949 5804602.169 550620.103 5804600.748 550616.331 5804593.096 550621.551 5804590.522 550620.823 5804589.047 550625.372 5804586.715 550626.832 5804589.569 550627.146 5804589.409 550629.024 5804593.081 550628.71 5804593.241 550630.38 5804596.505 550630.709 5804596.337 550632.712 5804600.254 550632.384 5804600.422 550634.71 5804604.971 550617.2 5804613.963 550612.793 5804605.3</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052v6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052v6BL</gml:identifier>
<oid>DENIAL43000052v6BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330376.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330376.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550570.151 5804590.831 550570.444 5804590.004 550571.795 5804586.196 550580.813 5804589.394 550579.527 5804593.02 550575.703 5804591.664 550575.345 5804592.673 550570.151 5804590.831</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005341BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005341BL</gml:identifier>
<oid>DENIAL4300005341BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330377.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330377.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550562.273 5804611.128 550562.299 5804611.087 550563.804 5804608.727 550570.151 5804590.831 550575.345 5804592.673 550578.042 5804593.629 550577.896 5804594.041 550576.023 5804599.32 550574.529 5804598.79 550573.578 5804600.874 550572.434 5804601.019 550572.174 5804601.856 550572.19 5804602.967 550575.267 5804604.903 550575.75 5804604.136 550579.739 5804606.645 550581.925 5804608.02 550574.913 5804619.17 550572.764 5804617.73 550562.273 5804611.128</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 42</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053GMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053GMBL</gml:identifier>
<oid>DENIAL43000053GMBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330378.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330378.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550574.913 5804619.17 550581.925 5804608.02 550583.309 5804605.819 550587.11 5804608.208 550585.804 5804610.285 550588.907 5804612.236 550588.663 5804612.624 550590.21 5804613.597 550592.247 5804612.537 550591.103 5804610.337 550594.195 5804608.728 550595.371 5804610.989 550601.259 5804622.307 550589.513 5804628.471 550574.913 5804619.17</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 44</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053L8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053L8BL</gml:identifier>
<oid>DENIAL43000053L8BL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330379.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330379.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550608.28 5804585.319 550611.611 5804575.731 550621.591 5804579.323 550623.296 5804582.664 550623.6 5804582.508 550625.676 5804586.559 550625.372 5804586.715 550620.823 5804589.047 550621.551 5804590.522 550616.331 5804593.096 550616.07 5804593.225 550615.365 5804591.902 550614.5 5804590.279 550614.917 5804590.102 550613.318 5804587.069 550608.28 5804585.319</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053eCBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053eCBL</gml:identifier>
<oid>DENIAL43000053eCBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330380.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330380.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550547.475 5804568.859 550552.626 5804554.278 550563.051 5804558.171 550557.849 5804572.608 550556.915 5804572.271 550547.475 5804568.859</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053fPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053fPBL</gml:identifier>
<oid>DENIAL43000053fPBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330381.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330381.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550590.342 5804581.761 550590.928 5804580.139 550594.719 5804569.652 550595.275 5804569.852 550611.611 5804575.731 550608.28 5804585.319 550607.794 5804586.716 550605.653 5804587.262 550590.342 5804581.761</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Ulrichstraße 1A</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053nKBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053nKBL</gml:identifier>
<oid>DENIAL43000053nKBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330382.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330382.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550543.521 5804579.991 550547.475 5804568.859 550556.915 5804572.271 550557.849 5804572.608 550553.837 5804583.746 550545.045 5804580.58 550543.521 5804579.991</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053wSBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053wSBL</gml:identifier>
<oid>DENIAL43000053wSBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330383.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330383.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550595.371 5804610.989 550604.881 5804606.042 550604.236 5804604.757 550603.168 5804605.292 550600.619 5804600.212 550603.905 5804598.563 550604.431 5804599.611 550607.25 5804598.343 550610.372 5804604.483 550611.965 5804603.672 550612.793 5804605.3 550617.2 5804613.963 550615.396 5804614.89 550601.259 5804622.307 550595.371 5804610.989</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7EBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7EBL</gml:identifier>
<oid>DENIAL430001HJ7EBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330428.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330428.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550543.833 5804584.064 550544.964 5804580.912 550545.045 5804580.58 550553.837 5804583.746 550555.287 5804584.268 550554.045 5804587.727 550543.833 5804584.064</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7FBL</gml:identifier>
<oid>DENIAL430001HJ7FBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330429.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330429.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550572.764 5804617.73 550579.739 5804606.645 550581.925 5804608.02 550574.913 5804619.17 550572.764 5804617.73</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7GBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7GBL</gml:identifier>
<oid>DENIAL430001HJ7GBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330430.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330430.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550587.701 5804578.98 550591.484 5804568.483 550594.719 5804569.652 550590.928 5804580.139 550587.701 5804578.98</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ7HBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ7HBL</gml:identifier>
<oid>DENIAL430001HJ7HBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330431.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330431.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550575.345 5804592.673 550575.703 5804591.664 550579.527 5804593.02 550579.979 5804593.18 550579.475 5804594.601 550577.896 5804594.041 550578.042 5804593.629 550575.345 5804592.673</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001NjccBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001NjccBL</gml:identifier>
<oid>DENIAL430001NjccBL</oid>
<aktualit>2026-07-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157330442.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157330442.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550537.635 5804597.562 550539.098 5804593.509 550540.356 5804593.559 550539.09 5804597.085 550541.661 5804598.008 550540.817 5804599.083 550537.635 5804597.562</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052D4BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052D4BL</gml:identifier>
<oid>DENIAL43000052D4BL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331433.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331433.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550625.354 5804691.608 550633.335 5804688.585 550635.682 5804694.781 550637.066 5804694.097 550639.049 5804698.111 550647.209 5804694.1 550651.808 5804703.456 550634.627 5804711.944 550632.855 5804711.182 550625.354 5804691.608</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 52</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052KmBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052KmBL</gml:identifier>
<oid>DENIAL43000052KmBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331434.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331434.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550604.612 5804637.479 550619.766 5804629.521 550623.048 5804638.128 550618.634 5804640.552 550617.73 5804638.906 550615.78 5804639.977 550616.791 5804643.516 550615.02 5804644.185 550615.928 5804646.589 550618.95 5804645.447 550622.295 5804654.302 550612.48 5804658.011 550604.612 5804637.479</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 46</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NeBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NeBL</gml:identifier>
<oid>DENIAL43000052NeBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331435.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331435.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550618.917 5804674.809 550630.207 5804670.544 550630.888 5804672.361 550638.912 5804669.354 550641.594 5804676.51 550635.808 5804678.678 550634.913 5804678.317 550633.132 5804678.972 550633.719 5804680.567 550634.533 5804681.273 550636.649 5804687.33 550633.335 5804688.585 550625.354 5804691.608 550618.917 5804674.809</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 50</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052PZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052PZBL</gml:identifier>
<oid>DENIAL43000052PZBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331436.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331436.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550659.903 5804674.65 550668.018 5804670.667 550670.697 5804676.124 550670.477 5804677.377 550668.356 5804678.405 550669.609 5804680.991 550670.927 5804680.125 550678.512 5804676.404 550681.098 5804681.707 550682.724 5804681.004 550685.53 5804686.795 550667.947 5804695.482 550663.936 5804687.289 550662.461 5804684.277 550664.206 5804683.421 550659.903 5804674.65</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 29</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000530FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000530FBL</gml:identifier>
<oid>DENIAL430000530FBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331437.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331437.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550689.874 5804653.41 550692.688 5804652.011 550691.655 5804649.934 550702.133 5804644.727 550704.068 5804648.653 550705.398 5804647.998 550707.58 5804652.426 550706.249 5804653.081 550708.037 5804656.71 550699.602 5804660.843 550698.349 5804661.457 550697.173 5804659.056 550697.44 5804658.426 550696.503 5804656.617 550695.09 5804656.134 550691.993 5804657.674 550689.874 5804653.41</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 12</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005340BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005340BL</gml:identifier>
<oid>DENIAL4300005340BL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331438.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331438.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550638.248 5804624.365 550655.711 5804616.015 550655.244 5804615.037 550661.39 5804612.098 550661.618 5804612.573 550661.414 5804612.67 550661.637 5804613.136 550679.161 5804604.75 550680.965 5804608.52 550683.18 5804607.46 550688.264 5804618.086 550683.778 5804620.232 550685.576 5804623.992 550676.844 5804628.169 550680.485 5804635.782 550661.322 5804644.946 550657.711 5804637.394 550648.961 5804641.578 550647.048 5804637.576 550642.534 5804639.734 550639.03 5804632.406 550641.274 5804631.332 550640.33 5804629.357 550640.578 5804629.239 550638.248 5804624.365</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Allgemein bildende Schule</funktion>
<gfkzshh>31001_3021</gfkzshh>
<name>Bonifatiusschule</name>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053AuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053AuBL</gml:identifier>
<oid>DENIAL43000053AuBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331439.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331439.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550645.13 5804689.87 550649.783 5804687.584 550647.554 5804683.049 550653.136 5804680.306 550652.381 5804678.77 550655.513 5804677.232 550656.303 5804678.839 550656.343 5804678.819 550658.502 5804683.215 550659.812 5804683.353 550662.164 5804688.157 550663.936 5804687.289 550667.947 5804695.482 550651.808 5804703.456 550647.209 5804694.1 550645.13 5804689.87</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053EIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053EIBL</gml:identifier>
<oid>DENIAL43000053EIBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331440.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331440.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550695.621 5804670.161 550701.09 5804667.46 550702.543 5804667.613 550703.543 5804667.123 550702.674 5804665.35 550701.977 5804665.691 550699.602 5804660.843 550708.037 5804656.71 550709.963 5804660.62 550711.145 5804660.038 550713.182 5804664.174 550712.001 5804664.756 550715.551 5804671.963 550700.244 5804679.525 550695.621 5804670.161</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 25</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053evBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053evBL</gml:identifier>
<oid>DENIAL43000053evBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331441.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331441.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550612.48 5804658.011 550622.295 5804654.302 550623.895 5804653.697 550626.803 5804661.379 550629.036 5804660.534 550629.379 5804659.732 550633.876 5804658.032 550636.471 5804664.898 550629.123 5804667.675 550630.207 5804670.544 550618.917 5804674.809 550612.48 5804658.011</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 48</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053iFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053iFBL</gml:identifier>
<oid>DENIAL43000053iFBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157331442.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157331442.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550678.512 5804676.404 550686.377 5804672.546 550687.621 5804672.308 550686.317 5804669.426 550684.366 5804670.31 550683.33 5804670.121 550680.568 5804664.49 550688.696 5804660.502 550693.009 5804669.293 550694.766 5804668.431 550695.621 5804670.161 550700.244 5804679.525 550685.53 5804686.795 550682.724 5804681.004 550681.098 5804681.707 550678.512 5804676.404</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 27</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052GfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052GfBL</gml:identifier>
<oid>DENIAL43000052GfBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332419.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332419.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550780.137 5804573.573 550783.189 5804571.885 550782.354 5804570.087 550783.47 5804569.43 550792.149 5804564.317 550792.662 5804564.015 550799.534 5804575.841 550789.894 5804580.57 550786.518 5804575.316 550782.371 5804577.61 550780.137 5804573.573</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 63</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052GyBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052GyBL</gml:identifier>
<oid>DENIAL43000052GyBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332420.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332420.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550780.663 5804628.605 550783.699 5804627.11 550783.426 5804626.557 550793.394 5804621.648 550793.666 5804622.201 550797.183 5804620.469 550796.445 5804618.969 550796.822 5804618.783 550801.97 5804629.26 550785.095 5804637.599 550780.663 5804628.605</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052HMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052HMBL</gml:identifier>
<oid>DENIAL43000052HMBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332421.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332421.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550705.569 5804602.156 550713.063 5804598.463 550715.593 5804597.216 550717.815 5804598.439 550716.733 5804600.406 550719.715 5804602.047 550718.61 5804604.016 550723.938 5804614.872 550714.141 5804619.681 550712.485 5804616.298 550711.25 5804616.902 550706.123 5804606.424 550707.359 5804605.82 550705.569 5804602.156</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052HbBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052HbBL</gml:identifier>
<oid>DENIAL43000052HbBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332422.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332422.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550714.141 5804619.681 550723.938 5804614.872 550725.059 5804614.322 550727.319 5804618.894 550728.582 5804618.269 550728.384 5804617.869 550732.841 5804615.664 550736.453 5804622.966 550731.996 5804625.171 550731.817 5804624.809 550730.554 5804625.434 550732.778 5804629.93 550732.166 5804630.235 550721.831 5804635.381 550720.308 5804632.273 550719.176 5804631.958 550718.084 5804629.666 550718.369 5804628.827 550717.276 5804626.685 550716.511 5804626.363 550715.421 5804624.075 550715.738 5804622.943 550714.141 5804619.681</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052J5BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052J5BL</gml:identifier>
<oid>DENIAL43000052J5BL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332423.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332423.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550721.831 5804635.381 550732.166 5804630.235 550737.265 5804640.573 550736.921 5804640.741 550738.103 5804643.184 550737.117 5804643.656 550728.018 5804648.019 550725.647 5804643.175 550724.569 5804643.703 550722.503 5804639.484 550723.582 5804638.956 550721.831 5804635.381</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052SeBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052SeBL</gml:identifier>
<oid>DENIAL43000052SeBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332424.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332424.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550797.728 5804596.738 550797.782 5804596.712 550807.97 5804591.742 550813.404 5804602.756 550803.113 5804607.767 550801.153 5804603.754 550800.633 5804604.008 550799.186 5804601.044 550799.706 5804600.79 550797.728 5804596.738</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 61</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052pgBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052pgBL</gml:identifier>
<oid>DENIAL43000052pgBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332425.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332425.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550763.222 5804635.802 550777.229 5804628.894 550780.106 5804627.475 550780.663 5804628.605 550785.095 5804637.599 550782.225 5804639.017 550768.219 5804645.937 550763.222 5804635.802</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 19</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052rQBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052rQBL</gml:identifier>
<oid>DENIAL43000052rQBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332426.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332426.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550766.167 5804558.411 550783.792 5804548.956 550788.729 5804557.246 550789.549 5804558.658 550789.014 5804558.97 550792.149 5804564.317 550783.47 5804569.43 550780.052 5804563.628 550771.175 5804568.18 550766.167 5804558.411</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052vBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052vBBL</gml:identifier>
<oid>DENIAL43000052vBBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332427.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332427.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550796.822 5804618.783 550797.082 5804618.655 550797.572 5804619.651 550806.713 5804615.155 550803.113 5804607.767 550813.404 5804602.756 550821.677 5804619.522 550801.97 5804629.26 550796.822 5804618.783</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 15</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053dABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053dABL</gml:identifier>
<oid>DENIAL43000053dABL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332428.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332428.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550718.364 5804582.376 550730.496 5804576.525 550734.515 5804574.504 550740.368 5804586.197 550733.185 5804589.793 550733.149 5804591.185 550735.544 5804595.995 550728.979 5804599.148 550725.463 5804592.09 550723.651 5804592.993 550723.227 5804592.142 550718.364 5804582.376</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053fjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053fjBL</gml:identifier>
<oid>DENIAL43000053fjBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332429.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332429.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550750.584 5804566.403 550766.167 5804558.411 550771.175 5804568.18 550767.099 5804570.269 550768.543 5804573.085 550768.57958521 5804573.1669728 550768.74968526 5804573.63930532 550768.85809091 5804574.12226718 550768.90555439 5804574.60431992 550768.89545089 5804575.07491168 550768.83323475 5804575.5251081 550768.72576843 5804575.94796194 550768.58063965 5804576.33862192 550768.4055573 5804576.69422599 550768.20787937 5804577.01364696 550767.99429032 5804577.29716092 550767.77061809 5804577.54609735 550767.54176534 5804577.76251229 550767.31172413 5804577.9489082 550767.08364444 5804578.10800986 550766.85993232 5804578.24259591 550766.62790699 5804578.36228201 550766.37272569 5804578.47280885 550766.09328756 5804578.5706696 550765.7889283 5804578.65175262 550765.45961509 5804578.71134645 550765.10617325 5804578.74419922 550764.73053231 5804578.74465325 550764.33596811 5804578.70687526 550763.92730436 5804578.62519584 550763.51102541 5804578.49455814 550763.09524471 5804578.31105317 550762.68947841 5804578.07248997 550762.30419409 5804577.7789195 550761.95014377 5804577.43301155 550761.63754142 5804577.04018614 550761.587 5804576.966 550759.971 5804574.189 550755.6 5804576.385 550750.584 5804566.403</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053hYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053hYBL</gml:identifier>
<oid>DENIAL43000053hYBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332430.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332430.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550700.13 5804591.011 550712.486 5804585.21 550718.364 5804582.376 550723.227 5804592.142 550716.642 5804595.414 550716.26 5804594.644 550712.175 5804596.665 550713.063 5804598.463 550705.569 5804602.156 550704.144 5804599.239 550702.785 5804599.903 550700.697 5804595.625 550702.057 5804594.961 550700.13 5804591.011</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053noBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053noBL</gml:identifier>
<oid>DENIAL43000053noBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332431.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332431.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550744.101 5804635.195 550750.822 5804631.815 550753.146 5804636.438 550752.022 5804638.218 550753.406 5804639.186 550754.313 5804638.87 550754.551 5804638.175 550762.467 5804634.271 550763.222 5804635.802 550768.219 5804645.937 550751.335 5804654.281 550747.049 5804645.762 550745.708 5804643.096 550747.597 5804642.146 550744.101 5804635.195</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 21</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053uMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053uMBL</gml:identifier>
<oid>DENIAL43000053uMBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332432.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332432.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550789.894 5804580.57 550799.534 5804575.841 550807.97 5804591.742 550797.782 5804596.712 550789.894 5804580.57</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 62</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053wUBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053wUBL</gml:identifier>
<oid>DENIAL43000053wUBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332433.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332433.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550728.018 5804648.019 550737.117 5804643.656 550739.082 5804647.754 550738.781 5804648.323 550739.578 5804649.907 550740.617 5804649.384 550740.462 5804649.076 550747.049 5804645.762 550751.335 5804654.281 550735.027 5804662.34 550733.238 5804658.685 550732.339 5804659.125 550730.222 5804654.8 550731.084 5804654.379 550729.538 5804651.219 550729.575 5804651.201 550728.018 5804648.019</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 23</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053yJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053yJBL</gml:identifier>
<oid>DENIAL43000053yJBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332434.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332434.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550734.515 5804574.504 550748.386 5804567.53 550750.584 5804566.403 550755.6 5804576.385 550756.076 5804577.332 550747.167 5804581.806 550748.336 5804584.135 550750.871 5804582.863 550754.225 5804589.553 550746.498 5804593.425 550742.374 5804585.192 550740.368 5804586.197 550734.515 5804574.504</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Bonifatiusplatz 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJclBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJclBL</gml:identifier>
<oid>DENIAL430001HJclBL</oid>
<aktualit>2026-07-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157332509.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157332509.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550777.229 5804628.894 550780.106 5804627.475 550780.663 5804628.605 550785.095 5804637.599 550782.225 5804639.017 550777.229 5804628.894</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SWMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SWMBL</gml:identifier>
<oid>DENIAL4300009SWMBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333785.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333785.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550839.617 5804537.22 550849.37 5804531.138 550853.628 5804537.984 550854.684 5804537.327 550859.184 5804544.564 550858.128 5804545.221 550862.291 5804551.916 550857.454 5804554.83 550857.083 5804554.5 550852.12 5804557.522 550839.617 5804537.22</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SaBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SaBBL</gml:identifier>
<oid>DENIAL4300009SaBBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333786.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333786.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550810.202 5804555.211 550820.285 5804549.398 550821.147 5804548.902 550822.352 5804551.063 550822.204 5804552.308 550822.793 5804553.327 550823.898 5804553.842 550829.029 5804563.057 550829.034 5804564.125 550829.782 5804565.418 550830.583 5804565.847 550831.887 5804568.123 550821.18 5804574.26 550817.722 5804568.257 550817.183 5804568.568 550813.001 5804561.312 550813.54 5804561.001 550810.202 5804555.211</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SbFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SbFBL</gml:identifier>
<oid>DENIAL4300009SbFBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333787.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333787.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550873.949 5804493.475 550895.482 5804480.214 550901.361 5804490.281 550899.479 5804491.412 550903.853 5804498.48 550903.287 5804498.838 550902.995 5804498.416 550895.668 5804503.146 550895.458 5804502.923 550894.608 5804503.406 550893.456 5804504.06 550889.828 5804497.667 550880.075 5804503.576 550873.949 5804493.475</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Friedrich-Heeren-Straße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SusBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SusBL</gml:identifier>
<oid>DENIAL4300009SusBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333789.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333789.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550852.409 5804506.742 550873.949 5804493.475 550880.075 5804503.576 550870.256 5804509.524 550875.345 5804517.935 550865.595 5804524.004 550860.429 5804515.605 550858.557 5804516.756 550852.409 5804506.742</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Friedrich-Heeren-Straße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009TAaBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009TAaBL</gml:identifier>
<oid>DENIAL4300009TAaBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333790.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333790.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550820.025 5804526.686 550841.335 5804513.562 550847.745 5804524.001 550845.749 5804525.316 550849.37 5804531.138 550839.617 5804537.22 550838 5804534.594 550838.481 5804534.01 550837.815 5804532.967 550836.976 5804532.931 550836.013 5804531.368 550833.111 5804533.155 550832.395 5804533.02 550831.611 5804533.492 550831.236 5804534.31 550826.637 5804537.143 550826.359 5804537.253 550820.025 5804526.686</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009UMsBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009UMsBL</gml:identifier>
<oid>DENIAL4300009UMsBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333793.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333793.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550873.762 5804537.283 550883.42 5804531.286 550884.461 5804533.007 550884.372 5804533.907 550884.974 5804534.898 550885.781 5804535.189 550889 5804540.514 550888.907 5804541.368 550889.583 5804542.481 550890.363 5804542.767 550891.495 5804544.638 550881.93 5804550.563 550879.785 5804547.075 550879.237 5804547.412 550875.148 5804540.766 550875.697 5804540.429 550873.762 5804537.283</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 3</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009Uw8BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009Uw8BL</gml:identifier>
<oid>DENIAL4300009Uw8BL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333796.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333796.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550856.926 5804589.379 550861.575 5804587.329 550862.396 5804587.488 550863.603 5804586.839 550863.762 5804586.364 550867.267 5804584.818 550866.495 5804583.426 550866.755 5804582.652 550866.213 5804581.576 550865.354 5804581.37 550863.84 5804578.642 550874.1 5804573.394 550877.988 5804579.917 550879.367 5804579.095 550884.604 5804590.451 550861.92 5804600.718 550856.926 5804589.379</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009V6LBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009V6LBL</gml:identifier>
<oid>DENIAL4300009V6LBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333799.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333799.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550798.259 5804540.091 550798.715 5804539.811 550820.025 5804526.686 550826.359 5804537.253 550822.124 5804539.922 550821.183 5804539.766 550819.852 5804540.567 550819.508 5804541.533 550817.406 5804542.828 550818.831 5804545.142 550818.445 5804546.205 550820.285 5804549.398 550810.202 5804555.211 550806.792 5804549.301 550804.59 5804550.6 550798.259 5804540.091</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VB7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VB7BL</gml:identifier>
<oid>DENIAL4300009VB7BL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333800.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333800.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550852.12 5804557.522 550857.083 5804554.5 550857.454 5804554.83 550862.291 5804551.916 550866.493 5804558.91 550867.243 5804558.46 550871.588 5804565.72 550870.066 5804566.629 550874.1 5804573.394 550863.84 5804578.642 550852.12 5804557.522</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VbrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VbrBL</gml:identifier>
<oid>DENIAL4300009VbrBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333802.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333802.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550821.18 5804574.26 550831.887 5804568.123 550833.009 5804570.204 550833.227 5804571.487 550833.905 5804572.711 550834.745 5804573.323 550839.808 5804582.416 550839.896 5804583.53 550840.732 5804585.041 550841.462 5804585.385 550842.667 5804587.551 550831.744 5804593.383 550828.547 5804587.487 550828.213 5804587.671 550824.108 5804580.328 550824.534 5804580.086 550821.18 5804574.26</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VvRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VvRBL</gml:identifier>
<oid>DENIAL4300009VvRBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333803.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333803.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550865.595 5804524.004 550875.345 5804517.935 550876.437 5804519.742 550876.087 5804520.688 550876.764 5804521.767 550877.74 5804521.896 550881.028 5804527.332 550880.823 5804528.236 550881.444 5804529.226 550882.343 5804529.505 550883.42 5804531.286 550873.762 5804537.283 550871.861 5804534.192 550871.312 5804534.53 550867.114 5804527.705 550867.663 5804527.367 550865.595 5804524.004</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kranckestraße 5</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WiDBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WiDBL</gml:identifier>
<oid>DENIAL4300009WiDBL</oid>
<aktualit>2026-07-31Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.157333804.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.157333804.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550831.744 5804593.383 550842.667 5804587.551 550846.292 5804594.07 550856.926 5804589.379 550861.92 5804600.718 550839.237 5804610.986 550833.398 5804600.397 550835.059 5804599.497 550831.744 5804593.383</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052C3BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052C3BL</gml:identifier>
<oid>DENIAL43000052C3BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277682.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277682.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550485.952 5804643.809 550490.583 5804630.909 550496.268 5804632.864 550496.933 5804633.885 550502.304 5804635.845 550500.955 5804639.577 550501.764 5804640.647 550500.953 5804642.884 550499.739 5804642.943 550497.881 5804648.088 550485.952 5804643.809</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 13</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052JwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052JwBL</gml:identifier>
<oid>DENIAL43000052JwBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277684.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277684.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550490.84 5804591.702 550499.492 5804583.709 550503.642 5804588.193 550505.656 5804590.369 550510.018 5804595.082 550503.106 5804601.472 550501.976 5804602.518 550500.491 5804600.94 550499.189 5804600.732 550497.006 5804598.371 550494.993 5804596.194 550490.84 5804591.702</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NJBL</gml:identifier>
<oid>DENIAL43000052NJBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277685.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277685.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550461.445 5804578.769 550479.458 5804562.064 550487.536 5804570.791 550489.116 5804572.499 550489.475 5804572.887 550480.91 5804580.895 550480.451 5804580.381 550479.814 5804579.667 550478.903 5804578.649 550474.934 5804574.218 550474.95 5804573.116 550472.768 5804573.084 550472.715 5804576.696 550465.659 5804583.313 550461.445 5804578.769</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 29</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NlBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NlBL</gml:identifier>
<oid>DENIAL43000052NlBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277687.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277687.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550480.91 5804580.895 550489.475 5804572.887 550489.77 5804573.206 550491.99 5804575.605 550499.492 5804583.709 550490.84 5804591.702 550489.213 5804593.205 550486.348 5804590.105 550486.532 5804589.935 550487.893 5804588.677 550483.283 5804583.539 550481.1 5804581.106 550480.91 5804580.895</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052OMBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052OMBL</gml:identifier>
<oid>DENIAL43000052OMBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277688.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277688.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550471.116 5804601.063 550476.26 5804594.565 550476.61 5804594.745 550476.554 5804594.854 550477.505 5804595.343 550477.411 5804595.429 550478.886 5804596.101 550476.725 5804603.051 550475.184 5804602.572 550475.254 5804602.35 550471.116 5804601.063</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052SnBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052SnBL</gml:identifier>
<oid>DENIAL43000052SnBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277689.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277689.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550481.205 5804608.858 550483.075 5804603.669 550496.188 5804608.395 550494.318 5804613.585 550481.205 5804608.858</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052weBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052weBL</gml:identifier>
<oid>DENIAL43000052weBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277695.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277695.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550457.698 5804574.757 550465.163 5804567.787 550468.331 5804567.755 550468.185 5804565.947 550467.31 5804565.497 550460.939 5804559.899 550468.799 5804550.948 550472.233 5804554.257 550479.458 5804562.064 550461.445 5804578.769 550457.698 5804574.757</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 27</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000538pBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000538pBL</gml:identifier>
<oid>DENIAL430000538pBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277699.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277699.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550472.018 5804656.059 550481.112 5804651.949 550481.722 5804653.299 550485.813 5804652.372 550486.295 5804651.029 550482.528 5804649.678 550484.783 5804643.39 550485.952 5804643.809 550497.881 5804648.088 550496.954 5804650.654 550498.179 5804651.097 550496.517 5804655.699 550495.292 5804655.257 550492.551 5804662.846 550491.013 5804662.29 550485.892 5804664.803 550486.385 5804665.809 550482.116 5804667.903 550481.623 5804666.898 550477.772 5804668.787 550472.47 5804657.059 550472.018 5804656.059</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 15</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053ADBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053ADBL</gml:identifier>
<oid>DENIAL43000053ADBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277701.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277701.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550466.237 5804590.346 550473.221 5804583.693 550476.182 5804586.8 550472.192 5804592.783 550472.024 5804592.979 550466.237 5804590.346</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053GiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053GiBL</gml:identifier>
<oid>DENIAL43000053GiBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277703.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277703.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550497.29 5804614.949 550499.67 5804608.327 550503.784 5804604.424 550504.737 5804603.519 550504.103 5804602.723 550503.106 5804601.472 550510.018 5804595.082 550511.095 5804596.244 550513.819 5804599.184 550514.303 5804602.59 550513.499 5804604.822 550515.022 5804605.513 550510.821 5804616.368 550509.514 5804615.898 550508.416 5804618.949 550497.29 5804614.949</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053gTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053gTBL</gml:identifier>
<oid>DENIAL43000053gTBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277708.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277708.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550461.638 5804623.726 550466.104 5804606.966 550471.116 5804601.063 550475.254 5804602.35 550475.184 5804602.572 550474.087 5804606.101 550475.628 5804606.58 550475.501 5804606.987 550475.465 5804607.102 550470.246 5804623.919 550469.359 5804626.847 550461.638 5804623.726</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053iBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053iBBL</gml:identifier>
<oid>DENIAL43000053iBBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277709.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277709.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550487.131 5804619.968 550488.111 5804617.426 550489.682 5804618.032 550490.687 5804615.233 550496.444 5804617.302 550497.29 5804614.949 550508.416 5804618.949 550507.128 5804622.512 550507.69 5804623.32 550506.734 5804626.302 550505.695 5804626.47 550504.992 5804628.414 550505.671 5804629.278 550504.558 5804632.271 550503.537 5804632.436 550502.304 5804635.845 550496.933 5804633.885 550496.268 5804632.864 550490.583 5804630.909 550494.112 5804621.078 550492.783 5804620.601 550491.153 5804621.518 550487.131 5804619.968</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053k9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053k9BL</gml:identifier>
<oid>DENIAL43000053k9BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277710.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277710.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550453.868 5804665.366 550472.47 5804657.059 550477.772 5804668.787 550474.305 5804670.318 550474.459 5804671.696 550471.271 5804673.076 550470.395 5804672.045 550467.083 5804673.508 550467.084 5804674.966 550463.963 5804676.309 550463.072 5804675.279 550459.029 5804677.064 550453.928 5804665.501 550453.868 5804665.366</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053sLBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053sLBL</gml:identifier>
<oid>DENIAL43000053sLBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277715.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277715.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550475.501 5804606.987 550475.628 5804606.58 550476.725 5804603.051 550478.886 5804596.101 550483.705 5804598.293 550484.042 5804597.982 550484.829 5804598.35 550481.157 5804608.746 550475.501 5804606.987</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053y1BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053y1BL</gml:identifier>
<oid>DENIAL43000053y1BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277718.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277718.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550477.411 5804595.429 550477.505 5804595.343 550485.065 5804588.349 550486.532 5804589.935 550486.348 5804590.105 550489.213 5804593.205 550484.042 5804597.982 550483.705 5804598.293 550478.886 5804596.101 550477.411 5804595.429</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HInfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HInfBL</gml:identifier>
<oid>DENIAL430001HInfBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277853.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277853.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550478.903 5804578.649 550487.536 5804570.791 550489.116 5804572.499 550480.451 5804580.381 550479.814 5804579.667 550478.903 5804578.649</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HIngBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HIngBL</gml:identifier>
<oid>DENIAL430001HIngBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277854.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277854.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550481.1 5804581.106 550489.77 5804573.206 550491.99 5804575.605 550483.283 5804583.539 550481.1 5804581.106</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HInhBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HInhBL</gml:identifier>
<oid>DENIAL430001HInhBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277855.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277855.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550494.993 5804596.194 550503.642 5804588.193 550505.656 5804590.369 550497.006 5804598.371 550494.993 5804596.194</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HIniBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HIniBL</gml:identifier>
<oid>DENIAL430001HIniBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277856.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277856.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550503.106 5804601.472 550510.018 5804595.082 550511.095 5804596.244 550504.103 5804602.723 550503.106 5804601.472</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HInjBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HInjBL</gml:identifier>
<oid>DENIAL430001HInjBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277857.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277857.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550501.976 5804602.518 550503.106 5804601.472 550504.103 5804602.723 550504.737 5804603.519 550503.784 5804604.424 550501.976 5804602.518</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052F6BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052F6BL</gml:identifier>
<oid>DENIAL43000052F6BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277935.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277935.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550491.929 5804766.622 550492.668 5804766.253 550492.069 5804765.053 550498.494 5804761.849 550498.68 5804762.221 550503.09 5804760.021 550503.554 5804760.952 550510.393 5804757.541 550515.28 5804767.518 550496.905 5804776.598 550491.929 5804766.622</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 41</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052MpBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052MpBL</gml:identifier>
<oid>DENIAL43000052MpBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277936.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277936.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550461.068 5804700.294 550465.152 5804698.536 550465.281 5804697.095 550467.63 5804696.127 550469.017 5804696.872 550472.008 5804695.584 550472.185 5804694.248 550474.694 5804693.214 550475.863 5804693.925 550479.774 5804692.241 550485.03 5804702.915 550485.628 5804704.13 550469.26 5804711.212 550467.977 5804712.986 550466.176 5804712.221 550465.46 5804710.549 550461.068 5804700.294</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052PuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052PuBL</gml:identifier>
<oid>DENIAL43000052PuBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277937.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277937.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550510.393 5804757.541 550517.541 5804753.929 550518.392 5804754.671 550518.747 5804755.457 550520.633 5804754.607 550519.897 5804752.975 550516.429 5804745.795 550516.791 5804745.615 550525.14 5804741.477 550527.051 5804745.314 550527.785 5804744.949 550534.337 5804758.101 550515.28 5804767.518 550510.393 5804757.541</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 39</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052RZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052RZBL</gml:identifier>
<oid>DENIAL43000052RZBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277938.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277938.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550479.774 5804692.241 550486.259 5804689.12 550485.625 5804687.801 550489.976 5804685.707 550490.611 5804687.026 550492.763 5804685.99 550494.349 5804686.59 550494.833 5804685.309 550498.448 5804686.676 550498.039 5804687.759 550499.752 5804688.407 550500.91 5804690.739 550502.387 5804690.005 550504.51 5804694.282 550503.048 5804695.007 550506.396 5804701.751 550495.366 5804707.342 550492.861 5804701.731 550493.576 5804699.345 550492.568 5804697.431 550490.167 5804698.695 550490.852 5804700.123 550485.03 5804702.915 550479.774 5804692.241</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053AFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053AFBL</gml:identifier>
<oid>DENIAL43000053AFBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277939.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277939.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550464.184 5804744.54 550473.59 5804739.853 550475.41 5804738.946 550484.486 5804757.402 550483.624 5804757.828 550473.23 5804762.951 550471.378 5804759.182 550469.873 5804759.082 550468.45 5804756.314 550468.897 5804755.959 550469.455 5804755.268 550468.093 5804752.495 550467.025 5804752.309 550466.453 5804752.428 550465.069 5804749.736 550466.117 5804748.475 550464.184 5804744.54</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Goebenstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053E2BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053E2BL</gml:identifier>
<oid>DENIAL43000053E2BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277940.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277940.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550495.366 5804707.342 550506.396 5804701.751 550515.018 5804719.19 550506.041 5804723.673 550503.272 5804725.056 550496.188 5804709.187 550495.366 5804707.342</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053mBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053mBBL</gml:identifier>
<oid>DENIAL43000053mBBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277942.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277942.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550506.041 5804723.673 550515.018 5804719.19 550516.659 5804722.501 550517.464 5804722.102 550519.423 5804726.053 550518.618 5804726.452 550522.205 5804733.685 550523.009 5804733.286 550525.029 5804737.36 550524.188 5804737.684 550525.885 5804741.108 550525.14 5804741.477 550516.791 5804745.615 550513.559 5804739.057 550514.377 5804738.654 550512.781 5804735.415 550512.501 5804735.553 550511.25 5804733.015 550511.53 5804732.877 550510.005 5804729.781 550509.237 5804730.16 550506.041 5804723.673</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 31</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rXBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rXBL</gml:identifier>
<oid>DENIAL43000053rXBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159277944.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159277944.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550473.23 5804762.951 550483.624 5804757.828 550486.795 5804764.372 550486.255 5804765.869 550484.677 5804766.62 550486.444 5804770.334 550488.708 5804769.257 550488.512 5804768.845 550489.002 5804768.036 550491.929 5804766.622 550496.905 5804776.598 550484.091 5804782.929 550482.447 5804782.37 550480.81 5804779.031 550478.482 5804774.091 550477.275 5804774.66 550475.287 5804770.443 550476.494 5804769.874 550473.23 5804762.951</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 43</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052AWBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052AWBL</gml:identifier>
<oid>DENIAL43000052AWBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278607.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278607.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550556.413 5804652.792 550561.511 5804644.891 550567.066 5804648.462 550561.973 5804656.375 550556.413 5804652.792</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052AcBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052AcBL</gml:identifier>
<oid>DENIAL43000052AcBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278608.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278608.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550588.698 5804713.783 550599.397 5804708.552 550596.346 5804701.307 550596.757 5804701.134 550605.001 5804697.662 550613.502 5804717.821 550612.594 5804719.455 550595.582 5804727.86 550590.626 5804717.724 550588.698 5804713.783</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 47</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052FsBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052FsBL</gml:identifier>
<oid>DENIAL43000052FsBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278609.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278609.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550549.16 5804664.03 550553.3 5804657.615 550557.665 5804665.269 550551.386 5804668.025 550549.16 5804664.03</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052OVBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052OVBL</gml:identifier>
<oid>DENIAL43000052OVBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278610.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278610.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550545.945 5804634.939 550552.114 5804625.352 550552.535 5804625.621 550558.774 5804629.61 550560.869 5804630.95 550567.692 5804635.313 550561.511 5804644.891 550556.413 5804652.792 550553.3 5804657.615 550549.16 5804664.03 550546.416 5804659.106 550549.197 5804654.712 550553.833 5804647.385 550554.407 5804647.185 550556.88 5804643.284 550557.195 5804642.156 550554.711 5804640.563 550552.618 5804639.22 550545.945 5804634.939</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 37</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052mwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052mwBL</gml:identifier>
<oid>DENIAL43000052mwBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278611.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278611.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550585.221 5804691.16 550591.495 5804688.517 550590.785 5804686.832 550599.017 5804683.358 550603.688 5804694.524 550605.001 5804697.662 550596.757 5804701.134 550595.805 5804698.874 550589.575 5804701.497 550585.221 5804691.16</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 45</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oGBL</gml:identifier>
<oid>DENIAL43000052oGBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278612.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278612.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550537.906 5804647.37 550541.697 5804645.3 550549.197 5804654.712 550546.416 5804659.106 550540.676 5804651.19 550537.906 5804647.37</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oNBL</gml:identifier>
<oid>DENIAL43000052oNBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278613.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278613.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550532.507 5804704.674 550544.038 5804699.011 550553.051 5804717.385 550541.7 5804722.989 550536.42 5804712.47 550535.207 5804713.079 550533.201 5804709.082 550534.414 5804708.473 550532.507 5804704.674</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052s3BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052s3BL</gml:identifier>
<oid>DENIAL43000052s3BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278614.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278614.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550530.157 5804632.477 550532.229 5804626.807 550530.929 5804626.332 550532.484 5804622.077 550533.784 5804622.552 550534.246 5804621.289 550534.976 5804620.875 550535.646 5804619.473 550536.069 5804619.197 550539.4 5804618.037 550541.196 5804618.754 550541.596 5804618.627 550552.114 5804625.352 550545.945 5804634.939 550545.815 5804635.139 550545.003 5804637.246 550541.843 5804635.295 550544.282 5804631.633 550544.935 5804631.43 550544.901 5804630.263 550540.883 5804627.748 550540.013 5804630.198 550539.039 5804629.852 550537.228 5804634.953 550530.157 5804632.477</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 35</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052tdBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052tdBL</gml:identifier>
<oid>DENIAL43000052tdBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278615.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278615.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550579.313 5804677.065 550585.615 5804674.424 550584.819 5804672.521 550593.017 5804669.093 550597.966 5804680.858 550599.017 5804683.358 550590.785 5804686.832 550589.729 5804684.324 550588.458 5804684.859 550588.564 5804685.111 550583.568 5804687.208 550579.313 5804677.065</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 43</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052wiBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052wiBL</gml:identifier>
<oid>DENIAL43000052wiBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278616.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278616.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550523.513 5804686.289 550534.83 5804680.777 550544.038 5804699.011 550532.507 5804704.674 550530.484 5804700.537 550529.098 5804700.447 550527.982 5804698.168 550528.723 5804696.939 550527.086 5804693.592 550525.757 5804693.622 550524.699 5804691.461 550525.428 5804690.203 550523.513 5804686.289</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 1A</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000531CBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000531CBL</gml:identifier>
<oid>DENIAL430000531CBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278617.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278617.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550521.371 5804657.463 550526.332 5804643.314 550535.03 5804646.362 550537.906 5804647.37 550540.676 5804651.19 550537.888 5804653.349 550536.089 5804650.664 550534.779 5804650.627 550532.752 5804656.457 550533.279 5804657.735 550534.632 5804658.212 550534.85 5804657.593 550542.045 5804660.125 550540.601 5804664.229 550533.057 5804661.575 550521.371 5804657.463</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 16</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053AfBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053AfBL</gml:identifier>
<oid>DENIAL43000053AfBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278618.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278618.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550570.229 5804659.754 550576.354 5804657.065 550586.15 5804652.765 550589.117 5804659.821 550590.034 5804661.999 550593.017 5804669.093 550584.819 5804672.521 550576.836 5804675.86 550575.639 5804672.999 550576.125 5804671.049 550577.85 5804670.124 550579.644 5804670.69 550580.754 5804670.223 550579.21 5804666.551 550578.294 5804664.373 550576.876 5804661.003 550575.874 5804661.424 550574.928 5804663.131 550573.075 5804663.979 550571.685 5804663.071 550570.229 5804659.754</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 41</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053D0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053D0BL</gml:identifier>
<oid>DENIAL43000053D0BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278619.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278619.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550560.003 5804733.534 550560.035 5804732.897 550560.306 5804732.763 550562.658 5804731.602 550563.072 5804731.397 550563.512 5804729.914 550576.4 5804723.69 550576.755 5804724.426 550581.721 5804734.709 550567.632 5804741.67 550565.28 5804742.832 550564.687 5804743.125 550560.211 5804733.96 550560.003 5804733.534</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 35</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053HYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053HYBL</gml:identifier>
<oid>DENIAL43000053HYBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278620.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278620.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550531.967 5804664.989 550533.057 5804661.575 550540.601 5804664.229 550551.386 5804668.025 550551.627 5804668.594 550546.888 5804670.593 550544.024 5804670.196 550534.451 5804666.798 550533.4 5804664.547 550531.967 5804664.989</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053JrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053JrBL</gml:identifier>
<oid>DENIAL43000053JrBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278621.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278621.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550558.013 5804683.731 550565.413 5804680.637 550566.173 5804680.319 550566.963 5804682.208 550566.684 5804684.621 550565.997 5804684.912 550568.771 5804691.464 550569.624 5804691.102 550572.019 5804692.86 550572.697 5804694.465 550564.437 5804697.952 550561.849 5804691.823 550563.999 5804690.916 550563.04 5804688.646 550560.537 5804689.704 550558.013 5804683.731</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053dYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053dYBL</gml:identifier>
<oid>DENIAL43000053dYBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278622.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278622.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550541.7 5804722.989 550553.051 5804717.385 550553.355 5804717.236 550554.979 5804720.56 550553.02 5804721.517 550557.427 5804730.538 550556.86 5804730.815 550558.746 5804734.675 550560.211 5804733.96 550564.687 5804743.125 550554.024 5804748.394 550546.591 5804733.071 550545.523 5804733.59 550542.35 5804727.051 550543.419 5804726.532 550541.7 5804722.989</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 3; Jakobistraße 37</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053fABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053fABL</gml:identifier>
<oid>DENIAL43000053fABL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278623.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278623.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550551.386 5804668.025 550557.665 5804665.269 550558.785 5804664.777 550560.169 5804667.932 550558.829 5804668.581 550562.418 5804677.098 550564.295 5804677.964 550565.413 5804680.637 550558.013 5804683.731 550553.027 5804671.914 550551.627 5804668.594 550551.386 5804668.025</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053kZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053kZBL</gml:identifier>
<oid>DENIAL43000053kZBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278624.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278624.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550525.95 5804639.879 550527.239 5804636.228 550528.657 5804636.728 550530.157 5804632.477 550537.228 5804634.953 550539.593 5804635.782 550538.959 5804637.605 550537.452 5804638.258 550536.48 5804640.855 550537.147 5804642.816 550536.432 5804644.873 550535.643 5804644.599 550535.03 5804646.362 550526.332 5804643.314 550527.368 5804640.38 550525.95 5804639.879</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Robertstraße 14</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053pcBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053pcBL</gml:identifier>
<oid>DENIAL43000053pcBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278625.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278625.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550561.511 5804644.891 550567.692 5804635.313 550575.544 5804640.333 550577.394 5804641.516 550581.211 5804643.957 550583.771 5804647.171 550586.15 5804652.765 550576.354 5804657.065 550574.744 5804653.397 550571.227 5804651.137 550569.379 5804649.949 550567.066 5804648.462 550561.511 5804644.891</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 39</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053q0BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053q0BL</gml:identifier>
<oid>DENIAL43000053q0BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278626.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278626.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550557.473 5804707.471 550566.167 5804703.058 550569.401 5804709.366 550560.514 5804713.701 550557.473 5804707.471</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rGBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rGBL</gml:identifier>
<oid>DENIAL43000053rGBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278627.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278627.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550516.24 5804670.315 550516.838 5804670.288 550518.804 5804664.725 550517.58 5804664.292 550519.088 5804660.024 550520.313 5804660.456 550521.371 5804657.463 550533.057 5804661.575 550531.967 5804664.989 550530.703 5804668.947 550530.969 5804671.29 550530.3 5804671.621 550534.83 5804680.777 550523.513 5804686.289 550521.787 5804682.743 550520.547 5804683.346 550518.616 5804679.379 550519.856 5804678.776 550517.106 5804673.127 550516.367 5804673.16 550516.24 5804670.315</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Am Schatzkampe 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053tvBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053tvBL</gml:identifier>
<oid>DENIAL43000053tvBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278628.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278628.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550564.437 5804697.952 550572.697 5804694.465 550573.251 5804695.779 550572.507 5804698.89 550571.774 5804699.19 550574.554 5804705.972 550575.417 5804705.618 550578.488 5804707.375 550578.913 5804708.648 550570.788 5804712.07 550568.292 5804706.161 550570.412 5804705.265 550569.381 5804702.826 550566.931 5804703.86 550564.437 5804697.952</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053vEBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053vEBL</gml:identifier>
<oid>DENIAL43000053vEBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278629.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278629.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550576.755 5804724.426 550590.626 5804717.724 550595.582 5804727.86 550581.721 5804734.709 550576.755 5804724.426</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 33</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ3XBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ3XBL</gml:identifier>
<oid>DENIAL430001HJ3XBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278693.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278693.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550560.306 5804732.763 550562.658 5804731.602 550567.632 5804741.67 550565.28 5804742.832 550560.306 5804732.763</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ3YBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ3YBL</gml:identifier>
<oid>DENIAL430001HJ3YBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278694.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278694.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550595.684 5804698.586 550602.711 5804695.627 550603.172 5804694.74 550603.688 5804694.524 550605.001 5804697.662 550596.757 5804701.134 550595.805 5804698.874 550595.684 5804698.586</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ3ZBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ3ZBL</gml:identifier>
<oid>DENIAL430001HJ3ZBL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278695.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278695.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550589.729 5804684.324 550597.966 5804680.858 550599.017 5804683.358 550590.785 5804686.832 550589.729 5804684.324</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ40BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ40BL</gml:identifier>
<oid>DENIAL430001HJ40BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278696.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278696.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550578.294 5804664.373 550589.117 5804659.821 550590.034 5804661.999 550579.21 5804666.551 550578.294 5804664.373</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ41BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ41BL</gml:identifier>
<oid>DENIAL430001HJ41BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278697.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278697.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550569.379 5804649.949 550575.544 5804640.333 550577.394 5804641.516 550571.227 5804651.137 550569.379 5804649.949</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJ42BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJ42BL</gml:identifier>
<oid>DENIAL430001HJ42BL</oid>
<aktualit>2026-09-21Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.159278698.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.159278698.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550552.618 5804639.22 550558.774 5804629.61 550560.869 5804630.95 550554.711 5804640.563 550552.618 5804639.22</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052sCBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052sCBL</gml:identifier>
<oid>DENIAL43000052sCBL</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160008039.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160008039.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550568.167 5804777.063 550594.154 5804764.223 550598.689 5804773.545 550598.953 5804774.088 550585.286 5804780.738 550583.554 5804780.482 550580.552 5804781.968 550581.262 5804783.404 550573.251 5804787.368 550568.167 5804777.063</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 42, 44</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000536dBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000536dBL</gml:identifier>
<oid>DENIAL430000536dBL</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160008041.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160008041.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550615.822 5804753.518 550625.87 5804748.553 550628.324 5804749.404 550640.593 5804773.041 550629.255 5804778.912 550625.615 5804780.797 550623.549 5804776.805 550628.697 5804774.079 550626.07 5804768.868 550629.105 5804767.338 550627.548 5804764.25 550624.513 5804765.78 550622.047 5804760.886 550619.829 5804761.941 550615.822 5804753.518</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 49</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000537FBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000537FBL</gml:identifier>
<oid>DENIAL430000537FBL</oid>
<aktualit>2026-10-16Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160008043.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160008043.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550594.154 5804764.223 550615.822 5804753.518 550619.829 5804761.941 550620.384 5804763.107 550598.689 5804773.545 550594.154 5804764.223</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 40</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052A2BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052A2BL</gml:identifier>
<oid>DENIAL43000052A2BL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503245.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503245.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550717.647 5804717.248 550722.06 5804715.033 550721.212 5804713.344 550724.033 5804711.928 550733.102 5804707.379 550735.052 5804711.275 550736.271 5804710.668 550738.174 5804714.5 550736.84 5804715.16 550738.531 5804718.593 550729.347 5804723.108 550728.466 5804721.316 550728.072 5804720.261 550726.842 5804719.819 550726.186 5804720.701 550724.933 5804721.329 550725.665 5804722.788 550720.988 5804725.134 550719.038 5804721.246 550719.529 5804721 550717.647 5804717.248</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ByBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ByBL</gml:identifier>
<oid>DENIAL43000052ByBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503246.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503246.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550655.619 5804758.58 550665.546 5804753.404 550666.525 5804755.283 550667.328 5804755.07 550667.979 5804756.406 550667.441 5804756.764 550669.606 5804761.319 550669.214 5804761.505 550670.256 5804763.696 550669.98 5804767.032 550672.018 5804767.201 550676.359 5804776.199 550670.195 5804779.172 550670.936 5804780.708 550667.874 5804782.184 550655.619 5804758.58</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 56</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052PTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052PTBL</gml:identifier>
<oid>DENIAL43000052PTBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503247.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503247.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550740.359 5804769.948 550747.734 5804766.386 550747.11 5804765.095 550754.682 5804761.439 550755.288 5804762.693 550758.178 5804761.297 550759.985 5804761.714 550763.986 5804770.194 550765.277 5804770.882 550766.27 5804773.043 550765.112 5804776.538 550766.102 5804776.866 550764.552 5804781.545 550763.532 5804781.207 550761.19 5804788.275 550752.074 5804785.255 550753.925 5804779.163 550754.234 5804779.31 550755.161 5804776.822 550753.863 5804774.296 550744.618 5804778.763 550740.359 5804769.948</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 9</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052Z9BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052Z9BL</gml:identifier>
<oid>DENIAL43000052Z9BL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503249.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503249.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550703.217 5804707.015 550706.857 5804705.217 550706.705 5804704.91 550710.958 5804702.809 550711.11 5804703.117 550717.483 5804699.969 550717.322 5804699.643 550721.058 5804697.798 550721.219 5804698.124 550725.729 5804695.896 550727.781 5804696.628 550729.179 5804699.42 550730.486 5804698.766 550732.457 5804702.703 550731.1 5804703.382 550733.102 5804707.379 550724.033 5804711.928 550722.996 5804709.862 550721.596 5804709.096 550719.192 5804710.199 550719.457 5804710.777 550716.254 5804712.247 550716.103 5804712.185 550707.773 5804716.281 550703.217 5804707.015</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 32</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052npBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052npBL</gml:identifier>
<oid>DENIAL43000052npBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503250.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503250.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550653.002 5804731.817 550656.688 5804729.997 550656.462 5804729.539 550659.125 5804728.223 550659.351 5804728.681 550664.356 5804726.21 550664.131 5804725.755 550666.689 5804724.492 550666.914 5804724.946 550670.941 5804722.957 550676.093 5804732.995 550676.404 5804733.599 550664.967 5804739.469 550664.032 5804741.471 550659.976 5804739.822 550659.32 5804741.748 550657.511 5804740.962 550653.002 5804731.817</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 38</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052oJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052oJBL</gml:identifier>
<oid>DENIAL43000052oJBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503251.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503251.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550707.374 5804747.607 550726.744 5804738.291 550732.135 5804749.512 550729.26 5804750.902 550729.63 5804751.944 550725.315 5804754.02 550724.871 5804753.098 550721.186 5804754.871 550721.656 5804755.849 550717.37 5804757.912 550716.882 5804756.897 550712.792 5804758.865 550707.374 5804747.607</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Slicherstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052tYBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052tYBL</gml:identifier>
<oid>DENIAL43000052tYBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503253.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503253.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550726.744 5804738.291 550732.436 5804735.57 550734.224 5804736.156 550734.703 5804735.894 550735.159 5804734.253 550731.634 5804732.966 550727.285 5804724.122 550729.347 5804723.108 550738.531 5804718.593 550740.414 5804722.415 550741.617 5804721.823 550745.682 5804730.081 550744.484 5804730.67 550749.613 5804741.093 550744.184 5804743.764 550744.727 5804744.868 550737.348 5804748.497 550736.735 5804747.251 550732.135 5804749.512 550726.744 5804738.291</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000535kBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000535kBL</gml:identifier>
<oid>DENIAL430000535kBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503256.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503256.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550687.079 5804714.986 550687.622 5804714.718 550687.501 5804714.475 550690.657 5804712.916 550690.778 5804713.159 550699.31 5804708.945 550699.191 5804708.704 550702.39 5804707.124 550702.509 5804707.365 550703.217 5804707.015 550707.773 5804716.281 550708.425 5804717.607 550700.63 5804721.44 550699.258 5804721.527 550700.296 5804723.74 550702.192 5804722.733 550702.988 5804723.124 550705.623 5804728.858 550700.141 5804731.55 550699.399 5804730.039 550697.244 5804731.097 550693.596 5804723.667 550691.779 5804724.559 550687.079 5804714.986</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 34</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053B3BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053B3BL</gml:identifier>
<oid>DENIAL43000053B3BL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503258.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503258.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550687.924 5804756.778 550707.299 5804747.449 550707.374 5804747.607 550712.792 5804758.865 550708.741 5804760.815 550708.596 5804762.12 550705.826 5804763.432 550704.705 5804762.732 550701.221 5804764.373 550700.991 5804765.705 550698.218 5804767.003 550697.26 5804766.213 550693.373 5804768.087 550688.133 5804757.212 550687.924 5804756.778</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Slicherstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053JBBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053JBBL</gml:identifier>
<oid>DENIAL43000053JBBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503261.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503261.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550670.941 5804722.957 550674.518 5804721.19 550674.361 5804720.873 550677.633 5804719.257 550677.79 5804719.574 550680.987 5804717.995 550680.834 5804717.686 550683.974 5804716.136 550684.126 5804716.444 550687.079 5804714.986 550691.779 5804724.559 550692.387 5804725.798 550686.368 5804728.753 550685.735 5804728.651 550685.467 5804728.232 550684.724 5804728.708 550687.931 5804735.342 550681.127 5804738.631 550677.787 5804732.125 550676.093 5804732.995 550670.941 5804722.957</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 36</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053bPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053bPBL</gml:identifier>
<oid>DENIAL43000053bPBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503262.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503262.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550644.027 5804736.25 550653.002 5804731.817 550657.511 5804740.962 550656.662 5804742.804 550660.434 5804744.435 550661.922 5804747.389 550662.717 5804747.104 550665.905 5804753.217 550665.546 5804753.404 550655.619 5804758.58 550644.027 5804736.25</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Voßstraße 54</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053vJBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053vJBL</gml:identifier>
<oid>DENIAL43000053vJBL</oid>
<aktualit>2026-10-29Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160503265.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160503265.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550672.018 5804767.201 550672.308 5804763.686 550674.418 5804763.86 550685.914 5804758.318 550685.416 5804757.284 550686.468 5804756.777 550686.951 5804757.781 550688.133 5804757.212 550693.373 5804768.087 550689.704 5804769.855 550690.182 5804770.847 550686.882 5804772.438 550686.391 5804771.42 550683.435 5804772.845 550683.911 5804773.833 550680.495 5804775.48 550679.996 5804774.445 550676.359 5804776.199 550672.018 5804767.201</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Slicherstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052GhBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052GhBL</gml:identifier>
<oid>DENIAL43000052GhBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505458.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505458.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550843.485 5804759.888 550847.99 5804757.943 550847.49 5804756.785 550851.012 5804755.265 550851.51 5804756.42 550857.469 5804753.848 550857.009 5804752.779 550860.928 5804751.088 550861.398 5804752.178 550865.982 5804750.2 550868.999 5804757.198 550869.931 5804762.771 550861.567 5804766.378 550861.073 5804765.231 550857.384 5804766.822 550857.853 5804767.91 550851.901 5804770.477 550852.227 5804771.233 550850.824 5804771.838 550850.494 5804771.074 550848.65 5804771.869 550843.485 5804759.888</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 1</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052HHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052HHBL</gml:identifier>
<oid>DENIAL43000052HHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505459.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505459.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550827.547 5804680.676 550836.074 5804676.417 550835.234 5804674.706 550836.729 5804673.971 550846.218 5804669.31 550849.508 5804676.913 550852.41 5804683.621 550846.902 5804685.943 550848.053 5804688.872 550841.201 5804691.713 550840.839 5804691.008 550837.826 5804684.055 550838.3 5804682.961 550837.915 5804681.955 550835.519 5804683.145 550836.223 5804684.907 550830.829 5804687.501 550827.547 5804680.676</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 59</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052MIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052MIBL</gml:identifier>
<oid>DENIAL43000052MIBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505461.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505461.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550774.844 5804743.049 550775.011 5804742.967 550785.367 5804737.919 550787.725 5804742.756 550812.273 5804732.323 550814.169 5804736.667 550814.927 5804736.336 550818.746 5804734.669 550823.164 5804744.786 550819.345 5804746.454 550818.425 5804746.855 550818.629 5804747.323 550817.159 5804747.967 550816.939 5804747.465 550815.512 5804748.092 550815.723 5804748.57 550814.584 5804749.072 550814.363 5804748.572 550813.12 5804749.121 550813.33 5804749.595 550812.162 5804750.113 550811.94 5804749.611 550810.867 5804750.087 550811.079 5804750.562 550810.042 5804751.024 550809.818 5804750.521 550808.69 5804751.025 550808.901 5804751.494 550807.638 5804752.06 550807.411 5804751.554 550806.354 5804752.029 550806.566 5804752.499 550805.425 5804753.014 550805.197 5804752.508 550804.048 5804753.028 550804.258 5804753.493 550803.111 5804754.013 550802.881 5804753.505 550801.734 5804754.026 550801.944 5804754.488 550800.798 5804755.01 550800.566 5804754.5 550799.434 5804755.017 550799.645 5804755.477 550798.522 5804755.991 550798.287 5804755.481 550797.197 5804755.982 550797.394 5804756.411 550793.977 5804757.986 550793.727 5804757.443 550792.405 5804758.054 550792.615 5804758.509 550791.649 5804758.957 550791.412 5804758.445 550790.232 5804758.994 550790.443 5804759.448 550789.525 5804759.876 550789.285 5804759.362 550787.983 5804759.971 550788.193 5804760.42 550787.244 5804760.866 550787.002 5804760.35 550785.591 5804761.014 550785.797 5804761.451 550783.999 5804762.3 550783.104 5804760.408 550779.686 5804762.027 550778.673 5804759.893 550782.082 5804758.273 550781.767 5804757.611 550782.203 5804757.404 550781.53 5804755.994 550781.099 5804756.2 550780.705 5804755.378 550781.144 5804755.167 550780.504 5804753.833 550780.076 5804754.038 550779.64 5804753.132 550780.083 5804752.919 550779.349 5804751.397 550778.926 5804751.602 550778.52 5804750.762 550779.02 5804750.52 550778.376 5804749.194 550777.939 5804749.407 550774.844 5804743.049</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistungen</funktion>
<gfkzshh>31001_2010</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 16; Harnischstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052NHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052NHBL</gml:identifier>
<oid>DENIAL43000052NHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505462.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505462.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550759.317 5804679.307 550778.026 5804670.066 550783.5 5804681.261 550781.681 5804682.259 550764.975 5804690.613 550762.854 5804686.375 550759.317 5804679.307</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 30</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052Q7BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052Q7BL</gml:identifier>
<oid>DENIAL43000052Q7BL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505465.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505465.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550814.095 5804675.019 550825.695 5804669.278 550827.961 5804673.876 550816.353 5804679.599 550815.274 5804677.411 550814.095 5804675.019</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052RLBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052RLBL</gml:identifier>
<oid>DENIAL43000052RLBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505467.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505467.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550835.772 5804700.533 550841.573 5804697.874 550842.21 5804699.262 550844.488 5804698.218 550844.101 5804697.373 550843.849 5804697.488 550842.132 5804693.744 550841.201 5804691.713 550848.053 5804688.872 550846.902 5804685.943 550852.41 5804683.621 550853.637 5804686.456 550854.622 5804688.734 550859.718 5804700.511 550848.234 5804705.415 550847.365 5804703.688 550838.871 5804707.294 550835.772 5804700.533</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 58</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052TABL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052TABL</gml:identifier>
<oid>DENIAL43000052TABL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505468.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505468.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550809.516 5804677.285 550812.834 5804675.643 550814.016 5804678.032 550815.274 5804677.411 550816.353 5804679.599 550818.093 5804683.125 550813.419 5804685.421 550809.516 5804677.285</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052TuBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052TuBL</gml:identifier>
<oid>DENIAL43000052TuBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505469.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505469.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550806.981 5804705.514 550814.236 5804702.406 550814.511 5804703.048 550815.432 5804702.653 550816.34 5804704.771 550815.504 5804705.13 550819.551 5804714.561 550812.245 5804717.697 550806.981 5804705.514</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052ZPBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052ZPBL</gml:identifier>
<oid>DENIAL43000052ZPBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505471.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505471.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550825.695 5804669.278 550829.509 5804667.39 550831.597 5804672.084 550827.961 5804673.876 550825.695 5804669.278</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052nFBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052nFBL</gml:identifier>
<oid>DENIAL43000052nFBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505473.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505473.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550830.72 5804728.324 550851.954 5804719.067 550853.185 5804718.646 550854.314 5804721.226 550858.014 5804729.681 550853.556 5804731.631 550854.061 5804732.786 550850.569 5804734.311 550850.056 5804733.135 550843.865 5804735.838 550844.375 5804737.006 550840.718 5804738.601 550840.198 5804737.408 550835.557 5804739.431 550831.026 5804729.028 550830.72 5804728.324</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 18</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000052wNBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000052wNBL</gml:identifier>
<oid>DENIAL43000052wNBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505474.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505474.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550848.234 5804705.415 550859.718 5804700.511 550868.552 5804720.928 550868.543 5804725.141 550865.436 5804726.5 550866.037 5804727.874 550861.894 5804729.686 550861.269 5804728.257 550858.014 5804729.681 550854.314 5804721.226 550856.267 5804720.372 550853.443 5804713.919 550851.962 5804714.525 550848.234 5804705.415</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 57</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000533xBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000533xBL</gml:identifier>
<oid>DENIAL430000533xBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505475.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505475.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550865.982 5804750.2 550868.848 5804748.964 550868.393 5804747.907 550875.501 5804744.838 550875.988 5804745.964 550878.849 5804744.727 550889.571 5804769.508 550876.826 5804775.11 550872.298 5804764.806 550874.058 5804763.492 550871.152 5804756.839 550868.999 5804757.198 550865.982 5804750.2</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 56</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300005363BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300005363BL</gml:identifier>
<oid>DENIAL4300005363BL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505476.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505476.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550800.365 5804659.033 550821.924 5804648.384 550826.229 5804657.109 550827.331 5804659.342 550818.089 5804663.915 550818.69 5804665.128 550815.724 5804666.603 550815.089 5804665.329 550805.84 5804669.954 550800.365 5804659.033</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 24</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430000536NBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430000536NBL</gml:identifier>
<oid>DENIAL430000536NBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505477.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505477.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550820.832 5804709.061 550823.74 5804707.812 550825.534 5804711.993 550822.626 5804713.241 550820.832 5804709.061</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053CpBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053CpBL</gml:identifier>
<oid>DENIAL43000053CpBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505479.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505479.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550766.069 5804724.56 550777.057 5804719.284 550785.973 5804737.624 550785.367 5804737.919 550775.011 5804742.967 550766.069 5804724.56</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 7</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053g5BL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053g5BL</gml:identifier>
<oid>DENIAL43000053g5BL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505482.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505482.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550817.903 5804726.176 550826.193 5804722.745 550828.57 5804728.005 550828.055 5804728.238 550828.842 5804729.979 550831.026 5804729.028 550835.557 5804739.431 550831.902 5804741.024 550832.366 5804742.088 550827.665 5804744.138 550827.181 5804743.031 550823.164 5804744.786 550818.746 5804734.669 550821.48 5804733.475 550822.34 5804732.142 550821.652 5804731.607 550821.395 5804730.987 550820.114 5804731.517 550817.903 5804726.176</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 17</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053kHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053kHBL</gml:identifier>
<oid>DENIAL43000053kHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505483.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505483.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550820.599 5804769.847 550824.634 5804768.078 550824.113 5804766.889 550828.496 5804764.975 550829.023 5804766.184 550835.169 5804763.51 550834.632 5804762.273 550838.864 5804760.439 550839.39 5804761.656 550843.485 5804759.888 550848.65 5804771.869 550848.691 5804771.964 550825.845 5804781.8 550820.599 5804769.847</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Gabelsbergerstraße 2</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053pHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053pHBL</gml:identifier>
<oid>DENIAL43000053pHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505485.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505485.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550821.924 5804648.384 550831.684 5804643.579 550833.813 5804644.314 550834.233 5804645.153 550844.883 5804666.513 550845.829 5804668.411 550846.218 5804669.31 550836.729 5804673.971 550835.376 5804671.229 550827.98 5804656.245 550826.229 5804657.109 550821.924 5804648.384</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 60</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053qtBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053qtBL</gml:identifier>
<oid>DENIAL43000053qtBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505486.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505486.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550778.026 5804670.066 550781.766 5804668.219 550781.533 5804667.748 550785.802 5804665.64 550786.034 5804666.111 550789.169 5804664.563 550792.234 5804671.609 550790.406 5804672.405 550791.726 5804675.437 550790.538 5804675.954 550791.384 5804677.897 550791.9 5804677.672 550794.323 5804683.237 550790.396 5804685.254 550789.455 5804683.424 550787.006 5804684.558 550785.301 5804680.876 550784.722 5804680.593 550783.5 5804681.261 550778.026 5804670.066</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 28</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053rTBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053rTBL</gml:identifier>
<oid>DENIAL43000053rTBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505487.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505487.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550775.589 5804713.707 550784.317 5804709.603 550786.764 5804714.623 550778.04 5804718.811 550775.589 5804713.707</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Wirtschaft oder Gewerbe</funktion>
<gfkzshh>31001_2000</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053sHBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053sHBL</gml:identifier>
<oid>DENIAL43000053sHBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505488.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505488.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550757.1 5804706.107 550766.903 5804701.339 550768.06 5804700.776 550769.572 5804703.887 550777.057 5804719.284 550766.069 5804724.56 550758.625 5804709.243 550757.1 5804706.107</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 6</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053uRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053uRBL</gml:identifier>
<oid>DENIAL43000053uRBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505489.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505489.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550789.169 5804664.563 550800.365 5804659.033 550805.84 5804669.954 550805.974 5804670.22 550801.711 5804672.357 550801.156 5804674.122 550801.731 5804675.263 550802.875 5804674.828 550805.356 5804680.528 550797.584 5804683.909 550792.234 5804671.609 550789.169 5804664.563</gml:posList>
</gml:LinearRing>
</gml:exterior>
<gml:interior>
<gml:LinearRing>
<gml:posList>550794.38 5804675.4 550795.442 5804677.78 550797.753 5804676.749 550796.692 5804674.369 550794.38 5804675.4</gml:posList>
</gml:LinearRing>
</gml:interior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 26</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL43000053vzBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL43000053vzBL</gml:identifier>
<oid>DENIAL43000053vzBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505490.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505490.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550747.126 5804685.328 550759.317 5804679.307 550762.854 5804686.375 550760.448 5804687.748 550762.264 5804691.554 550762.948 5804691.417 550764.259 5804694.222 550764.15 5804695.678 550766.903 5804701.339 550757.1 5804706.107 550755.654 5804703.131 550754.775 5804703.425 550752.81 5804699.542 550753.589 5804699.049 550750.606 5804693.152 550749.679 5804693.496 550747.707 5804689.719 550748.639 5804689.232 550747.402 5804686.552 550747.126 5804685.328</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Harnischstraße 4</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009RXIBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009RXIBL</gml:identifier>
<oid>DENIAL4300009RXIBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505639.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505639.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550871.156 5804670.354 550881.822 5804665.762 550883.233 5804669.04 550888.867 5804682.132 550891.015 5804687.123 550890.398 5804687.39 550880.476 5804691.684 550878.926 5804688.096 550877.537 5804687.791 550876.117 5804684.787 550876.885 5804683.601 550874.786 5804678.604 550873.436 5804678.389 550872.011 5804675.273 550872.812 5804674.203 550872.566 5804673.631 550871.156 5804670.354</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude</funktion>
<gfkzshh>31001_1000</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 11</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009SEvBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009SEvBL</gml:identifier>
<oid>DENIAL4300009SEvBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505643.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505643.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550857.35 5804651.001 550868.696 5804646.149 550872.658 5804644.454 550879.595 5804660.584 550880.422 5804662.506 550881.822 5804665.762 550871.156 5804670.354 550869.754 5804667.096 550869.466 5804666.429 550868.108 5804666.279 550866.977 5804663.428 550867.683 5804662.245 550865.605 5804657.262 550865.428 5804657.312 550863.906 5804653.764 550861.67 5804652.69 550858.647 5804653.998 550857.35 5804651.001</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 10</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009VYwBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009VYwBL</gml:identifier>
<oid>DENIAL4300009VYwBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505662.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505662.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550848.983 5804631.67 550849.462 5804630.422 550865.016 5804623.417 550869.338 5804633.167 550865.884 5804634.698 550865.617 5804634.096 550861.887 5804635.749 550862.817 5804637.848 550864.775 5804636.981 550868.696 5804646.149 550857.35 5804651.001 550848.983 5804631.67</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Gebäude für Handel und Dienstleistung mit Wohnen</funktion>
<gfkzshh>31001_2310</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Kollenrodtstraße 8</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL4300009WqeBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL4300009WqeBL</gml:identifier>
<oid>DENIAL4300009WqeBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505667.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505667.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550865.016 5804623.417 550884.394 5804614.69 550889.837 5804626.711 550887.375 5804627.826 550890.36 5804634.42 550885.028 5804636.577 550881.079 5804627.663 550879.899 5804628.186 550879.99 5804628.69 550876.883 5804629.978 550877.285 5804630.947 550873.658 5804632.451 550871.801 5804633.678 550869.859 5804634.344 550869.338 5804633.167 550865.016 5804623.417</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Gebäude</gebnutzbez>
<funktion>Wohngebäude mit Handel und Dienstleistungen</funktion>
<gfkzshh>31001_1120</gfkzshh>
<gmdschl>03241001</gmdschl>
<lagebeztxt>Jakobistraße 20</lagebeztxt>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcmBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcmBL</gml:identifier>
<oid>DENIAL430001HJcmBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505799.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505799.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550835.376 5804671.229 550844.883 5804666.513 550845.829 5804668.411 550846.218 5804669.31 550836.729 5804673.971 550835.376 5804671.229</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcnBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcnBL</gml:identifier>
<oid>DENIAL430001HJcnBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505800.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505800.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550841.201 5804691.713 550848.053 5804688.872 550853.637 5804686.456 550854.622 5804688.734 550842.132 5804693.744 550841.201 5804691.713</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcoBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcoBL</gml:identifier>
<oid>DENIAL430001HJcoBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505801.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505801.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550814.927 5804736.336 550818.746 5804734.669 550823.164 5804744.786 550819.345 5804746.454 550814.927 5804736.336</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001HJcrBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001HJcrBL</gml:identifier>
<oid>DENIAL430001HJcrBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505804.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505804.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550780.442 5804701.652 550783.228 5804700.294 550795.615 5804725.712 550792.874 5804727.162 550786.764 5804714.623 550784.317 5804709.603 550780.442 5804701.652</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Sonstiges Bauwerk oder sonstige Einrichtung</gebnutzbez>
<funktion>Überdachung</funktion>
<gfkzshh>51009_1610</gfkzshh>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZLQBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLQBL</gml:identifier>
<oid>DENIAL430001jZLQBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505825.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505825.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550869.754 5804667.096 550880.422 5804662.506 550881.822 5804665.762 550871.156 5804670.354 550869.754 5804667.096</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
<wfs:member>
<GebaeudeBauwerk gml:id="DENIAL430001jZLRBL">
<gml:identifier codeSpace="urn:adv:oid:">urn:adv:oid:DENIAL430001jZLRBL</gml:identifier>
<oid>DENIAL430001jZLRBL</oid>
<aktualit>2026-10-30Z</aktualit>
<geometrie>
<gml:MultiSurface gml:id="gebbau.id.160505826.geometrie.Geom_0" srsName="urn:ogc:def:crs:EPSG::25832" srsDimension="2">
<gml:surfaceMember>
<gml:Polygon gml:id="gebbau.id.160505826.geometrie.Geom_1">
<gml:exterior>
<gml:LinearRing>
<gml:posList>550871.156 5804670.354 550881.822 5804665.762 550883.233 5804669.04 550872.566 5804673.631 550871.156 5804670.354</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:Polygon>
</gml:surfaceMember>
</gml:MultiSurface>
</geometrie>
<gebnutzbez>Bauteil</gebnutzbez>
<funktion>Durchfahrt im Gebäude</funktion>
<gmdschl>03241001</gmdschl>
</GebaeudeBauwerk>
</wfs:member>
</wfs:FeatureCollection>